export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      cads: {
        Row: {
          cargo: string | null
          cod_cargo: string | null
          cpf: string | null
          created_at: string | null
          data_admissao: string | null
          email: string | null
          id: string
          jornada: number
          matricula: string | null
          nome: string
          observacoes: string | null
          sexo: string | null
          situacao: string | null
          situacao_funcional: string | null
          status: string | null
          telefone: string | null
          unidade_id: string | null
          updated_at: string | null
          vencimento: string | null
        }
        Insert: {
          cargo?: string | null
          cod_cargo?: string | null
          cpf?: string | null
          created_at?: string | null
          data_admissao?: string | null
          email?: string | null
          id?: string
          jornada: number
          matricula?: string | null
          nome: string
          observacoes?: string | null
          sexo?: string | null
          situacao?: string | null
          situacao_funcional?: string | null
          status?: string | null
          telefone?: string | null
          unidade_id?: string | null
          updated_at?: string | null
          vencimento?: string | null
        }
        Update: {
          cargo?: string | null
          cod_cargo?: string | null
          cpf?: string | null
          created_at?: string | null
          data_admissao?: string | null
          email?: string | null
          id?: string
          jornada?: number
          matricula?: string | null
          nome?: string
          observacoes?: string | null
          sexo?: string | null
          situacao?: string | null
          situacao_funcional?: string | null
          status?: string | null
          telefone?: string | null
          unidade_id?: string | null
          updated_at?: string | null
          vencimento?: string | null
        }
        Relationships: []
      }
      levantamentos_pedagogicos: {
        Row: {
          created_at: string
          dados_pedagogicos: Json
          data_levantamento: string | null
          etapa: number | null
          id: string
          responsavel: string | null
          status: string | null
          unidade_id: string
          unidade_nome: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          dados_pedagogicos?: Json
          data_levantamento?: string | null
          etapa?: number | null
          id?: string
          responsavel?: string | null
          status?: string | null
          unidade_id: string
          unidade_nome: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          dados_pedagogicos?: Json
          data_levantamento?: string | null
          etapa?: number | null
          id?: string
          responsavel?: string | null
          status?: string | null
          unidade_id?: string
          unidade_nome?: string
          updated_at?: string
        }
        Relationships: []
      }
      unidades_cadastro: {
        Row: {
          atualizado_por: string | null
          bairro: string | null
          cep: string | null
          cidade: string | null
          created_at: string
          diretor: string | null
          email: string | null
          id: string
          inep: string | null
          logradouro: string | null
          modalidades: string | null
          nome: string
          numero: string | null
          observacoes: string | null
          qtd_alunos: number | null
          qtd_alunos_instituicao: number | null
          qtd_cads: number | null
          qtd_salas: number | null
          regiao: string | null
          salas: Json
          situacao_imovel: string | null
          telefone: string | null
          turnos: string | null
          uf: string | null
          unidade_id: string
          updated_at: string
        }
        Insert: {
          atualizado_por?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          created_at?: string
          diretor?: string | null
          email?: string | null
          id?: string
          inep?: string | null
          logradouro?: string | null
          modalidades?: string | null
          nome: string
          numero?: string | null
          observacoes?: string | null
          qtd_alunos?: number | null
          qtd_alunos_instituicao?: number | null
          qtd_cads?: number | null
          qtd_salas?: number | null
          regiao?: string | null
          salas?: Json
          situacao_imovel?: string | null
          telefone?: string | null
          turnos?: string | null
          uf?: string | null
          unidade_id: string
          updated_at?: string
        }
        Update: {
          atualizado_por?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          created_at?: string
          diretor?: string | null
          email?: string | null
          id?: string
          inep?: string | null
          logradouro?: string | null
          modalidades?: string | null
          nome?: string
          numero?: string | null
          observacoes?: string | null
          qtd_alunos?: number | null
          qtd_alunos_instituicao?: number | null
          qtd_cads?: number | null
          qtd_salas?: number | null
          regiao?: string | null
          salas?: Json
          situacao_imovel?: string | null
          telefone?: string | null
          turnos?: string | null
          uf?: string | null
          unidade_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      vistorias: {
        Row: {
          created_at: string
          data_vistoria: string | null
          entorno: Json
          estrutural: Json
          etapa: number
          fotografico: Json
          id: string
          imovel_proprio_alugado: string | null
          nota_media: number | null
          parecer: Json
          responsavel: string | null
          status: string
          unidade_id: string
          unidade_nome: string
          updated_at: string
          uso_tipo: string | null
        }
        Insert: {
          created_at?: string
          data_vistoria?: string | null
          entorno?: Json
          estrutural?: Json
          etapa?: number
          fotografico?: Json
          id?: string
          imovel_proprio_alugado?: string | null
          nota_media?: number | null
          parecer?: Json
          responsavel?: string | null
          status?: string
          unidade_id: string
          unidade_nome: string
          updated_at?: string
          uso_tipo?: string | null
        }
        Update: {
          created_at?: string
          data_vistoria?: string | null
          entorno?: Json
          estrutural?: Json
          etapa?: number
          fotografico?: Json
          id?: string
          imovel_proprio_alugado?: string | null
          nota_media?: number | null
          parecer?: Json
          responsavel?: string | null
          status?: string
          unidade_id?: string
          unidade_nome?: string
          updated_at?: string
          uso_tipo?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
