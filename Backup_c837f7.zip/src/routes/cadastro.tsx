import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import VistoriaForm from "@/components/cadastro/VistoriaForm";
import unidadesData from "@/data/unidades.json";
import type { Unidade } from "@/types/unidade";
import {
  listarCadastros,
  listarVistorias,
  type CadastroUnidade,
  type Vistoria,
} from "@/lib/cadastro-api";
import {
  classificacaoPorNota,
  corDaNota,
  labelClassificacao,
  labelPadrao,
} from "@/lib/cadastro-schema";

const UNIDADES = unidadesData as Unidade[];

export const Route = createFileRoute("/cadastro")({
  head: () => ({
    meta: [
      { title: "Cadastro & Vistoria Técnica | PMC-MCEDU-CAD" },
      {
        name: "description",
        content:
          "Módulo de cadastro e vistoria técnica das unidades educacionais de Cuiabá: dados cadastrais, análise estrutural, checklist fotográfico, entorno e parecer técnico.",
      },
      { property: "og:title", content: "Cadastro & Vistoria Técnica | PMC-MCEDU-CAD" },
      {
        property: "og:description",
        content:
          "Atualize os dados cadastrais das unidades educacionais e registre vistorias técnicas conforme NBR 14653-2.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CadastroPage,
});

function CadastroPage() {
  const [cadastros, setCadastros] = useState<CadastroUnidade[]>([]);
  const [vistorias, setVistorias] = useState<Vistoria[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [aba, setAba] = useState<"painel" | "form">("painel");
  const [edicao, setEdicao] = useState<Vistoria | null>(null);
  const [busca, setBusca] = useState("");

  async function carregar() {
    setCarregando(true);
    try {
      const [c, v] = await Promise.all([listarCadastros(), listarVistorias()]);
      setCadastros(c);
      setVistorias(v);
      setErro(null);
    } catch (e) {
      setErro("Não foi possível carregar os registros.");
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregar();
  }, []);

  const unidadesOrdenadas = useMemo(
    () => [...UNIDADES].sort((a, b) => a.unidade.localeCompare(b.unidade, "pt-BR")),
    [],
  );

  const listaFiltrada = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return vistorias;
    return vistorias.filter((v) => v.unidade_nome.toLowerCase().includes(q));
  }, [vistorias, busca]);

  const resumo = useMemo(() => {
    const notas = vistorias
      .map((v) => v.nota_media)
      .filter((n): n is number => typeof n === "number");
    const media = notas.length
      ? Math.round((notas.reduce((a, b) => a + b, 0) / notas.length) * 100) / 100
      : null;
    return {
      totalUnidades: UNIDADES.length,
      atualizacoes: cadastros.length,
      vistorias: vistorias.length,
      concluidas: vistorias.filter((v) => v.status === "concluida").length,
      criticas: notas.filter((n) => n < 5).length,
      media,
    };
  }, [cadastros, vistorias]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-7xl flex-1 space-y-6 px-4 py-6 sm:px-6 lg:px-8">
        <header className="space-y-1">
          <h1 className="text-2xl font-bold sm:text-3xl">Cadastro & Vistoria Técnica</h1>
          <p className="text-sm text-muted-foreground">
            Módulo de atualização cadastral das unidades educacionais com laudo técnico em 6 etapas
            (NBR 14653-2 / CAU-BR). Os dados alimentam o painel principal do sistema.
          </p>
        </header>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {[
            ["Unidades educacionais", resumo.totalUnidades],
            ["Atualizações realizadas", resumo.atualizacoes],
            ["Vistorias registradas", resumo.vistorias],
            ["Vistorias concluídas", resumo.concluidas],
            ["Nota média geral", resumo.media ?? "—"],
            ["Unidades críticas", resumo.criticas],
          ].map(([label, valor]) => (
            <div key={String(label)} className="rounded-xl border border-border bg-card p-3">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</p>
              <p className="mt-1 text-xl font-bold">{valor}</p>
            </div>
          ))}
        </div>


        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setAba("painel")}
            className={`rounded-md px-4 py-2 text-sm font-semibold ${
              aba === "painel" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            Painel de atualizações
          </button>
          <button
            type="button"
            onClick={() => {
              setEdicao(null);
              setAba("form");
            }}
            className={`rounded-md px-4 py-2 text-sm font-semibold ${
              aba === "form" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            Nova vistoria / atualização
          </button>
        </div>

        {erro && (
          <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{erro}</p>
        )}

        {aba === "form" ? (
          <VistoriaForm
            unidades={unidadesOrdenadas}
            cadastros={cadastros}
            vistoriaInicial={edicao}
            onSaved={() => {
              carregar();
              setAba("painel");
            }}
            onCancel={() => setAba("painel")}
          />
        ) : (
          <section className="space-y-3">
            <input
              className="w-full max-w-md rounded-md border border-border bg-background px-3 py-2 text-sm"
              placeholder="Buscar unidade..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
            />
            {carregando ? (
              <p className="text-sm text-muted-foreground">Carregando...</p>
            ) : listaFiltrada.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Nenhuma vistoria registrada. Clique em “Nova vistoria / atualização”.
              </p>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-border">
                <table className="w-full min-w-[860px] text-sm">
                  <thead className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2">Unidade</th>
                      <th className="px-3 py-2">Data</th>
                      <th className="px-3 py-2">Nota</th>
                      <th className="px-3 py-2">Conservação</th>
                      <th className="px-3 py-2">Padrão</th>
                      <th className="px-3 py-2">Status</th>
                      <th className="px-3 py-2">Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {listaFiltrada.map((v) => {
                      const cad = cadastros.find((c) => c.unidade_id === v.unidade_id);
                      return (
                        <tr key={v.id} className="border-t border-border">
                          <td className="px-3 py-2">
                            <p className="font-semibold">{v.unidade_nome}</p>
                            <p className="text-[11px] text-muted-foreground">
                              {[cad?.logradouro, cad?.numero, cad?.bairro]
                                .filter(Boolean)
                                .join(", ") || "Endereço não informado"}
                            </p>
                          </td>
                          <td className="px-3 py-2">{v.data_vistoria ?? "—"}</td>
                          <td className="px-3 py-2">
                            <span
                              className={`rounded px-2 py-0.5 text-xs font-bold ${corDaNota(v.nota_media)}`}
                            >
                              {v.nota_media ?? "—"}
                            </span>
                          </td>
                          <td className="px-3 py-2 text-xs">
                            {labelClassificacao(v.parecer?.classificacaoFinalConservacao as string) !==
                            "—"
                              ? labelClassificacao(
                                  v.parecer?.classificacaoFinalConservacao as string,
                                )
                              : classificacaoPorNota(v.nota_media)}
                          </td>
                          <td className="px-3 py-2 text-xs">
                            {labelPadrao(v.parecer?.padraoConstrutivoGeral as string)}
                          </td>
                          <td className="px-3 py-2 text-xs">
                            {v.status === "concluida" ? "Concluída" : "Rascunho"}
                          </td>
                          <td className="px-3 py-2">
                            <button
                              type="button"
                              onClick={() => {
                                setEdicao(v);
                                setAba("form");
                              }}
                              className="rounded border border-border px-2 py-1 text-xs font-semibold hover:bg-accent"
                            >
                              Editar
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}

        <section className="rounded-xl border border-border bg-muted/40 p-4 text-xs text-muted-foreground">
          <p className="mb-1 font-semibold text-foreground">API pública de cadastro</p>
          <p>GET/POST /api/public/cadastro/unidades — dados cadastrais das unidades.</p>
          <p>GET/POST /api/public/cadastro/vistorias — laudos de vistoria técnica.</p>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
