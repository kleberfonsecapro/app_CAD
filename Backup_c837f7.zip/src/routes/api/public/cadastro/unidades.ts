import { createFileRoute } from "@tanstack/react-router";
import { cadastroSchema } from "@/lib/cadastro-validation";


/**
 * API pública de cadastro das unidades educacionais.
 * GET  /api/public/cadastro/unidades       — lista os cadastros
 * POST /api/public/cadastro/unidades       — cria/atualiza o cadastro de uma unidade
 */
export const Route = createFileRoute("/api/public/cadastro/unidades")({
  server: {
    handlers: {
      GET: async () => {
        const { createPublicSupabase, jsonResponse } = await import(
          "@/lib/supabase-public.server"
        );
        const supabase = createPublicSupabase();
        const { data, error } = await supabase
          .from("unidades_cadastro")
          .select("*")
          .order("updated_at", { ascending: false });
        if (error) return jsonResponse({ error: "Falha ao consultar cadastros" }, 500);
        return jsonResponse({ total: data?.length ?? 0, data });
      },
      POST: async ({ request }) => {
        const { createPublicSupabase, jsonResponse } = await import(
          "@/lib/supabase-public.server"
        );
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return jsonResponse({ error: "JSON inválido" }, 400);
        }
        const parsed = cadastroSchema.safeParse(body);
        if (!parsed.success) {
          return jsonResponse(
            { error: "Dados inválidos", detalhes: parsed.error.flatten().fieldErrors },
            400,
          );
        }
        const supabase = createPublicSupabase();
        const { data, error } = await supabase
          .from("unidades_cadastro")
          .upsert(parsed.data, { onConflict: "unidade_id" })
          .select()
          .single();
        if (error) return jsonResponse({ error: "Falha ao salvar cadastro" }, 500);
        return jsonResponse({ ok: true, data }, 200);
      },
    },
  },
});
