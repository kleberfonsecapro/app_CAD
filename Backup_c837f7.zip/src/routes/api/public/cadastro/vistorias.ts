import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { cadastroSchema } from "@/lib/cadastro-validation";

const jsonObj = z.record(z.any());

const vistoriaSchema = z.object({
  id: z.string().uuid().optional(),
  unidade_id: z.string().trim().min(2).max(200),
  unidade_nome: z.string().trim().min(2).max(200),
  data_vistoria: z.string().trim().max(20).optional().nullable(),
  imovel_proprio_alugado: z.enum(["proprio", "alugado"]).optional().nullable(),
  responsavel: z.string().trim().max(160).optional().nullable(),
  uso_tipo: z.string().trim().max(40).optional().nullable(),
  estrutural: jsonObj.optional(),
  fotografico: jsonObj.optional(),
  entorno: jsonObj.optional(),
  parecer: jsonObj.optional(),
  etapa: z.number().int().min(1).max(6).optional(),
  status: z.enum(["rascunho", "concluida"]).optional(),
  /** Bloco cadastral opcional — mesmos campos da aba Cadastro & Vistoria. */
  cadastro: cadastroSchema.partial({ unidade_id: true, nome: true }).optional(),
});

function media(estrutural: Record<string, unknown> | undefined) {
  if (!estrutural) return null;
  const notas = Object.entries(estrutural)
    .filter(([k, v]) => k.endsWith("Nota") && typeof v === "number")
    .map(([, v]) => v as number);
  if (!notas.length) return null;
  return Math.round((notas.reduce((a, b) => a + b, 0) / notas.length) * 100) / 100;
}

/**
 * API pública de vistorias/atualizações cadastrais.
 * GET  /api/public/cadastro/vistorias                 — lista as vistorias
 * GET  /api/public/cadastro/vistorias?unidade=NOME    — filtra por unidade (inclui o cadastro)
 * POST /api/public/cadastro/vistorias                 — cria (sem id) ou atualiza (com id)
 */
export const Route = createFileRoute("/api/public/cadastro/vistorias")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { createPublicSupabase, jsonResponse } = await import(
          "@/lib/supabase-public.server"
        );
        const unidade = new URL(request.url).searchParams.get("unidade");
        const supabase = createPublicSupabase();
        let query = supabase
          .from("vistorias")
          .select("*")
          .order("updated_at", { ascending: false })
          .limit(500);
        if (unidade) query = query.eq("unidade_id", unidade.slice(0, 200));
        const { data, error } = await query;
        if (error) return jsonResponse({ error: "Falha ao consultar vistorias" }, 500);
        if (unidade) {
          const { data: cadastro } = await supabase
            .from("unidades_cadastro")
            .select("*")
            .eq("unidade_id", unidade.slice(0, 200))
            .maybeSingle();
          return jsonResponse({ total: data?.length ?? 0, data, cadastro: cadastro ?? null });
        }
        return jsonResponse({ total: data?.length ?? 0, data });
      },
      POST: async ({ request }) => {
        const { createPublicSupabase, jsonResponse } = await import(
          "@/lib/supabase-public.server"
        );
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return jsonResponse({ error: "JSON inválido" }, 400);
        }
        const parsed = vistoriaSchema.safeParse(body);
        if (!parsed.success) {
          return jsonResponse(
            { error: "Dados inválidos", detalhes: parsed.error.flatten().fieldErrors },
            400,
          );
        }
        const { id, cadastro, ...rest } = parsed.data;
        const payload = { ...rest, nota_media: media(rest.estrutural) };
        const supabase = createPublicSupabase();

        // Espelha o cadastro da unidade (salas, CADs e alunos CAD por turno)
        if (cadastro) {
          const { error: erroCadastro } = await supabase
            .from("unidades_cadastro")
            .upsert(
              {
                ...cadastro,
                unidade_id: cadastro.unidade_id ?? rest.unidade_id,
                nome: cadastro.nome ?? rest.unidade_nome,
              },
              { onConflict: "unidade_id" },
            );
          if (erroCadastro)
            return jsonResponse({ error: "Falha ao salvar cadastro da unidade" }, 500);
        }

        const query = id
          ? supabase.from("vistorias").update(payload).eq("id", id).select().single()
          : supabase.from("vistorias").insert(payload).select().single();
        const { data, error } = await query;
        if (error) return jsonResponse({ error: "Falha ao salvar vistoria" }, 500);
        return jsonResponse({ ok: true, data });
      },
    },
  },
});
