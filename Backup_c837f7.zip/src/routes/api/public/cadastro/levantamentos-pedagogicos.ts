import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const jsonObj = z.record(z.any());

const levantamentoSchema = z.object({
  id: z.string().uuid().optional(),
  unidade_id: z.string().trim().min(2).max(200),
  unidade_nome: z.string().trim().min(2).max(200),
  data_levantamento: z.string().trim().max(20).optional().nullable(),
  responsavel: z.string().trim().max(160).optional().nullable(),
  dados_pedagogicos: jsonObj.optional(),
  etapa: z.number().int().min(1).max(6).optional(),
  status: z.enum(["rascunho", "concluida"]).optional(),
});

export const Route = createFileRoute("/api/public/cadastro/levantamentos-pedagogicos")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { createPublicSupabase, jsonResponse } = await import(
          "@/lib/supabase-public.server"
        );
        const unidade = new URL(request.url).searchParams.get("unidade");
        const supabase = createPublicSupabase();
        let query = supabase
          .from("levantamentos_pedagogicos" as any)
          .select("*")
          .order("updated_at", { ascending: false })
          .limit(500);
        if (unidade) query = query.eq("unidade_id", unidade.slice(0, 200));
        const { data, error } = await query;
        if (error) return jsonResponse({ error: "Falha ao consultar levantamentos" }, 500);
        return jsonResponse({ total: data?.length ?? 0, data });
      },
      POST: async ({ request }) => {
        const { createPublicSupabase, jsonResponse } = await import(
          "@/lib/supabase-public.server"
        );
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return jsonResponse({ error: "JSON inválido" }, 400);
        }
        const parsed = levantamentoSchema.safeParse(body);
        if (!parsed.success) {
          return jsonResponse(
            { error: "Dados inválidos", detalhes: parsed.error.flatten().fieldErrors },
            400,
          );
        }
        const { id, ...payload } = parsed.data;
        const supabase = createPublicSupabase();

        const query = id
          ? supabase.from("levantamentos_pedagogicos" as any).update(payload).eq("id", id).select().single()
          : supabase.from("levantamentos_pedagogicos" as any).insert(payload).select().single();
        const { data, error } = await query;
        if (error) return jsonResponse({ error: "Falha ao salvar levantamento" }, 500);
        return jsonResponse({ ok: true, data });
      },
    },
  },
});
