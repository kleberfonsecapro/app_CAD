import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import LevantamentoPedagogicoForm from "@/components/pedagogico/LevantamentoPedagogicoForm";
// Pesquisa de CAD por nome — mesmo componente usado no módulo Cadastro CADs
// (aba Cadastro Profissionais). Aqui entra apenas para VISUALIZAÇÃO.
import ConsultaCADs from "@/components/cadastro/ConsultaCADs";
import unidadesData from "@/data/unidades.json";
import type { Unidade } from "@/types/unidade";
import logoAsset from "@/assets/pmc-logo.png.asset.json";
import { Search, FileBarChart } from "lucide-react";
import RelatorioReferenciaCruzada from "@/components/pedagogico/RelatorioReferenciaCruzada";
import { verificarSenhaPedagogico } from "@/lib/pedagogico/acesso.functions";
import {
  listarCadastros,
  listarLevantamentosPedagogicos,
  type CadastroUnidade,
  type LevantamentoPedagogico,
} from "@/lib/cadastro-api";

const UNIDADES = unidadesData as Unidade[];

export const Route = createFileRoute("/levantamento-pedagogico")({
  head: () => ({
    meta: [
      { title: "Levantamento Pedagógico (Mobile) | PMC-MCEDU-CAD" },
      {
        name: "description",
        content:
          "Aplicativo web para levantamento pedagógico das unidades educacionais de Cuiabá.",
      },
      { property: "og:title", content: "Levantamento Pedagógico | PMC-MCEDU-CAD" },
      { property: "og:type", content: "website" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#0b6b3a" },
    ],
  }),
  component: LevantamentoPedagogicoPage,
});

function LevantamentoPedagogicoPage() {
  const [liberado, setLiberado] = useState(false);
  useEffect(() => {
    if (sessionStorage.getItem("pedagogico-acesso") === "1") setLiberado(true);
  }, []);
  if (!liberado) return <TelaSenha onOk={() => setLiberado(true)} />;
  return <ConteudoPedagogico />;
}

function TelaSenha({ onOk }: { onOk: () => void }) {
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [enviando, setEnviando] = useState(false);
  async function entrar(e: React.FormEvent) {
    e.preventDefault();
    setEnviando(true);
    setErro(null);
    try {
      const r = await verificarSenhaPedagogico({ data: { senha } });
      if (r.ok) {
        sessionStorage.setItem("pedagogico-acesso", "1");
        onOk();
      } else setErro("Senha incorreta.");
    } catch {
      setErro("Não foi possível verificar a senha. Tente novamente.");
    } finally {
      setEnviando(false);
    }
  }
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <form onSubmit={entrar} className="w-full max-w-sm space-y-4 rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <img src={logoAsset.url} alt="Prefeitura de Cuiabá" className="h-10 w-auto" />
          <div>
            <p className="text-base font-bold">Módulo Pedagógico</p>
            <p className="text-xs text-muted-foreground">Acesso restrito — informe a senha</p>
          </div>
        </div>
        <input
          type="password"
          autoFocus
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
          placeholder="Senha de acesso"
          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
        />
        {erro && <p className="text-sm text-destructive">{erro}</p>}
        <button
          type="submit"
          disabled={enviando || !senha}
          className="w-full rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
        >
          {enviando ? "Verificando..." : "Entrar"}
        </button>
      </form>
    </div>
  );
}

function ConteudoPedagogico() {
  const [cadastros, setCadastros] = useState<CadastroUnidade[]>([]);
  const [levantamentos, setLevantamentos] = useState<LevantamentoPedagogico[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [modo, setModo] = useState<"lista" | "form" | "pesquisa" | "relatorios">("form");
  const [edicao, setEdicao] = useState<LevantamentoPedagogico | null>(null);

  async function carregar() {
    setCarregando(true);
    try {
      const [c, l] = await Promise.all([listarCadastros(), listarLevantamentosPedagogicos()]);
      setCadastros(c);
      setLevantamentos(l);
      setErro(null);
    } catch {
      setErro("Sem conexão com o servidor. Verifique a internet e tente novamente.");
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregar();
  }, []);

  const unidadesOrdenadas = useMemo(
    () => [...UNIDADES].sort((a, b) => a.unidade.localeCompare(b.unidade, "pt-BR")),
    [],
  );

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-20 border-b border-border bg-primary text-primary-foreground">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3">
          <img src={logoAsset.url} alt="Prefeitura de Cuiabá" className="h-9 w-auto" />
          <div className="min-w-0">
            <p className="truncate text-sm font-bold leading-tight">Levantamento Pedagógico</p>
            <p className="truncate text-[11px] opacity-80">PMC-MCEDU-CAD · qualidade educacional</p>
          </div>
        </div>
      </header>

      <div className="sticky top-[60px] z-10 border-b border-border bg-background/95 backdrop-blur">
        <div
          className={`mx-auto flex w-full gap-2 px-4 py-2 ${
            modo === "pesquisa" || modo === "relatorios" ? "max-w-7xl" : "max-w-3xl"
          }`}
        >
          <button
            type="button"
            onClick={() => {
              setEdicao(null);
              setModo("form");
            }}
            className={`flex-1 rounded-md px-3 py-2 text-sm font-semibold ${
              modo === "form" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            Novo Levantamento
          </button>
          <button
            type="button"
            onClick={() => setModo("lista")}
            className={`flex-1 rounded-md px-3 py-2 text-sm font-semibold ${
              modo === "lista" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            Enviados ({levantamentos.length})
          </button>
          <button
            type="button"
            onClick={() => setModo("pesquisa")}
            className={`flex flex-1 items-center justify-center gap-2 rounded-md px-3 py-2 text-sm font-semibold transition-colors ${
              modo === "pesquisa" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            <Search className="h-4 w-4" />
            Pesquisa
          </button>
          <button
            type="button"
            onClick={() => setModo("relatorios")}
            className={`flex flex-1 items-center justify-center gap-2 rounded-md px-3 py-2 text-sm font-semibold transition-colors ${
              modo === "relatorios" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            <FileBarChart className="h-4 w-4" />
            Relatórios
          </button>
        </div>
      </div>

      <main
        className={`mx-auto w-full flex-1 space-y-4 px-4 py-4 pb-24 ${
          modo === "pesquisa" || modo === "relatorios" ? "max-w-7xl" : "max-w-3xl"
        }`}
      >
        {erro && (
          <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{erro}</p>
        )}

        {modo === "pesquisa" ? (
          <section className="space-y-3">
            <header className="rounded-xl border border-border bg-card p-4">
              <h2 className="flex items-center gap-2 text-base font-bold text-foreground">
                <Search className="h-4 w-4 text-primary" />
                Pesquisa de CAD por nome
              </h2>
              <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
                Mesma consulta do módulo Cadastro CADs (aba Cadastro Profissionais): busque pelo
                nome do profissional e abra um registro para ver a escola, o ano/série, a turma, o
                período, os alunos vinculados e o responsável técnico do levantamento.
              </p>
              <p className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-[11px] font-semibold text-primary">
                <Search className="h-3.5 w-3.5" />
                Modo somente visualização — nenhum cadastro é criado ou alterado por aqui
              </p>
            </header>
            <ConsultaCADs />
          </section>
        ) : carregando ? (
          <p className="text-sm text-muted-foreground">Carregando dados...</p>
        ) : modo === "relatorios" ? (
          <div className="space-y-3">
            <button
              type="button"
              onClick={async () => {
                const t = toast.loading("Gerando planilha Excel...");
                try {
                  const { exportarExcelCompleto } = await import("@/components/pedagogico/exportar-excel");
                  await exportarExcelCompleto(levantamentos, cadastros);
                  toast.success("Planilha gerada.", { id: t });
                } catch {
                  toast.error("Não foi possível gerar a planilha.", { id: t });
                }
              }}
              className="w-full rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground"
            >
              Exportar Excel completo (CADs, alunos, turmas e escolas)
            </button>
            <RelatorioReferenciaCruzada levantamentos={levantamentos} onChange={carregar} />
          </div>
        ) : false ? (
          <p className="text-sm text-muted-foreground">Carregando dados...</p>
        ) : modo === "form" ? (
          <LevantamentoPedagogicoForm
            unidades={unidadesOrdenadas}
            cadastros={cadastros}
            levantamentoInicial={edicao}
            onSaved={() => {
              carregar();
              setEdicao(null);
              setModo("lista");
            }}
            onCancel={() => {
              setEdicao(null);
              setModo("lista");
            }}
          />
        ) : levantamentos.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Nenhum levantamento enviado ainda. Toque em “Novo Levantamento”.
          </p>
        ) : (
          <ul className="space-y-2">
            {levantamentos.map((l) => (
              <li
                key={l.id}
                className="rounded-xl border border-border bg-card p-3 active:bg-accent"
              >
                <button
                  type="button"
                  className="w-full text-left"
                  onClick={() => {
                    setEdicao(l);
                    setModo("form");
                  }}
                >
                  <p className="text-sm font-semibold">{l.unidade_nome}</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">
                    {l.data_levantamento ?? "sem data"} ·{" "}
                    {l.status === "concluida" ? "Concluído" : "Rascunho"}
                  </p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </main>

      <footer className="border-t border-border bg-muted/40 py-3 text-center text-[11px] text-muted-foreground">
        Integrado à API /api/public/cadastro/levantamentos-pedagogicos
      </footer>
    </div>
  );
}
