import { createFileRoute } from "@tanstack/react-router";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import BICads from "@/components/BICads";
import unidadesData from "@/data/unidades.json";
import type { Unidade } from "@/types/unidade";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CadastroIndividualCAD from "@/components/cadastro/CadastroIndividualCAD";
// Consulta de CAD por nome — componente em src/components/cadastro/ConsultaCADs.tsx
import ConsultaCADs from "@/components/cadastro/ConsultaCADs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, UserPlus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { listarCadastros } from "@/lib/cadastro-api";
import { useState } from "react";

const UNIDADES = unidadesData as Unidade[];

export const Route = createFileRoute("/cadastro-cads")({
  head: () => ({
    meta: [
      { title: "Gestão e Cadastro de CADs | PMC-MCEDU-CAD" },
      {
        name: "description",
        content: "Gestão centralizada de Cuidadores de Alunos com Deficiência: cadastro, BI com indicadores por zoneamento, escola e carga horária.",
      },
      { property: "og:title", content: "Gestão e Cadastro de CADs | PMC-MCEDU-CAD" },
      { property: "og:description", content: "Gestão centralizada de Cuidadores de Alunos com Deficiência: cadastro, BI com indicadores por zoneamento, escola e carga horária." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CadastroCadsPage,
});

function CadastroCadsPage() {
  const [selectedUnidadeId, setSelectedUnidadeId] = useState<string>("");
  
  const { data: cadastros = [] } = useQuery({
    queryKey: ["cadastros-unidades"],
    queryFn: listarCadastros,
    staleTime: 0, // Garante que pegamos dados novos após a importação
  });

  const unidadesOrdenadas = [...UNIDADES].sort((a, b) => a.unidade.localeCompare(b.unidade, "pt-BR"));

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <header className="mb-8">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-primary/10 p-2 text-primary">
              <Users size={24} />
            </div>
            <div>
              <h1 className="pmc-titulo text-3xl">Gestão de CADs</h1>
              <p className="text-muted-foreground">
                Módulo centralizado para cadastro, atualização e análise de profissionais.
              </p>
            </div>
          </div>
        </header>

        <Tabs defaultValue="bi" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
            <TabsTrigger value="bi">Business Intelligence (BI)</TabsTrigger>
            <TabsTrigger value="cadastro-individual">
              <UserPlus className="w-4 h-4 mr-2" />
              Cadastro Profissionais
            </TabsTrigger>
          </TabsList>

          <TabsContent value="bi" className="space-y-6">
            <BICads unidades={UNIDADES} />
          </TabsContent>

          <TabsContent value="cadastro-individual" className="space-y-6">
            <ConsultaCADs />
            <Card>
              <CardHeader>
                <CardTitle>Cadastro Individual de Profissionais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="max-w-md">
                  <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1 block">
                    Selecione a Unidade para Gerenciar
                  </label>
                  <select
                    className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                    value={selectedUnidadeId}
                    onChange={(e) => setSelectedUnidadeId(e.target.value)}
                  >
                    <option value="">Selecione uma unidade...</option>
                    <option value="TODOS">TODAS AS UNIDADES</option>
                    {unidadesOrdenadas.map((u) => (
                      <option key={u.unidade} value={u.unidade}>
                        {u.unidade}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedUnidadeId ? (
                  <CadastroIndividualCAD unidadeId={selectedUnidadeId} />
                ) : (
                  <div className="flex h-32 items-center justify-center text-muted-foreground italic border-2 border-dashed rounded-lg">
                    Selecione uma unidade acima para visualizar e gerenciar os profissionais.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <SiteFooter />
    </div>
  );
}
