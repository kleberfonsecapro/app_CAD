import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import cidData from "@/data/cid10.json";
import { Search } from "lucide-react";

export const Route = createFileRoute("/cids")({
  head: () => ({
    meta: [
      { title: "Base CID-10 | PMC-MCEDU-CAD" },
      {
        name: "description",
        content: "Consulta completa da base CID-10 utilizada na rede municipal de educação.",
      },
    ],
  }),
  component: CIDsPage,
});

function CIDsPage() {
  const [busca, setBusca] = useState("");

  const filtrados = useMemo(() => {
    const termo = busca.toLowerCase().trim();
    if (!termo) return cidData;
    return cidData.filter(
      (c) =>
        c.codigo.toLowerCase().includes(termo) ||
        c.descricao.toLowerCase().includes(termo)
    );
  }, [busca]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-7xl flex-1 space-y-6 px-4 py-6 sm:px-6 lg:px-8">
        <header className="space-y-1">
          <h1 className="text-2xl font-bold sm:text-3xl">Base CID-10</h1>
          <p className="text-sm text-muted-foreground">
            Consulta completa da Classificação Internacional de Doenças (CID-10) integrada ao sistema de Educação Especial.
          </p>
        </header>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <input
            className="w-full rounded-md border border-input bg-card pl-9 pr-3 py-2 text-sm text-foreground outline-none focus:border-primary"
            placeholder="Buscar por código ou descrição (ex: F84 ou Autismo)..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>

        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="max-h-[600px] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 z-10 bg-muted/95 backdrop-blur text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-bold w-32">Código</th>
                  <th className="px-4 py-3 font-bold">Descrição</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtrados.map((cid) => (
                  <tr key={cid.codigo} className="hover:bg-accent/50 transition-colors">
                    <td className="px-4 py-3 font-mono font-bold text-primary">{cid.codigo}</td>
                    <td className="px-4 py-3 text-foreground">{cid.descricao}</td>
                  </tr>
                ))}
                {filtrados.length === 0 && (
                  <tr>
                    <td colSpan={2} className="px-4 py-8 text-center text-muted-foreground">
                      Nenhum CID encontrado para "{busca}".
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
