import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import VistoriaForm from "@/components/cadastro/VistoriaForm";
import unidadesData from "@/data/unidades.json";
import type { Unidade } from "@/types/unidade";
import logoAsset from "@/assets/pmc-logo.png.asset.json";
import {
  listarCadastros,
  listarVistorias,
  type CadastroUnidade,
  type Vistoria,
} from "@/lib/cadastro-api";

const UNIDADES = unidadesData as Unidade[];

export const Route = createFileRoute("/vistoria")({
  head: () => ({
    meta: [
      { title: "Lançamento Predial (Mobile) | PMC-MCEDU-CAD" },
      {
        name: "description",
        content:
          "Aplicativo web para lançamento em campo de vistorias técnicas das unidades educacionais de Cuiabá, integrado à API de cadastro.",
      },
      { property: "og:title", content: "Lançamento Predial | PMC-MCEDU-CAD" },
      {
        property: "og:description",
        content:
          "Registre vistorias técnicas direto do celular: dados cadastrais, estrutura, fotos, entorno e parecer.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#0b6b3a" },
    ],
  }),
  component: VistoriaMobilePage,
});

function VistoriaMobilePage() {
  const [cadastros, setCadastros] = useState<CadastroUnidade[]>([]);
  const [vistorias, setVistorias] = useState<Vistoria[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [modo, setModo] = useState<"lista" | "form">("form");
  const [edicao, setEdicao] = useState<Vistoria | null>(null);

  async function carregar() {
    setCarregando(true);
    try {
      const [c, v] = await Promise.all([listarCadastros(), listarVistorias()]);
      setCadastros(c);
      setVistorias(v);
      setErro(null);
    } catch {
      setErro("Sem conexão com o servidor. Verifique a internet e tente novamente.");
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregar();
  }, []);

  const unidadesOrdenadas = useMemo(
    () => [...UNIDADES].sort((a, b) => a.unidade.localeCompare(b.unidade, "pt-BR")),
    [],
  );

  const ultimas = useMemo(() => vistorias.slice(0, 30), [vistorias]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-20 border-b border-border bg-primary text-primary-foreground">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3">
          <img src={logoAsset.url} alt="Prefeitura de Cuiabá" className="h-9 w-auto" />
          <div className="min-w-0">
            <p className="truncate text-sm font-bold leading-tight">Levantamento Predial</p>
            <p className="truncate text-[11px] opacity-80">PMC-MCEDU-CAD · atualização cadastral</p>
          </div>
        </div>
      </header>

      <div className="sticky top-[60px] z-10 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex w-full max-w-3xl gap-2 px-4 py-2">
          <button
            type="button"
            onClick={() => {
              setEdicao(null);
              setModo("form");
            }}
            className={`flex-1 rounded-md px-3 py-2 text-sm font-semibold ${
              modo === "form" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            Novo levantamento
          </button>
          <button
            type="button"
            onClick={() => setModo("lista")}
            className={`flex-1 rounded-md px-3 py-2 text-sm font-semibold ${
              modo === "lista" ? "bg-primary text-primary-foreground" : "bg-muted"
            }`}
          >
            Enviados ({vistorias.length})
          </button>
        </div>
      </div>

      <main className="mx-auto w-full max-w-3xl flex-1 space-y-4 px-4 py-4 pb-24">
        {erro && (
          <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{erro}</p>
        )}

        {carregando ? (
          <p className="text-sm text-muted-foreground">Carregando unidades...</p>
        ) : modo === "form" ? (
          <VistoriaForm
            unidades={unidadesOrdenadas}
            cadastros={cadastros}
            vistoriaInicial={edicao}
            onSaved={() => {
              carregar();
              setEdicao(null);
              setModo("lista");
            }}
            onCancel={() => {
              setEdicao(null);
              setModo("lista");
            }}
          />
        ) : ultimas.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Nenhum levantamento enviado ainda. Toque em “Novo levantamento”.
          </p>
        ) : (
          <ul className="space-y-2">
            {ultimas.map((v) => (
              <li
                key={v.id}
                className="rounded-xl border border-border bg-card p-3 active:bg-accent"
              >
                <button
                  type="button"
                  className="w-full text-left"
                  onClick={() => {
                    setEdicao(v);
                    setModo("form");
                  }}
                >
                  <p className="text-sm font-semibold">{v.unidade_nome}</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">
                    {v.data_vistoria ?? "sem data"} ·{" "}
                    {v.status === "concluida" ? "Concluída" : "Rascunho"} · Nota{" "}
                    {v.nota_media ?? "—"}
                  </p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </main>

      <footer className="border-t border-border bg-muted/40 py-3 text-center text-[11px] text-muted-foreground">
        Integrado à API /api/public/cadastro/vistorias
      </footer>
    </div>
  );
}
