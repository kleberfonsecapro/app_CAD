import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import PainelMatriculas from "@/components/matriculas/PainelMatriculas";
import UnidadesMatriculas from "@/components/matriculas/UnidadesMatriculas";
import VagasLivres from "@/components/matriculas/VagasLivres";
import Filantropicas from "@/components/matriculas/Filantropicas";
import Estudos from "@/components/matriculas/Estudos";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import MapaDistorcao from "@/components/MapaDistorcao";

const TITULO = "Matrículas RME 2026 | PMC-MCEDU-CAD";
const DESC =
  "Painel de matrículas na Rede Municipal de Educação de Cuiabá em 2026: evolução diária, série histórica, matrículas por unidade, vagas livres e instituições filantrópicas conveniadas.";

export const Route = createFileRoute("/matriculas")({
  head: () => ({
    meta: [
      { title: TITULO },
      { name: "description", content: DESC },
      { property: "og:title", content: TITULO },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MatriculasPage,
});

const ABAS = [
  { key: "painel", label: "Painel diário" },
  { key: "unidades", label: "Por unidade" },
  { key: "vagas", label: "Vagas livres" },
  { key: "filantropicas", label: "Filantrópicas" },
  { key: "tecnica", label: "Análise técnica CAD" },
  { key: "estudos", label: "Estudos" },
] as const;

function MatriculasPage() {
  const [aba, setAba] = useState<(typeof ABAS)[number]["key"]>("painel");

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="border-b border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 pt-5 sm:px-6 lg:px-8">
          <div className="pmc-secao">
            <h1 className="pmc-titulo text-xl leading-tight sm:text-2xl">
              Painel de Matrículas na Rede Municipal de Educação de Cuiabá — 2026
            </h1>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Coordenadoria de Microplanejamento Educacional · Secretaria Municipal de Educação
            </p>
          </div>
        </div>
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 sm:px-6 lg:px-8">
          {ABAS.map((a) => (
            <button
              key={a.key}
              onClick={() => setAba(a.key)}
              className={`whitespace-nowrap border-b-2 px-4 py-2 text-sm font-medium transition-colors ${
                aba === a.key
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {a.label}
            </button>
          ))}
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {aba === "painel" && <PainelMatriculas />}
        {aba === "unidades" && <UnidadesMatriculas />}
        {aba === "vagas" && <VagasLivres />}
        {aba === "filantropicas" && <Filantropicas />}
        {aba === "tecnica" && <MapaDistorcao />}
        {aba === "estudos" && <Estudos />}
      </main>
      <SiteFooter />
    </div>
  );
}
