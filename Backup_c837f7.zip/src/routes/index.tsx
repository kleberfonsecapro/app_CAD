import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import unidadesData from "@/data/unidades.json";
import type { Unidade } from "@/types/unidade";
import { enderecoCompleto } from "@/lib/endereco";
import { construirClusters } from "@/lib/triangulacao";
import TriangulacaoPanel from "@/components/TriangulacaoPanel";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import FichaTecnica from "@/components/FichaTecnica";
import MapaDistorcao from "@/components/MapaDistorcao";
import PainelCriticidade from "@/components/PainelCriticidade";
import PainelAtualizacoes from "@/components/site/PainelAtualizacoes";
import PainelFluxoMatriculas from "@/components/PainelFluxoMatriculas";
import ConfiguracaoPadroes from "@/components/ConfiguracaoPadroes";
import { COR_PADRAO, faixaPorRazao, useConfigPadroes } from "@/lib/configPadroes";
import { construirCriticidade, resumirCriticidade } from "@/lib/criticidade";
import { fetchUnidades as fetchMatriculasUnidades } from "@/lib/matriculas";
import {
  COR_TENDENCIA,
  construirFluxo,
  resumirFluxo,
  segmentoDaUnidade,
  type Segmento,
} from "@/lib/matriculaFluxo";

const HeatMap = lazy(() => import("@/components/HeatMap"));
const UNIDADES = unidadesData as Unidade[];



const METRICS = [
  { key: "estudantes", label: "Estudantes atendidos" },
  { key: "tea", label: "Casos TEA" },
  { key: "deficiencia", label: "Deficiência" },
  { key: "transtorno", label: "Transtornos" },
  { key: "semLaudo", label: "Sem laudo" },
  { key: "suporte3", label: "TEA nível 3" },
  { key: "razao", label: "Estudantes por CAD" },
] as const;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PMC-MCEDU-CAD | Mapa de Calor do Atendimento Especializado" },
      {
        name: "description",
        content:
          "Painel de decisão da Secretaria Municipal de Educação: mapa de calor, indicadores e ranking das unidades educacionais por demanda de Cuidadores de Alunos com Deficiência.",
      },
      { property: "og:title", content: "PMC-MCEDU-CAD | Mapa de Calor do Atendimento Especializado" },
      {
        property: "og:description",
        content: "Painel de decisão da Secretaria Municipal de Educação: mapa de calor, indicadores e ranking das unidades educacionais por demanda de Cuidadores de Alunos com Deficiência.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

function Kpi({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 text-3xl font-semibold tabular-nums text-foreground">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function Dashboard() {
  const [metric, setMetric] = useState<(typeof METRICS)[number]["key"]>("estudantes");
  const [regiao, setRegiao] = useState("Todas");
  const [busca, setBusca] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [raio, setRaio] = useState(1000);
  const [cluster, setCluster] = useState<string | null>(null);
  const [modoCriticidade, setModoCriticidade] = useState(true);
  const [modoFluxo, setModoFluxo] = useState(false);
  const [modoPadrao, setModoPadrao] = useState(true);
  const { config, salvar: salvarConfig, restaurar: restaurarConfig } = useConfigPadroes();
  const [segmentos, setSegmentos] = useState<Record<Segmento, boolean>>({
    Creche: true,
    Escola: true,
  });

  const { data: matriculasUnidades, isLoading: carregandoMatriculas } = useQuery({
    queryKey: ["mat-unidades"],
    queryFn: fetchMatriculasUnidades,
    staleTime: 300000,
  });

  const regioes = useMemo(
    () => ["Todas", ...Array.from(new Set(UNIDADES.map((u) => u.regiao))).sort()],
    [],
  );

  const filtradas = useMemo(
    () =>
      UNIDADES.filter(
        (u) =>
          (regiao === "Todas" || u.regiao === regiao) &&
          segmentos[segmentoDaUnidade(u.unidade)] &&
          u.unidade.toLowerCase().includes(busca.toLowerCase().trim()),
      ),
    [regiao, busca, segmentos],
  );

  const fluxo = useMemo(
    () => construirFluxo(filtradas, matriculasUnidades),
    [filtradas, matriculasUnidades],
  );
  const resumoFluxo = useMemo(() => resumirFluxo(filtradas, fluxo), [filtradas, fluxo]);


  const tot = useMemo(() => {
    const sum = (k: keyof Unidade) => filtradas.reduce((a, u) => a + (Number(u[k]) || 0), 0);
    const est = sum("estudantes");
    const cads = sum("cuidadores");
    return {
      est,
      cads,
      unidades: filtradas.length,
      tea: sum("tea"),
      semLaudo: sum("semLaudo"),
      suporte3: sum("suporte3"),
      razao: cads ? (est / cads).toFixed(2) : "0",
    };
  }, [filtradas]);

  const ranking = useMemo(
    () => [...filtradas].sort((a, b) => (Number(b[metric]) || 0) - (Number(a[metric]) || 0)),
    [filtradas, metric],
  );

  const clusters = useMemo(() => construirClusters(filtradas, raio), [filtradas, raio]);
  const clusterAtual = clusters.find((c) => c.id === cluster) ?? null;

  const criticidade = useMemo(() => construirCriticidade(filtradas, raio), [filtradas, raio]);
  const resumoCrit = useMemo(() => resumirCriticidade(criticidade), [criticidade]);

  const det = UNIDADES.find((u) => u.unidade === selected);


  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <header className="mb-6 grid gap-4 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
        <div className="pmc-secao min-w-0">
          <p className="text-[11px] uppercase tracking-[0.25em] text-secondary">
            Painel de gestão · Educação Especial
          </p>
          <h1 className="pmc-titulo text-2xl leading-tight lg:text-3xl">
            PMC-MCEDU-CAD — Mapa de Calor do Atendimento Especializado
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Consolidação da 2ª Etapa (Norte, Sul, Leste, Oeste e Campo) para levantamento de
            necessidades e tomada de decisão.
          </p>
        </div>
        <div className="grid gap-2 sm:grid-cols-3 lg:flex lg:flex-wrap">
          <input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar unidade educacional…"
            className="min-w-0 rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground outline-none focus:border-ring lg:w-64"
          />
          <select
            value={regiao}
            onChange={(e) => setRegiao(e.target.value)}
            className="min-w-0 rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground"
          >
            {regioes.map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
          <select
            value={metric}
            onChange={(e) => setMetric(e.target.value as typeof metric)}
            className="min-w-0 rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground"
          >
            {METRICS.map((m) => (
              <option key={m.key} value={m.key}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
      </header>

      <section className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-6">
        <Kpi label="Unidades" value={String(tot.unidades)} />
        <Kpi label="Estudantes" value={tot.est.toLocaleString("pt-BR")} />
        <Kpi label="Cuidadores (CAD)" value={tot.cads.toLocaleString("pt-BR")} />
        <Kpi label="Estudantes por CAD" value={tot.razao} hint="Indicador de sobrecarga" />
        <Kpi label="Casos TEA" value={tot.tea.toLocaleString("pt-BR")} />
        <Kpi label="Sem laudo" value={tot.semLaudo.toLocaleString("pt-BR")} hint="Demanda de avaliação" />
      </section>

      <ConfiguracaoPadroes config={config} onSalvar={salvarConfig} onRestaurar={restaurarConfig} />

      <section className="mb-3 flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card p-3">
        <label className="flex items-center gap-2 text-sm font-medium text-foreground">
          <input
            type="checkbox"
            checked={modoPadrao}
            onChange={(e) => setModoPadrao(e.target.checked)}
            className="h-4 w-4 accent-primary"
          />
          Modo padrão técnico (cor pela razão alunos/CAD · bola pelo nº de CADs)
        </label>
        {modoPadrao && !modoFluxo && (
          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
            {(
              [
                ["vermelho", `Até ${config.limiteVermelho} alunos/CAD`],
                ["amarelo", `${config.limiteVermelho} a ${config.limiteAmarelo} alunos/CAD`],
                ["verde", `Acima de ${config.limiteAmarelo} alunos/CAD`],
              ] as const
            ).map(([faixa, txt]) => (
              <span key={faixa} className="flex items-center gap-1.5">
                <span
                  className="inline-block h-3 w-3 rounded-full"
                  style={{ background: COR_PADRAO[faixa] }}
                />
                {txt} ({filtradas.filter((u) => faixaPorRazao(u.razao, config) === faixa).length})
              </span>
            ))}
            <span>Referência nacional: {config.mediaNacional}:1 · número no centro = CADs</span>
          </div>
        )}
      </section>

      <section className="mb-3 flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card p-3">
        <label className="flex items-center gap-2 text-sm font-medium text-foreground">
          <input
            type="checkbox"
            checked={modoCriticidade}
            onChange={(e) => setModoCriticidade(e.target.checked)}
            className="h-4 w-4 accent-primary"
          />
          Modo criticidade CAD (excedentes em destaque)
        </label>
        {modoCriticidade && (
          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded-full bg-[hsl(280,70%,50%)]" /> Excedente
              crítico ({resumoCrit.excedentes})
            </span>
            <span className="flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded-full bg-[hsl(0,80%,48%)]" /> Déficit
              crítico ({resumoCrit.deficitCritico})
            </span>
            <span className="flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded-full bg-[hsl(32,92%,50%)]" /> Déficit (
              {resumoCrit.deficit})
            </span>
            <span className="flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded-full bg-[hsl(150,60%,38%)]" /> Adequado (
              {resumoCrit.adequadas})
            </span>
            <span>Linhas roxas = remanejamento sugerido em até {raio} m</span>
          </div>
        )}
        <span className="flex items-center gap-1.5 text-xs font-semibold text-[hsl(8,92%,46%)]">
          <span className="inline-block h-3 w-3 rounded-full bg-[hsl(8,92%,46%)] ring-4 ring-[hsl(8,92%,46%)]/25" />
          🔥 20% que mais necessitam de intervenção ({resumoCrit.prioritarias})
        </span>

        <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="inline-block h-3 w-3 rounded-full border border-dashed border-[hsl(215,15%,45%)] bg-[hsl(215,15%,60%)]/30" />
          Unidade sem cadastro de CAD ({filtradas.filter((u) => u.semCadastro).length})
        </span>
      </section>

      <section className="mb-3 flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card p-3">
        <label className="flex items-center gap-2 text-sm font-medium text-foreground">
          <input
            type="checkbox"
            checked={modoFluxo}
            onChange={(e) => setModoFluxo(e.target.checked)}
            className="h-4 w-4 accent-primary"
          />
          Flag de matrículas 2020–2026 (crescimento × retração)
        </label>

        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Etapa:
        </span>
        {(["Creche", "Escola"] as Segmento[]).map((s) => (
          <label key={s} className="flex items-center gap-2 text-sm text-foreground">
            <input
              type="checkbox"
              checked={segmentos[s]}
              onChange={(e) => setSegmentos((p) => ({ ...p, [s]: e.target.checked }))}
              className="h-4 w-4 accent-secondary"
            />
            {s === "Creche" ? "Creches (CMEI / CEIC / CEEI)" : "Escolas (EMEB / EMEBC)"} (
            {UNIDADES.filter((u) => segmentoDaUnidade(u.unidade) === s).length})
          </label>
        ))}

        {modoFluxo && (
          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
            {(
              ["Crescimento forte", "Crescimento", "Estável", "Retração", "Retração forte"] as const
            ).map((c) => (
              <span key={c} className="flex items-center gap-1.5">
                <span
                  className="inline-block h-3 w-3 rounded-full"
                  style={{ background: COR_TENDENCIA[c] }}
                />
                {c} ({[...fluxo.values()].filter((f) => f.classe === c).length})
              </span>
            ))}
            <span>Tamanho do círculo = variação absoluta · traço pontilhado = creche</span>
          </div>
        )}
      </section>


      <section className="grid gap-4 lg:grid-cols-[2fr_1fr]">
        <div className="h-[420px] overflow-hidden rounded-xl border border-border bg-card sm:h-[560px]">
          <ClientOnly fallback={<div className="p-6 text-sm text-muted-foreground">Carregando mapa…</div>}>
            <Suspense fallback={<div className="p-6 text-sm text-muted-foreground">Carregando mapa…</div>}>
              <HeatMap
                unidades={filtradas}
                metric={metric}
                metricLabel={METRICS.find((m) => m.key === metric)?.label ?? ""}
                selected={selected}
                onSelect={setSelected}
                arestas={clusterAtual?.arestas ?? []}
                focoCluster={cluster}
                criticidade={criticidade}
                modoCriticidade={modoCriticidade}
                fluxo={fluxo}
                modoFluxo={modoFluxo}
                config={config}
                modoPadrao={modoPadrao}

              />
            </Suspense>
          </ClientOnly>
        </div>


        <div className="flex h-[480px] flex-col sm:h-[560px] rounded-xl border border-border bg-card">
          <div className="border-b border-border p-3">
            <h2 className="text-sm font-semibold text-foreground">
              Ranking por {METRICS.find((m) => m.key === metric)?.label}{" "}
              <span className="font-normal text-muted-foreground">({ranking.length} unidades)</span>
            </h2>
          </div>
          <ul className="flex-1 overflow-y-auto text-sm">
            {ranking.map((u, i) => (
              <li key={u.unidade}>
                <button
                  onClick={() => setSelected(u.unidade)}
                  className={`flex w-full items-center justify-between gap-3 border-b border-border px-3 py-2 text-left transition-colors hover:bg-accent ${
                    selected === u.unidade ? "bg-accent" : ""
                  }`}
                >
                  <span className="truncate">
                    <span className="mr-2 text-xs text-muted-foreground">{i + 1}</span>
                    {u.unidade}
                  </span>
                  <span className="shrink-0 font-semibold tabular-nums text-foreground">
                    {Number(u[metric]) || 0}
                  </span>
                </button>
              </li>
            ))}
          </ul>
          {det && (
            <div className="border-t border-border p-3 text-xs text-muted-foreground">
              <p className="mb-1 text-sm font-semibold text-foreground">{det.unidade}</p>
              <p className="mb-1">Endereço: {enderecoCompleto(det)}</p>
              <p>
                Região {det.regiao} · {det.estudantes} estudantes · {det.cuidadores} CADs · razão{" "}
                {det.razao}
              </p>
              <p>
                TEA {det.tea} (N3 {det.suporte3} / N2 {det.suporte2} / N1 {det.suporte1}) ·
                Deficiência {det.deficiencia} · Transtornos {det.transtorno} · Sem laudo{" "}
                {det.semLaudo}
              </p>
              <p>
                Matutino {det.matutino} · Vespertino {det.vespertino} · Integral {det.integral} ·
                CADs 40h {det.carga40}
              </p>
            </div>
          )}
        </div>
      </section>

      {det && (
        <section className="mt-6">
          <FichaTecnica unidade={det} />
        </section>
      )}

      <PainelCriticidade
        criticidade={criticidade}
        resumo={resumoCrit}
        raio={raio}
        onSelecionar={setSelected}
      />

      <ClientOnly fallback={null}>
        <PainelFluxoMatriculas
          resumo={resumoFluxo}
          carregando={carregandoMatriculas}
          onSelecionar={setSelected}
        />
      </ClientOnly>


      <section className="mt-8">
        <MapaDistorcao />
      </section>

      <TriangulacaoPanel
        clusters={clusters}
        raio={raio}
        onRaio={setRaio}
        selecionado={cluster}
        onSelecionar={setCluster}
        onSelecionarUnidade={setSelected}
      />

      <ClientOnly fallback={null}>
        <PainelAtualizacoes />
      </ClientOnly>


      <p className="mt-4 text-xs text-muted-foreground">
        Base consolidada e deduplicada das 5 planilhas ({UNIDADES.length} unidades / {" "}
        {UNIDADES.reduce((a, u) => a + u.estudantes, 0)} atendimentos). Posições no mapa são
        aproximadas por região até a carga das coordenadas oficiais das unidades.
      </p>
      </main>
      <SiteFooter />
    </div>
  );
}
