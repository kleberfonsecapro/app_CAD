// Definição das etapas e campos do formulário de cadastro/vistoria técnica
// Base normativa: ABNT NBR 14653-2 e diretrizes CAU/BR

export const ETAPAS = [
  { id: 1, label: "Dados Cadastrais" },
  { id: 2, label: "Dados Gerais" },
  { id: 3, label: "Análise Estrutural" },
  { id: 4, label: "Levantamento Fotográfico" },
  { id: 5, label: "Análise do Entorno" },
  { id: 6, label: "Parecer Técnico" },
] as const;

export const ITENS_ESTRUTURAIS = [
  {
    key: "estruturaPrincipal",
    label: "Estrutura Principal",
    tooltip:
      "Estabilidade de pilares, vigas, lajes e fundações visíveis. Verifique trincas, deformações ou recalques que comprometam a integridade estrutural.",
  },
  {
    key: "alvenariaVedacoes",
    label: "Alvenaria / Vedações",
    tooltip:
      "Integridade de paredes e divisórias: fissuras, rachaduras, esfarelamento de reboco e função de compartimentação.",
  },
  {
    key: "coberturaTelhado",
    label: "Cobertura / Telhado",
    tooltip:
      "Estanqueidade da cobertura, alinhamento de telhas, estrutura de madeira/aço, calhas, rufos e impermeabilização.",
  },
  {
    key: "umidadeInfiltracoes",
    label: "Umidade & Infiltrações",
    tooltip:
      "Umidade ascendente, eflorescências, mofo, manchas em teto e rodapés, vazamentos e falhas de impermeabilização.",
  },
  {
    key: "revestimentosPisos",
    label: "Revestimentos & Pisos",
    tooltip:
      "Pisos cerâmicos, madeira, pedras e azulejos: nivelamento, peças soltas ou quebradas e aderência dos revestimentos.",
  },
  {
    key: "pinturaAcabamentos",
    label: "Pintura & Acabamentos",
    tooltip:
      "Pintura interna e externa: descascamento, bolhas, sujidade e acabamento de gesso.",
  },
  {
    key: "esquadriasVidros",
    label: "Esquadrias & Vidros",
    tooltip:
      "Funcionamento de portas, janelas e portões, trincos, fechaduras, oxidação e integridade dos vidros.",
  },
  {
    key: "instalacoesEletricas",
    label: "Instalações Elétricas",
    tooltip:
      "Quadro de distribuição, disjuntores, fiação aparente, tomadas, interruptores e aterramento (risco de incêndio e choque).",
  },
  {
    key: "instalacoesHidrossanitarias",
    label: "Instalações Hidrossanitárias",
    tooltip:
      "Pressão de água, vazamentos, louças e metais, caixas de gordura e de passagem e rede de esgoto.",
  },
  {
    key: "acessibilidade",
    label: "Acessibilidade (NBR 9050)",
    tooltip:
      "Rampas, corrimãos, piso tátil, sanitários acessíveis, largura de portas e circulação — essencial para o atendimento especializado (CAD).",
  },
] as const;

export const ITENS_FOTOGRAFICOS = [
  {
    key: "fachadaAcessos",
    label: "Fachada & Acessos",
    desc: "Fachada principal, portões, rampas de acessibilidade, escadarias e calçadas.",
  },
  {
    key: "ambientesInternos",
    label: "Ambientes Internos",
    desc: "Salas de aula, laboratório, biblioteca, banheiros, cozinha/refeitório e circulação.",
  },
  {
    key: "detalhesAcabamento",
    label: "Detalhes de Acabamento",
    desc: "Trincas, pisos soltos, infiltrações, pintura descascando e esquadrias danificadas.",
  },
  {
    key: "manifestacoesPatologicas",
    label: "Manifestações Patológicas",
    desc: "Eflorescências, manchas de umidade, mofo, corrosão, desplacamento de reboco e trincas estruturais.",
  },
  {
    key: "areasAnexos",
    label: "Áreas Comuns & Anexos",
    desc: "Quadras, pátios, garagens, depósitos, portarias e demais espaços comuns.",
  },
  {
    key: "panoramicaEntorno",
    label: "Panorâmica do Entorno",
    desc: "Vista geral da unidade, ruas adjacentes, árvores, postes e edificações vizinhas.",
  },
] as const;

export const ITENS_ENTORNO = [
  {
    key: "infraestruturaBasica",
    label: "Infraestrutura Básica",
    desc: "Água, esgoto, drenagem pluvial, iluminação pública e pavimentação da via.",
    options: [
      { value: "completa", label: "Completa" },
      { value: "parcial", label: "Parcial" },
      { value: "ausente", label: "Ausente" },
    ],
  },
  {
    key: "servicosTransportes",
    label: "Serviços & Transportes",
    desc: "Proximidade de linhas de ônibus, escolas, unidades de saúde, comércio e serviços.",
    options: [
      { value: "bom", label: "Bom" },
      { value: "regular", label: "Regular" },
      { value: "precario", label: "Precário" },
    ],
  },
  {
    key: "padraoVizinhanca",
    label: "Padrão da Vizinhança",
    desc: "Padrão construtivo dominante, nível socioeconômico e adensamento urbano.",
    options: [
      { value: "alto", label: "Alto" },
      { value: "medio", label: "Médio" },
      { value: "baixo", label: "Baixo" },
    ],
  },
  {
    key: "usoOcupacaoSolo",
    label: "Uso e Ocupação do Solo",
    desc: "Característica da zona: residencial, comercial, industrial ou mista.",
    options: [
      { value: "residencial", label: "Residencial" },
      { value: "comercial", label: "Comercial" },
      { value: "misto", label: "Misto" },
    ],
  },
  {
    key: "polosInfluencia",
    label: "Polos de Influência",
    desc: "Comércio/shoppings, parques, ruído, tráfego pesado ou áreas inundáveis.",
    options: [
      { value: "favoravel", label: "Favorável" },
      { value: "neutro", label: "Neutro" },
      { value: "desfavoravel", label: "Desfavorável" },
    ],
  },
] as const;

export const CLASSIFICACOES_CONSERVACAO = [
  { value: "novo_muito_bom", label: "Novo / Muito Bom" },
  { value: "regular", label: "Regular" },
  { value: "reparos_simples", label: "Reparos Simples" },
  { value: "reparos_importantes", label: "Reparos Importantes / Mau" },
  { value: "mau_pessimo", label: "Péssimo / Ruína" },
] as const;

export const PADROES_CONSTRUTIVOS = [
  { value: "minimo_baixo", label: "Mínimo / Baixo" },
  { value: "medio", label: "Médio" },
  { value: "alto", label: "Alto" },
  { value: "luxo", label: "Luxo" },
] as const;

export const FAIXAS_NOTA = [
  { range: "9–10", label: "Novo / Muito Bom", color: "bg-emerald-500" },
  { range: "7–8", label: "Regular", color: "bg-blue-500" },
  { range: "5–6", label: "Reparos Simples", color: "bg-yellow-500" },
  { range: "2–4", label: "Reparos Importantes", color: "bg-orange-500" },
  { range: "0–1", label: "Péssimo / Ruína", color: "bg-red-500" },
] as const;

export function corDaNota(nota: number | null | undefined) {
  if (nota == null) return "bg-muted text-muted-foreground";
  if (nota >= 9) return "bg-emerald-500 text-white";
  if (nota >= 7) return "bg-blue-500 text-white";
  if (nota >= 5) return "bg-yellow-500 text-black";
  if (nota >= 2) return "bg-orange-500 text-white";
  return "bg-red-500 text-white";
}

export function classificacaoPorNota(nota: number | null | undefined) {
  if (nota == null) return "Não avaliado";
  if (nota >= 9) return "Novo / Muito Bom";
  if (nota >= 7) return "Regular";
  if (nota >= 5) return "Reparos Simples";
  if (nota >= 2) return "Reparos Importantes";
  return "Péssimo / Ruína";
}

export function labelClassificacao(value?: string | null) {
  return CLASSIFICACOES_CONSERVACAO.find((c) => c.value === value)?.label ?? "—";
}

export function labelPadrao(value?: string | null) {
  return PADROES_CONSTRUTIVOS.find((c) => c.value === value)?.label ?? "—";
}

export function calcularNotaMedia(estrutural: Record<string, unknown>) {
  const notas = ITENS_ESTRUTURAIS.map((i) => estrutural?.[`${i.key}Nota`]).filter(
    (n): n is number => typeof n === "number",
  );
  if (!notas.length) return null;
  return Math.round((notas.reduce((a, b) => a + b, 0) / notas.length) * 100) / 100;
}

// Séries/etapas atendidas por sala (educação infantil + anos iniciais)
export const SERIES_SALA = [
  { value: "G0", label: "G0 · Berçário" },
  { value: "G1", label: "G1 · Maternal" },
  { value: "G2", label: "G2 · Jardim I" },
  { value: "G3", label: "G3 · Jardim II" },
  { value: "G4", label: "G4 · Pré-escola I" },
  { value: "G5", label: "G5 · Pré-escola II" },
  { value: "1ANO", label: "1º Ano" },
  { value: "2ANO", label: "2º Ano" },
  { value: "3ANO", label: "3º Ano" },
  { value: "4ANO", label: "4º Ano" },
  { value: "5ANO", label: "5º Ano" },
] as const;

export type SalaCadastro = {
  serie: string;
  cads_matutino: number | null;
  cads_vespertino: number | null;
  alunos_matutino: number | null;
  alunos_vespertino: number | null;
};

export const salaVazia = (): SalaCadastro => ({
  serie: "",
  cads_matutino: null,
  cads_vespertino: null,
  alunos_matutino: null,
  alunos_vespertino: null,
});

export function labelSerie(value?: string | null) {
  return SERIES_SALA.find((s) => s.value === value)?.label ?? "—";
}

/** Ajusta a lista de salas ao número informado (cascata). */
export function ajustarSalas(salas: SalaCadastro[], quantidade: number | null): SalaCadastro[] {
  const n = Math.max(0, Math.min(200, quantidade ?? 0));
  const lista = salas.slice(0, n).map((s) => ({ ...salaVazia(), ...s }));
  while (lista.length < n) lista.push(salaVazia());
  return lista;
}

export function totalCadsSalas(salas: SalaCadastro[]) {
  return salas.reduce(
    (acc, s) => acc + (s.cads_matutino ?? 0) + (s.cads_vespertino ?? 0),
    0,
  );
}

export function totalAlunosSalas(salas: SalaCadastro[]) {
  return salas.reduce(
    (acc, s) => acc + (s.alunos_matutino ?? 0) + (s.alunos_vespertino ?? 0),
    0,
  );
}
