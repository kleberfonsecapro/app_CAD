import type { Unidade } from "@/types/unidade";

export function enderecoCompleto(u: Unidade) {
  const linha = [u.rua, u.numero].filter(Boolean).join(", ");
  const partes = [linha, u.bairro, u.cep].filter(Boolean).join(" · ");
  if (partes) return `${partes}${partes.includes("Cuiabá") ? "" : " — Cuiabá/MT"}`;
  if (u.endereco) return u.endereco;
  return `Endereço não informado — Região ${u.regiao}, Cuiabá/MT`;
}
