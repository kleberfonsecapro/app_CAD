import type { Unidade } from "@/types/unidade";
import { analisarUnidade, type AnaliseTecnica } from "@/lib/analiseTecnica";
import { distanciaMetros } from "@/lib/triangulacao";

export type Movimento = {
  destino: string;
  cads: number;
  metros: number;
  deficitDestino: number;
};

export type Criticidade = {
  unidade: string;
  analise: AnaliseTecnica;
  /** classe operacional exibida no mapa */
  classe: "Excedente crítico" | "Déficit crítico" | "Déficit" | "Adequado";
  /** 0-100 — quanto maior, mais urgente a intervenção */
  score: number;
  /** CADs disponíveis para remanejamento (unidades excedentes) */
  excedente: number;
  /** CADs faltantes (unidades deficitárias) */
  deficit: number;
  /** destinos sugeridos para o excedente, dentro do raio */
  movimentos: Movimento[];
  /** unidades excedentes próximas que podem socorrer o déficit */
  origens: { origem: string; cads: number; metros: number }[];
  /** riscos de exaustão emocional / sobrecarga estrutural */
  riscos: string[];
  /** 0-100 — Índice de Necessidade de Intervenção (saneamento e reorganização estrutural) */
  intervencao: number;
  /** posição no ranking de necessidade de intervenção (1 = mais urgente) */
  rankIntervencao: number;
  /** pertence aos 20% que mais necessitam de intervenção */
  prioridadeTop20: boolean;
  /** fatores que compõem o índice de intervenção */
  fatores: string[];
};

export const COR_CLASSE: Record<Criticidade["classe"], string> = {
  "Excedente crítico": "hsl(280 70% 50%)",
  "Déficit crítico": "hsl(0 80% 48%)",
  Déficit: "hsl(32 92% 50%)",
  Adequado: "hsl(150 60% 38%)",
};

/** cor "quente" aplicada aos 20% prioritários no mapa de calor */
export const COR_INTERVENCAO = "hsl(8 92% 46%)";


function riscosDe(u: Unidade, a: AnaliseTecnica, classe: Criticidade["classe"]): string[] {
  const r: string[] = [];
  const cargaPorCad = u.cuidadores ? u.estudantes / u.cuidadores : Infinity;
  if (classe === "Excedente crítico")
    r.push(
      "Excedente de CAD imobiliza força de trabalho que outra unidade próxima precisa — risco de má alocação orçamentária.",
    );
  if (cargaPorCad > 9.5)
    r.push(
      `Carga de ${cargaPorCad === Infinity ? "—" : cargaPorCad.toFixed(1)} estudantes por CAD acima da média nacional — alto risco de exaustão emocional.`,
    );
  if (u.suporte3 > u.cuidadores)
    r.push("Casos de apoio individual (TEA nível 3) superam o número de CADs — sobrecarga estrutural.");
  if (u.integral > 0 && u.carga40 === 0)
    r.push("Estudantes em tempo integral sem CAD de 40h — descontinuidade de cobertura na jornada.");
  if (u.semLaudo > 0)
    r.push(`${u.semLaudo} estudante(s) sem laudo — dimensionamento sujeito a revisão técnica.`);
  return r;
}

export function construirCriticidade(unidades: Unidade[], raio = 1000): Map<string, Criticidade> {
  const analises = new Map(unidades.map((u) => [u.unidade, analisarUnidade(u)]));

  const base: Criticidade[] = unidades.map((u) => {
    const a = analises.get(u.unidade)!;
    const excedente = Math.max(0, a.saldo);
    const deficit = Math.max(0, -a.saldo);
    const classe: Criticidade["classe"] =
      a.classificacao === "Excedente"
        ? "Excedente crítico"
        : a.classificacao === "Déficit crítico"
          ? "Déficit crítico"
          : a.classificacao === "Déficit"
            ? "Déficit"
            : "Adequado";

    const score =
      classe === "Excedente crítico"
        ? Math.min(100, 55 + Math.abs(a.distorcao) * 0.4)
        : classe === "Déficit crítico"
          ? Math.min(100, 70 + Math.abs(a.distorcao) * 0.3)
          : classe === "Déficit"
            ? Math.min(100, 40 + Math.abs(a.distorcao) * 0.5)
            : Math.max(0, 20 - Math.abs(a.distorcao) * 0.2);

    return {
      unidade: u.unidade,
      analise: a,
      classe,
      score: Math.round(score),
      excedente,
      deficit,
      movimentos: [],
      origens: [],
      riscos: riscosDe(u, a, classe),
      intervencao: 0,
      rankIntervencao: 0,
      prioridadeTop20: false,
      fatores: [],
    };
  });


  const porNome = new Map(base.map((c) => [c.unidade, c]));
  const coord = new Map(unidades.map((u) => [u.unidade, u]));

  // saldo disponível/necessário mutável para o plano de remanejamento
  const disp = new Map(base.map((c) => [c.unidade, c.excedente]));
  const falta = new Map(base.map((c) => [c.unidade, c.deficit]));

  const excedentes = base
    .filter((c) => c.excedente > 0)
    .sort((a, b) => b.excedente - a.excedente);

  excedentes.forEach((ex) => {
    const origem = coord.get(ex.unidade)!;
    const candidatos = base
      .filter((c) => (falta.get(c.unidade) ?? 0) > 0 && c.unidade !== ex.unidade)
      .map((c) => {
        const d = coord.get(c.unidade)!;
        return {
          alvo: c,
          metros: Math.round(distanciaMetros(origem, d)),
        };
      })
      .filter((c) => c.metros <= raio)
      .sort((a, b) => a.metros - b.metros);

    candidatos.forEach((c) => {
      const restante = disp.get(ex.unidade) ?? 0;
      if (restante <= 0) return;
      const necessidade = falta.get(c.alvo.unidade) ?? 0;
      if (necessidade <= 0) return;
      const mover = Math.min(restante, necessidade);
      disp.set(ex.unidade, restante - mover);
      falta.set(c.alvo.unidade, necessidade - mover);

      ex.movimentos.push({
        destino: c.alvo.unidade,
        cads: mover,
        metros: c.metros,
        deficitDestino: necessidade,
      });
      porNome.get(c.alvo.unidade)!.origens.push({
        origem: ex.unidade,
        cads: mover,
        metros: c.metros,
      });
    });

    if (ex.movimentos.length === 0)
      ex.riscos.push(
        `Nenhuma unidade deficitária em até ${raio} m — avaliar remanejamento regional ou ampliação do raio.`,
      );
  });

  // ---- Índice de Necessidade de Intervenção (saneamento + reorganização estrutural) ----
  const brutos = base.map((c) => {
    const u = coord.get(c.unidade)!;
    const fatores: string[] = [];
    let v = 0;

    // 1) Déficit de CAD frente ao dimensionamento técnico (peso maior)
    if (c.deficit > 0) {
      v += Math.min(40, c.deficit * 8);
      fatores.push(`Déficit de ${c.deficit} CAD frente ao dimensionamento técnico`);
    }

    // 2) Sobrecarga por cuidador (estudantes/CAD acima da meta de 6:1)
    const carga = u.cuidadores ? u.estudantes / u.cuidadores : u.estudantes > 0 ? 30 : 0;
    if (carga > 6) {
      v += Math.min(25, (carga - 6) * 3);
      fatores.push(
        u.cuidadores
          ? `Carga de ${carga.toFixed(1)} estudantes por CAD (meta 6:1)`
          : "Unidade com estudantes e sem CAD lotado",
      );
    }

    // 3) Apoio individual (TEA nível 3) acima da capacidade instalada
    if (u.suporte3 > u.cuidadores) {
      v += Math.min(15, (u.suporte3 - u.cuidadores) * 4);
      fatores.push(`${u.suporte3} caso(s) de apoio individual acima da equipe disponível`);
    }

    // 4) Demanda represada de avaliação (sem laudo)
    if (u.semLaudo > 0) {
      v += Math.min(10, u.semLaudo * 2);
      fatores.push(`${u.semLaudo} estudante(s) sem laudo — saneamento cadastral pendente`);
    }

    // 5) Integral sem CAD de 40h — descontinuidade de jornada
    if (u.integral > 0 && u.carga40 === 0) {
      v += 8;
      fatores.push("Tempo integral sem CAD de 40h");
    }

    // 6) Unidade sem cadastro de CAD — saneamento estrutural imediato
    if (u.semCadastro) {
      v += 12;
      fatores.push("Unidade sem cadastro de CAD na base");
    }

    // 7) Criticidade operacional consolidada
    v += c.score * 0.15;

    return { c, v, fatores };
  });

  const maxV = Math.max(1, ...brutos.map((b) => b.v));
  brutos
    .sort((a, b) => b.v - a.v)
    .forEach((b, i) => {
      b.c.intervencao = Math.round((b.v / maxV) * 100);
      b.c.rankIntervencao = i + 1;
      b.c.fatores = b.fatores;
    });

  const corte = Math.max(1, Math.ceil(brutos.length * 0.2));
  brutos.forEach((b, i) => {
    b.c.prioridadeTop20 = b.v > 0 && i < corte;
  });

  return porNome;
}


export type ResumoCriticidade = {
  excedentes: number;
  deficitCritico: number;
  deficit: number;
  adequadas: number;
  cadsRemanejaveis: number;
  cadsRemanejados: number;
  unidadesBeneficiadas: number;
  prioritarias: number;
};

export function resumirCriticidade(mapa: Map<string, Criticidade>): ResumoCriticidade {
  const lista = [...mapa.values()];
  const movimentos = lista.flatMap((c) => c.movimentos);
  return {
    excedentes: lista.filter((c) => c.classe === "Excedente crítico").length,
    deficitCritico: lista.filter((c) => c.classe === "Déficit crítico").length,
    deficit: lista.filter((c) => c.classe === "Déficit").length,
    adequadas: lista.filter((c) => c.classe === "Adequado").length,
    cadsRemanejaveis: lista.reduce((a, c) => a + c.excedente, 0),
    cadsRemanejados: movimentos.reduce((a, m) => a + m.cads, 0),
    unidadesBeneficiadas: new Set(movimentos.map((m) => m.destino)).size,
    prioritarias: lista.filter((c) => c.prioridadeTop20).length,
  };
}
