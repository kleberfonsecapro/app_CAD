// Cruzamento das matrículas 2020–2026 (SIGEEC) com as unidades do mapa de calor
import type { UnidadeMatricula } from "@/lib/matriculas";
import { ANOS } from "@/lib/matriculas";
import type { Unidade } from "@/types/unidade";

export const normalizarNome = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .trim();

export type Segmento = "Creche" | "Escola";

export function segmentoDaUnidade(nome: string): Segmento {
  const n = normalizarNome(nome);
  return /^(CMEI|CEIC|CEEI|CRECHE)\b/.test(n) ? "Creche" : "Escola";
}

export type TendenciaClasse =
  | "Crescimento forte"
  | "Crescimento"
  | "Estável"
  | "Retração"
  | "Retração forte";

export const COR_TENDENCIA: Record<TendenciaClasse, string> = {
  "Crescimento forte": "hsl(150 70% 32%)",
  Crescimento: "hsl(150 55% 45%)",
  Estável: "hsl(210 12% 55%)",
  Retração: "hsl(32 92% 50%)",
  "Retração forte": "hsl(0 80% 48%)",
};

export type FluxoMatricula = {
  unidade: string;
  segmento: Segmento;
  serie: { ano: number; valor: number }[];
  m2020: number;
  m2025: number;
  m2026: number;
  variacaoTotal: number; // 2026 - 2020
  variacaoPct: number; // % 2020 → 2026
  variacaoAno: number; // 2026 - 2025
  variacaoAnoPct: number;
  pico: { ano: number; valor: number };
  classe: TendenciaClasse;
};

function classificar(pct: number): TendenciaClasse {
  if (pct >= 20) return "Crescimento forte";
  if (pct >= 5) return "Crescimento";
  if (pct > -5) return "Estável";
  if (pct > -20) return "Retração";
  return "Retração forte";
}

export function construirFluxo(
  unidades: Unidade[],
  matriculas: UnidadeMatricula[] | undefined,
): Map<string, FluxoMatricula> {
  const mapa = new Map<string, FluxoMatricula>();
  if (!matriculas?.length) return mapa;

  const porNome = new Map<string, UnidadeMatricula>();
  for (const m of matriculas) porNome.set(normalizarNome(m.unidade), m);

  for (const u of unidades) {
    const m = porNome.get(normalizarNome(u.unidade));
    if (!m) continue;
    const serie = ANOS.map((ano) => ({ ano, valor: Number(m[ano]) || 0 }));
    const m2020 = serie[0].valor;
    const m2025 = serie[serie.length - 2].valor;
    const m2026 = serie[serie.length - 1].valor;
    const base = m2020 || m2025 || 1;
    const variacaoPct = ((m2026 - m2020) / (m2020 || base)) * 100;
    const pico = serie.reduce((a, b) => (b.valor > a.valor ? b : a), serie[0]);
    mapa.set(u.unidade, {
      unidade: u.unidade,
      segmento: segmentoDaUnidade(u.unidade),
      serie,
      m2020,
      m2025,
      m2026,
      variacaoTotal: m2026 - m2020,
      variacaoPct: Math.round(variacaoPct * 10) / 10,
      variacaoAno: m2026 - m2025,
      variacaoAnoPct: m2025 ? Math.round(((m2026 - m2025) / m2025) * 1000) / 10 : 0,
      pico,
      classe: classificar(variacaoPct),
    });
  }
  return mapa;
}

export type ResumoFluxo = {
  comDados: number;
  crescimento: number;
  retracao: number;
  estaveis: number;
  total2020: number;
  total2026: number;
  porRegiao: {
    regiao: string;
    unidades: number;
    t2020: number;
    t2026: number;
    delta: number;
    pct: number;
  }[];
  maioresAltas: FluxoMatricula[];
  maioresQuedas: FluxoMatricula[];
};

export function resumirFluxo(
  unidades: Unidade[],
  fluxo: Map<string, FluxoMatricula>,
): ResumoFluxo {
  const itens = [...fluxo.values()];
  const regioes = new Map<string, { unidades: number; t2020: number; t2026: number }>();
  for (const u of unidades) {
    const f = fluxo.get(u.unidade);
    if (!f) continue;
    const r = regioes.get(u.regiao) ?? { unidades: 0, t2020: 0, t2026: 0 };
    r.unidades += 1;
    r.t2020 += f.m2020;
    r.t2026 += f.m2026;
    regioes.set(u.regiao, r);
  }
  return {
    comDados: itens.length,
    crescimento: itens.filter((f) => f.classe.startsWith("Crescimento")).length,
    retracao: itens.filter((f) => f.classe.startsWith("Retração")).length,
    estaveis: itens.filter((f) => f.classe === "Estável").length,
    total2020: itens.reduce((a, f) => a + f.m2020, 0),
    total2026: itens.reduce((a, f) => a + f.m2026, 0),
    porRegiao: [...regioes.entries()]
      .map(([regiao, r]) => ({
        regiao,
        unidades: r.unidades,
        t2020: r.t2020,
        t2026: r.t2026,
        delta: r.t2026 - r.t2020,
        pct: r.t2020 ? Math.round(((r.t2026 - r.t2020) / r.t2020) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.delta - a.delta),
    maioresAltas: [...itens].sort((a, b) => b.variacaoTotal - a.variacaoTotal).slice(0, 8),
    maioresQuedas: [...itens].sort((a, b) => a.variacaoTotal - b.variacaoTotal).slice(0, 8),
  };
}
