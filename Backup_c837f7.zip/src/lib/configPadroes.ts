import { useCallback, useEffect, useState } from "react";

export type ConfigPadroes = {
  /** Média nacional de referência (estudantes por CAD) */
  mediaNacional: number;
  /** Até este valor de estudantes/CAD o círculo fica vermelho */
  limiteVermelho: number;
  /** Entre o limite vermelho e este valor o círculo fica amarelo; acima, verde */
  limiteAmarelo: number;
  /** Raio mínimo do círculo (unidade com poucos CADs) */
  raioMin: number;
  /** Raio máximo do círculo (unidade com mais CADs) */
  raioMax: number;
  /** Mostrar o número de CADs no centro do círculo */
  mostrarNumeroCads: boolean;
};

export const CONFIG_PADRAO: ConfigPadroes = {
  mediaNacional: 9,
  limiteVermelho: 5,
  limiteAmarelo: 8,
  raioMin: 10,
  raioMax: 34,
  mostrarNumeroCads: true,
};

export const COR_PADRAO = {
  vermelho: "hsl(0 80% 48%)",
  amarelo: "hsl(45 95% 48%)",
  verde: "hsl(150 60% 38%)",
} as const;

export type FaixaPadrao = "vermelho" | "amarelo" | "verde";

export const ROTULO_FAIXA: Record<FaixaPadrao, string> = {
  vermelho: "Abaixo do parâmetro",
  amarelo: "Em transição",
  verde: "Dentro do parâmetro",
};

/** Classifica pela razão estudantes por CAD */
export function faixaPorRazao(razao: number | null | undefined, cfg: ConfigPadroes): FaixaPadrao {
  const r = Number(razao) || 0;
  if (r <= cfg.limiteVermelho) return "vermelho";
  if (r <= cfg.limiteAmarelo) return "amarelo";
  return "verde";
}

export function corPorRazao(razao: number | null | undefined, cfg: ConfigPadroes) {
  return COR_PADRAO[faixaPorRazao(razao, cfg)];
}

/** Raio proporcional ao número de CADs da unidade */
export function raioPorCads(cads: number, maxCads: number, cfg: ConfigPadroes) {
  const t = Math.sqrt(Math.max(0, cads) / Math.max(1, maxCads));
  return cfg.raioMin + t * (cfg.raioMax - cfg.raioMin);
}

const CHAVE = "pmc-mcedu-cad:config-padroes";

export function useConfigPadroes() {
  const [config, setConfig] = useState<ConfigPadroes>(CONFIG_PADRAO);

  useEffect(() => {
    try {
      const bruto = window.localStorage.getItem(CHAVE);
      if (bruto) setConfig({ ...CONFIG_PADRAO, ...(JSON.parse(bruto) as Partial<ConfigPadroes>) });
    } catch {
      /* configuração inválida — mantém padrão */
    }
  }, []);

  const salvar = useCallback((c: ConfigPadroes) => {
    setConfig(c);
    try {
      window.localStorage.setItem(CHAVE, JSON.stringify(c));
    } catch {
      /* armazenamento indisponível */
    }
  }, []);

  const restaurar = useCallback(() => {
    setConfig(CONFIG_PADRAO);
    try {
      window.localStorage.removeItem(CHAVE);
    } catch {
      /* armazenamento indisponível */
    }
  }, []);

  return { config, salvar, restaurar };
}
