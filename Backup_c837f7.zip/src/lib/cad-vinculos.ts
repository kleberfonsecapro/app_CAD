import type { CAD, LevantamentoPedagogico } from "@/lib/cadastro-api";

/** Aluno atendido por um CAD, conforme registrado no Levantamento Pedagógico. */
export type AlunoVinculado = {
  nome: string;
  cid?: string;
  deficiencia?: string;
  teaNivelSuporte?: string;
  teaAutonomia?: string;
  possuiTranstornos?: string;
  possuiLaudo?: string;
  transtornoComportamental?: string;
  /** Índice original do aluno dentro de vinculos[].alunos[]. */
  idx?: number;
};

/** Vínculo de um CAD com uma sala (escola + ano/série + turma + período) e seus alunos. */
export type VinculoAluno = {
  escola: string;
  unidadeId: string;
  anoSerie: string;
  turma: string;
  periodo: string;
  alunos: AlunoVinculado[];
  responsavel?: string | null;
  dataLevantamento?: string | null;
  status?: string | null;
  levantamentoId?: string;
  vinculoIdx?: number;
};

export type IndiceVinculos = {
  porCadId: Map<string, VinculoAluno[]>;
  porNome: Map<string, VinculoAluno[]>;
  totalAlunos: number;
  totalVinculos: number;
  profissionaisComAlunos: number;
};

/** Normaliza nome para comparação (sem acento, sem caixa, sem espaços duplicados). */
export const normalizarNomeCAD = (valor?: string | null): string =>
  (valor ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .trim();

const texto = (v: unknown): string => (typeof v === "string" ? v.trim() : "");

const paraAluno = (bruto: any): AlunoVinculado => ({
  nome: texto(bruto?.nome) || texto(bruto?.estudante) || texto(bruto?.aluno),
  cid: texto(bruto?.cid),
  deficiencia: texto(bruto?.deficiencia),
  teaNivelSuporte: texto(bruto?.teaNivelSuporte),
  teaAutonomia: texto(bruto?.teaAutonomia),
  possuiTranstornos: texto(bruto?.possuiTranstornos),
  possuiLaudo: texto(bruto?.possuiLaudo),
  transtornoComportamental: texto(bruto?.transtornoComportamental),
});

const chaveVinculo = (v: VinculoAluno) =>
  [
    normalizarNomeCAD(v.escola),
    v.anoSerie,
    v.turma,
    v.periodo,
    v.alunos.map((a) => normalizarNomeCAD(a.nome)).join("|"),
  ].join("::");

/**
 * Monta o índice de vínculos CAD → alunos a partir dos levantamentos pedagógicos.
 * A origem é o JSON `dados_pedagogicos.salaAula` (ano, turma, periodo e vinculos[].alunos[]),
 * combinado com a escola do levantamento (unidade_nome / unidade_id).
 */
export function construirIndiceVinculos(
  levantamentos: LevantamentoPedagogico[] = [],
): IndiceVinculos {
  const porCadId = new Map<string, VinculoAluno[]>();
  const porNome = new Map<string, VinculoAluno[]>();
  const alunosUnicos = new Set<string>();
  const profissionais = new Set<string>();
  let totalVinculos = 0;

  for (const lev of levantamentos ?? []) {
    const dados = (lev?.dados_pedagogicos ?? {}) as Record<string, any>;
    const sala = (dados.salaAula ?? dados.sala_aula ?? {}) as Record<string, any>;
    const vinculosBrutos: any[] = Array.isArray(sala.vinculos) ? sala.vinculos : [];
    const escola = texto(lev?.unidade_nome) || texto(lev?.unidade_id) || "Escola não informada";

    vinculosBrutos.forEach((bruto, vinculoIdx) => {
      const alunos: AlunoVinculado[] = (Array.isArray(bruto?.alunos) ? bruto.alunos : [])
        .map((b: any, idx: number) => ({ ...paraAluno(b), idx }))
        .filter((a: AlunoVinculado) => a.nome || a.cid);

      const vinculo: VinculoAluno = {
        escola,
        unidadeId: texto(lev?.unidade_id),
        anoSerie: texto(sala.ano),
        turma: texto(sala.turma),
        periodo: texto(sala.periodo),
        alunos,
        responsavel: lev?.responsavel ?? null,
        dataLevantamento: lev?.data_levantamento ?? null,
        status: lev?.status ?? null,
        levantamentoId: (lev as any)?.id,
        vinculoIdx,
      };

      totalVinculos++;

      alunos.forEach((a, i) => {
        alunosUnicos.add(
          `${normalizarNomeCAD(escola)}|${vinculo.anoSerie}|${vinculo.turma}|${
            vinculo.periodo
          }|${normalizarNomeCAD(a.nome)}|${i}`,
        );
      });

      const id = texto(bruto?.cadId) || texto(bruto?.cad_id);
      if (id) {
        porCadId.set(id, [...(porCadId.get(id) ?? []), vinculo]);
        profissionais.add(`id:${id}`);
      }

      const nomeCad = normalizarNomeCAD(bruto?.cadNome ?? bruto?.cad_nome);
      if (nomeCad) {
        porNome.set(nomeCad, [...(porNome.get(nomeCad) ?? []), vinculo]);
        profissionais.add(`nome:${nomeCad}`);
      }
    });
  }

  return {
    porCadId,
    porNome,
    totalAlunos: alunosUnicos.size,
    totalVinculos,
    profissionaisComAlunos: profissionais.size,
  };
}

/**
 * Retorna os vínculos (escola, ano/série, turma, período e alunos) de um CAD,
 * casando primeiro pelo id do CAD e depois pelo nome normalizado (fallback).
 */
export function buscarVinculosDoCAD(cad: CAD, indice: IndiceVinculos): VinculoAluno[] {
  const lista: VinculoAluno[] = [
    ...(cad?.id ? indice.porCadId.get(cad.id) ?? [] : []),
    ...(indice.porNome.get(normalizarNomeCAD(cad?.nome)) ?? []),
  ];

  const vistos = new Set<string>();
  return lista.filter((v) => {
    const chave = chaveVinculo(v);
    if (vistos.has(chave)) return false;
    vistos.add(chave);
    return true;
  });
}

/** Total de alunos únicos (por escola/sala/nome) presentes numa lista de vínculos. */
export function contarAlunosDosVinculos(vinculos: VinculoAluno[]): number {
  const chaves = new Set<string>();
  vinculos.forEach((v) => {
    v.alunos.forEach((a, i) => {
      chaves.add(
        `${normalizarNomeCAD(v.escola)}|${v.anoSerie}|${v.turma}|${v.periodo}|${
          normalizarNomeCAD(a.nome)
        }|${i}`,
      );
    });
  });
  return chaves.size;
}
