import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { calcularNotaMedia, type SalaCadastro } from "@/lib/cadastro-schema";

type JsonRecord = { [key: string]: Json | undefined };

export type CadastroUnidade = {
  id?: string;
  unidade_id: string;
  nome: string;
  inep?: string | null;
  regiao?: string | null;
  logradouro?: string | null;
  numero?: string | null;
  bairro?: string | null;
  cep?: string | null;
  cidade?: string | null;
  uf?: string | null;
  telefone?: string | null;
  email?: string | null;
  diretor?: string | null;
  modalidades?: string | null;
  turnos?: string | null;
  qtd_salas?: number | null;
  salas?: SalaCadastro[] | null;
  qtd_alunos?: number | null;
  qtd_alunos_instituicao?: number | null;
  qtd_cads?: number | null;
  situacao_imovel?: string | null;
  observacoes?: string | null;
  atualizado_por?: string | null;
  created_at?: string;
  updated_at?: string;
};

export type CAD = {
  id?: string;
  unidade_id?: string | null;
  nome: string;
  sexo?: string | null;
  matricula?: string | null;
  jornada: number;
  cargo?: string | null;
  cod_cargo?: string | null;
  situacao?: string | null;
  situacao_funcional?: string | null;
  status?: string | null;
  data_admissao?: string | null;
  vencimento?: string | null;
  cpf?: string | null;
  telefone?: string | null;
  email?: string | null;
  observacoes?: string | null;
  created_at?: string;
  updated_at?: string;
};

const CADS_INDIVIDUAIS = "cads";

export type Vistoria = {
  id?: string;
  unidade_id: string;
  unidade_nome: string;
  data_vistoria?: string | null;
  imovel_proprio_alugado?: string | null;
  responsavel?: string | null;
  uso_tipo?: string | null;
  estrutural: JsonRecord;
  fotografico: JsonRecord;
  entorno: JsonRecord;
  parecer: JsonRecord;
  nota_media?: number | null;
  etapa?: number;
  status?: string;
  created_at?: string;
  updated_at?: string;
};

export type LevantamentoPedagogico = {
  id?: string;
  unidade_id: string;
  unidade_nome: string;
  data_levantamento?: string | null;
  responsavel?: string | null;
  dados_pedagogicos: JsonRecord;
  etapa?: number;
  status?: string;
  created_at?: string;
  updated_at?: string;
};

const CADASTRO = "unidades_cadastro";
const VISTORIAS = "vistorias";
const LEVANTAMENTOS_PEDAGOGICOS = "levantamentos_pedagogicos";

export async function listarCadastros(): Promise<CadastroUnidade[]> {
  const { data, error } = await supabase
    .from(CADASTRO)
    .select("*")
    .order("updated_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as CadastroUnidade[];
}

export async function listarVistorias(): Promise<Vistoria[]> {
  const { data, error } = await supabase
    .from(VISTORIAS)
    .select("*")
    .order("updated_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as Vistoria[];
}

export async function salvarCadastro(cadastro: CadastroUnidade) {
  const { data, error } = await supabase
    .from(CADASTRO)
    .upsert(
      { ...cadastro, id: undefined },
      { onConflict: "unidade_id" },
    )
    .select()
    .single();
  if (error) throw new Error(error.message);
  return data as CadastroUnidade;
}

export async function salvarVistoria(vistoria: Vistoria) {
  const payload = {
    ...vistoria,
    nota_media: calcularNotaMedia(vistoria.estrutural ?? {}),
  };
  if (vistoria.id) {
    const { data, error } = await supabase
      .from(VISTORIAS)
      .update(payload)
      .eq("id", vistoria.id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return data as Vistoria;
  }
  const { data, error } = await supabase
    .from(VISTORIAS)
    .insert({ ...payload, id: undefined })
    .select()
    .single();
  if (error) throw new Error(error.message);
  return data as Vistoria;
}

/** Tamanho de cada página ao baixar a base de CADs do banco. */
const PAGINA_CADS = 1000;
/** Limite de segurança de páginas (evita laço infinito em bases muito grandes). */
const MAX_PAGINAS_CADS = 30;

/**
 * Lista os CADs da base.
 *
 * Importante: a API do Supabase devolve no máximo 1000 linhas por chamada.
 * Antes esta função fazia uma única requisição, então a consulta por nome
 * "não encontrava" profissionais que existiam no cadastro (ficavam fora da
 * página carregada). Agora baixamos todas as páginas até o fim da base.
 */
export async function listarCADs(unidadeId?: string): Promise<CAD[]> {
  const todos: CAD[] = [];

  for (let pagina = 0; pagina < MAX_PAGINAS_CADS; pagina++) {
    const inicio = pagina * PAGINA_CADS;
    let query = supabase.from(CADS_INDIVIDUAIS as any).select("*");

    if (unidadeId) query = query.eq("unidade_id", unidadeId);

    const { data, error } = await query.order("nome").range(inicio, inicio + PAGINA_CADS - 1);

    if (error) throw new Error(error.message);

    const lote = (data ?? []) as any as CAD[];
    todos.push(...lote);

    if (lote.length < PAGINA_CADS) break;
  }

  return todos;
}

/**
 * Consulta o banco diretamente pelos CADs cujo nome contenha o termo digitado.
 * Funciona como rede de segurança da consulta por nome quando a base local
 * ainda não foi carregada (ou veio incompleta).
 */
export async function buscarCADsPorNome(termo: string, limite = 500): Promise<CAD[]> {
  const texto = (termo ?? "").trim();
  if (texto.length < 2) return [];

  const { data, error } = await supabase
    .from(CADS_INDIVIDUAIS as any)
    .select("*")
    .ilike("nome", `%${texto}%`)
    .order("nome")
    .limit(limite);

  if (error) throw new Error(error.message);
  return (data ?? []) as any as CAD[];
}

export async function salvarCAD(cad: CAD) {
  const { data, error } = await supabase
    .from(CADS_INDIVIDUAIS as any)
    .upsert(cad)
    .select()
    .single();
  if (error) throw new Error(error.message);
  return data as any as CAD;
}

export async function excluirCAD(id: string) {
  const { error } = await supabase
    .from(CADS_INDIVIDUAIS as any)
    .delete()
    .eq("id", id);
  if (error) throw new Error(error.message);
}

export async function listarLevantamentosPedagogicos(): Promise<LevantamentoPedagogico[]> {
  const PAGINA = 1000;
  const todos: LevantamentoPedagogico[] = [];
  for (let inicio = 0; inicio < 100000; inicio += PAGINA) {
    const { data, error } = await supabase
      .from(LEVANTAMENTOS_PEDAGOGICOS as any)
      .select("*")
      .order("updated_at", { ascending: false })
      .order("id", { ascending: true })
      .range(inicio, inicio + PAGINA - 1);
    if (error) throw new Error(error.message);
    const lote = (data ?? []) as any as LevantamentoPedagogico[];
    todos.push(...lote);
    if (lote.length < PAGINA) break;
  }
  return todos;
}

export async function salvarLevantamentoPedagogico(levantamento: LevantamentoPedagogico) {
  const { data, error } = await supabase
    .from(LEVANTAMENTOS_PEDAGOGICOS as any)
    .upsert({ ...levantamento, id: undefined })
    .select()
    .single();
  if (error) throw new Error(error.message);
  return data as any as LevantamentoPedagogico;
}

export async function atualizarDadosLevantamentoPedagogico(
  id: string,
  dados_pedagogicos: Record<string, unknown>,
) {
  const { error } = await supabase
    .from(LEVANTAMENTOS_PEDAGOGICOS as any)
    .update({ dados_pedagogicos })
    .eq("id", id);
  if (error) throw new Error(error.message);
}
