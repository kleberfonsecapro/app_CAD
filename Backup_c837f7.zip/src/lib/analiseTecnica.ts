import type { Unidade } from "@/types/unidade";

/**
 * Parâmetros técnicos derivados do resumo executivo
 * "Cuiabá: quantas cuidadoras realmente precisa?"
 *  - Média nacional estimada de apoio escolar: 1 CAD : 9,5 alunos
 *  - Lei 13.146/2015 e Decreto 12.686/2025: sem proporção fixa,
 *    o apoio é definido por estudo de caso (individual, compartilhado ou intermitente)
 */
export const MEDIA_NACIONAL = 9.5; // alunos por CAD
export const META_GESTAO = 6; // meta operacional da rede (estudantes por CAD)

/** Razões de apoio por perfil de autonomia (modelo de gestão eficiente) */
export const RATIO = {
  individual: 1, // TEA nível 3 / alta dependência — 1 CAD por estudante
  compartilhado: 2, // TEA nível 2 e deficiências com apoio contínuo
  volante: 3.5, // TEA nível 1, transtornos e apoio intermitente
  revisao: 4, // sem laudo — revisão por autonomia
} as const;

export type Cenario = {
  chave: string;
  rotulo: string;
  cads: number;
  descricao: string;
};

export type AnaliseTecnica = {
  unidade: string;
  estudantes: number;
  cadsAtuais: number;
  razaoAtual: number | null;
  /** CAD necessário pelo perfil de autonomia da unidade */
  cadTecnico: number;
  /** CAD se aplicada a média nacional pura (estudantes / 9,5) */
  cadMediaNacional: number;
  /** CAD para atingir a meta de gestão (estudantes / 6) */
  cadMeta: number;
  /** faixa provável de gestão eficiente */
  faixaMin: number;
  faixaMax: number;
  /** diferença entre o quadro atual e o necessário técnico (positivo = excedente) */
  saldo: number;
  /** distorção % do quadro atual frente ao necessário técnico */
  distorcao: number;
  classificacao: "Excedente" | "Adequado" | "Déficit" | "Déficit crítico";
  prioridade: number; // 0-100, quanto maior mais urgente
  composicao: { rotulo: string; alunos: number; cads: number; regra: string }[];
  cenarios: Cenario[];
  alertas: string[];
};

const arred = (n: number) => Math.round(n * 10) / 10;

export function analisarUnidade(u: Unidade): AnaliseTecnica {
  const individualAlunos = u.suporte3;
  const compartilhadoAlunos = u.suporte2 + u.deficiencia;
  const volanteAlunos = u.suporte1 + u.transtorno;
  const revisaoAlunos = u.semLaudo;

  const composicao = [
    {
      rotulo: "Apoio individual",
      alunos: individualAlunos,
      cads: individualAlunos / RATIO.individual,
      regra: "1 CAD : 1 estudante (alta dependência / TEA nível 3)",
    },
    {
      rotulo: "Sala compartilhada",
      alunos: compartilhadoAlunos,
      cads: compartilhadoAlunos / RATIO.compartilhado,
      regra: "1 CAD : 2 estudantes compatíveis",
    },
    {
      rotulo: "Apoio volante",
      alunos: volanteAlunos,
      cads: volanteAlunos / RATIO.volante,
      regra: "1 CAD : 3 a 4 estudantes com apoio intermitente",
    },
    {
      rotulo: "Revisão por autonomia",
      alunos: revisaoAlunos,
      cads: revisaoAlunos / RATIO.revisao,
      regra: "Sem laudo — depende de avaliação caso a caso",
    },
  ];

  const cadTecnico = Math.max(
    u.estudantes > 0 ? 1 : 0,
    Math.ceil(composicao.reduce((a, c) => a + c.cads, 0)),
  );
  const cadMediaNacional = arred(u.estudantes / MEDIA_NACIONAL);
  const cadMeta = arred(u.estudantes / META_GESTAO);
  const faixaMin = Math.max(1, Math.round(cadTecnico * 0.85));
  const faixaMax = Math.max(faixaMin, Math.round(cadTecnico * 1.15));

  const saldo = u.cuidadores - cadTecnico;
  const distorcao = cadTecnico > 0 ? arred((saldo / cadTecnico) * 100) : 0;

  let classificacao: AnaliseTecnica["classificacao"] = "Adequado";
  if (distorcao > 15) classificacao = "Excedente";
  else if (distorcao < -35) classificacao = "Déficit crítico";
  else if (distorcao < -10) classificacao = "Déficit";

  const prioridade = Math.max(
    0,
    Math.min(100, Math.round(Math.max(0, -distorcao) * 0.7 + (individualAlunos / Math.max(1, u.estudantes)) * 30)),
  );

  const alertas: string[] = [];
  if (u.semLaudo > 0)
    alertas.push(
      `${u.semLaudo} estudante(s) sem laudo — necessitam avaliação técnica para definição do tipo de apoio.`,
    );
  if (u.suporte3 > u.cuidadores)
    alertas.push(
      `${u.suporte3} caso(s) de TEA nível 3 (apoio individual) para ${u.cuidadores} CAD — cobertura individual não atendida.`,
    );
  if (u.razao !== null && u.razao > MEDIA_NACIONAL)
    alertas.push(
      `Razão de ${u.razao} estudantes por CAD acima da média nacional estimada (${MEDIA_NACIONAL}).`,
    );
  if (u.cuidadores === 0 && u.estudantes > 0)
    alertas.push("Unidade sem CAD lotado apesar de possuir estudantes da educação especial.");
  if (u.integral > 0)
    alertas.push(`${u.integral} estudante(s) em tempo integral — exige cobertura de jornada ampliada.`);

  const cenarios: Cenario[] = [
    {
      chave: "edital",
      rotulo: "Quadro atual",
      cads: u.cuidadores,
      descricao: "CADs lotados hoje na unidade",
    },
    {
      chave: "nacional",
      rotulo: "Média nacional pura",
      cads: cadMediaNacional,
      descricao: `Estudantes ÷ ${MEDIA_NACIONAL} (referência comparativa Inep/MEC)`,
    },
    {
      chave: "tecnico",
      rotulo: "Necessário técnico",
      cads: cadTecnico,
      descricao: "Soma por perfil de autonomia (individual, compartilhado, volante)",
    },
    {
      chave: "meta",
      rotulo: "Meta de gestão",
      cads: cadMeta,
      descricao: `Estudantes ÷ ${META_GESTAO} (meta operacional da rede)`,
    },
  ];

  return {
    unidade: u.unidade,
    estudantes: u.estudantes,
    cadsAtuais: u.cuidadores,
    razaoAtual: u.razao,
    cadTecnico,
    cadMediaNacional,
    cadMeta,
    faixaMin,
    faixaMax,
    saldo,
    distorcao,
    classificacao,
    prioridade,
    composicao,
    cenarios,
    alertas,
  };
}

export type ConsolidadoTecnico = {
  unidades: number;
  estudantes: number;
  cadsAtuais: number;
  cadTecnico: number;
  cadMediaNacional: number;
  faixaMin: number;
  faixaMax: number;
  saldo: number;
  distorcao: number;
  deficit: number;
  excedente: number;
  adequadas: number;
  criticas: number;
  razaoAtual: number;
  razaoTecnica: number;
};

export function consolidar(analises: AnaliseTecnica[]): ConsolidadoTecnico {
  const estudantes = analises.reduce((a, x) => a + x.estudantes, 0);
  const cadsAtuais = analises.reduce((a, x) => a + x.cadsAtuais, 0);
  const cadTecnico = analises.reduce((a, x) => a + x.cadTecnico, 0);
  const cadMediaNacional = Math.round(estudantes / MEDIA_NACIONAL);
  const saldo = cadsAtuais - cadTecnico;

  return {
    unidades: analises.length,
    estudantes,
    cadsAtuais,
    cadTecnico,
    cadMediaNacional,
    faixaMin: analises.reduce((a, x) => a + x.faixaMin, 0),
    faixaMax: analises.reduce((a, x) => a + x.faixaMax, 0),
    saldo,
    distorcao: cadTecnico ? arred((saldo / cadTecnico) * 100) : 0,
    deficit: analises.filter((a) => a.classificacao.startsWith("Déficit")).length,
    excedente: analises.filter((a) => a.classificacao === "Excedente").length,
    adequadas: analises.filter((a) => a.classificacao === "Adequado").length,
    criticas: analises.filter((a) => a.classificacao === "Déficit crítico").length,
    razaoAtual: cadsAtuais ? arred(estudantes / cadsAtuais) : 0,
    razaoTecnica: cadTecnico ? arred(estudantes / cadTecnico) : 0,
  };
}
