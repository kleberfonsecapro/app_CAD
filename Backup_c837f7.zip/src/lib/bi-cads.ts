import { Unidade } from "@/types/unidade";
import { CAD } from "./cadastro-api";
import { normalizarNome } from "./matriculaFluxo";

export interface StatsZoneamento {
  regiao: string;
  unidades: number;
  estudantes: number;
  cads: number;
  carga30h: number;
  carga40h: number;
}

export interface RecadastramentoStats {
  totalCriancasAtendidas: number;
  estudantesComDeficiencia: number;
  tea: number;
  nivel1: number;
  nivel2: number;
  nivel3: number;
  nivelNaoInformado: number;
  autonomiaComSuporte: number;
  autonomiaSemSuporte: number;
  autonomiaNaoInformada: number;
  multiUnidade: number;
  sobrecargaAlunos: number; // CADs com 3 ou mais alunos
  cad30h: number;
  cad40h: number;
}

export interface Inconsistencia {
  id: string;
  tipo: 'CAD_SEM_MAPA' | 'UNIDADE_SEM_CAD' | 'DIVERGENCIA_QTD' | 'RECADASTRAMENTO_MISSING' | 'DISTORCAO_CARGA' | 'MULTI_LOTACAO';
  entidade: string;
  detalhe: string;
  valorEsperado?: number;
  valorEncontrado?: number;
}

export interface BIResult {
  stats: StatsZoneamento[];
  inconsistencias: Inconsistencia[];
  recadastramento?: RecadastramentoStats;
}

export function processarBI(unidades: Unidade[], cadsIndividuais: CAD[] = []): BIResult {
  const porRegiao = new Map<string, StatsZoneamento>();
  const inconsistencias: Inconsistencia[] = [];

  // Primeiro, processamos as unidades para pegar estudantes e regiões
  unidades.forEach((u) => {
    const r = u.regiao || "Outros";
    const current = porRegiao.get(r) || {
      regiao: r,
      unidades: 0,
      estudantes: 0,
      cads: 0,
      carga30h: 0,
      carga40h: 0,
    };

    current.unidades++;
    current.estudantes += u.estudantes || 0;
    porRegiao.set(r, current);
  });

  // Criamos um mapa de unidades normalizado para busca rápida
  const unidadesMapaNormalizado = new Map<string, Unidade>();
  unidades.forEach(u => {
    unidadesMapaNormalizado.set(normalizarNome(u.unidade), u);
  });

  // Se temos a lista real de CADs, usamos ela para as estatísticas de profissionais
  if (cadsIndividuais.length > 0) {
    const cadsPorUnidadeNormalizado = new Map<string, CAD[]>();
    
    cadsIndividuais.forEach(cad => {
      const nomeUnidadeOriginal = cad.unidade_id || "SEM UNIDADE";
      const nomeNormalizado = normalizarNome(nomeUnidadeOriginal);
      
      const list = cadsPorUnidadeNormalizado.get(nomeNormalizado) || [];
      list.push(cad);
      cadsPorUnidadeNormalizado.set(nomeNormalizado, list);

      // Check if CAD's unit exists in map
      const unidadeMap = unidadesMapaNormalizado.get(nomeNormalizado);
      
      if (!unidadeMap) {
        inconsistencias.push({
          id: `cad-${cad.id || cad.matricula}-${Math.random()}`,
          tipo: 'CAD_SEM_MAPA',
          entidade: cad.nome,
          detalhe: `Lotação "${nomeUnidadeOriginal}" não encontrada no mapa.`
        });
      }

      const r = unidadeMap?.regiao || "Outros";
      const current = porRegiao.get(r);
      if (current) {
        current.cads++;
        if (cad.jornada === 40) current.carga40h++;
        else current.carga30h++;
      }
    });

    // Verificar unidades sem CADs ou com divergência
    unidades.forEach(u => {
      const nomeNormalizado = normalizarNome(u.unidade);
      const cadsRegistrados = cadsPorUnidadeNormalizado.get(nomeNormalizado) || [];
      const qtdEsperada = u.cuidadores_real || u.cuidadores || 0;
      const qtdRegistrada = cadsRegistrados.length;

      if (qtdEsperada > 0 && qtdRegistrada === 0) {
        inconsistencias.push({
          id: `uni-vazia-${u.unidade}`,
          tipo: 'UNIDADE_SEM_CAD',
          entidade: u.unidade,
          detalhe: 'Unidade possui alunos mas não há profissionais registrados no cadastro individual.',
          valorEsperado: qtdEsperada,
          valorEncontrado: 0
        });
      } else if (qtdEsperada !== qtdRegistrada && qtdEsperada > 0) {
        inconsistencias.push({
          id: `uni-div-${u.unidade}`,
          tipo: 'DIVERGENCIA_QTD',
          entidade: u.unidade,
          detalhe: 'Divergência entre o esperado no mapa e o cadastro individual.',
          valorEsperado: qtdEsperada,
          valorEncontrado: qtdRegistrada
        });
      }
    });

    // Verificar quem não fez o recadastramento (CADs que estão na base mas não tem observação de recadastramento)
    cadsIndividuais.forEach(cad => {
      const isRecadastrado = cad.observacoes?.includes('Recadastramento:');
      if (!isRecadastrado) {
        inconsistencias.push({
          id: `missing-rec-${cad.id || cad.matricula}`,
          tipo: 'RECADASTRAMENTO_MISSING',
          entidade: cad.nome,
          detalhe: `Profissional consta na base principal mas NÃO realizou o recadastramento 2026.`
        });
      }
    });

    // Análise de Distorções baseada no arquivo de recadastramento
    inconsistencias.push({
      id: 'distorcao-multi-1',
      tipo: 'MULTI_LOTACAO',
      entidade: 'JOSEFINA RITA DE SOUZA BRITO',
      detalhe: 'Atuando em: EMEB PADRE RAIMUNDO, CMEI ENG. OSCAR AMELITO, EMEB JOANA DARK.',
      valorEsperado: 1,
      valorEncontrado: 3
    });

    inconsistencias.push({
      id: 'distorcao-multi-2',
      tipo: 'MULTI_LOTACAO',
      entidade: 'JUCICLEIDE AUXILIADORA XAVIER',
      detalhe: 'Atuando em: CRECHE TERTULIANA, EMEB ALZIRA VALLADARES.',
      valorEsperado: 1,
      valorEncontrado: 2
    });

    inconsistencias.push({
      id: 'distorcao-sobrecarga-1',
      tipo: 'DISTORCAO_CARGA',
      entidade: 'DAICY MARIA RAYMUNDO',
      detalhe: 'Sobrecarga crítica: Atende 4 alunos simultaneamente.',
      valorEsperado: 2,
      valorEncontrado: 4
    });

    inconsistencias.push({
      id: 'distorcao-sobrecarga-2',
      tipo: 'DISTORCAO_CARGA',
      entidade: 'EDINETH SEBASTIANA',
      detalhe: 'Sobrecarga crítica: Atende 4 alunos simultaneamente.',
      valorEsperado: 2,
      valorEncontrado: 4
    });



  } else {
    // Fallback para dados estáticos se a lista real não estiver disponível
    unidades.forEach((u) => {
      const r = u.regiao || "Outros";
      const current = porRegiao.get(r)!;
      current.cads += u.cuidadores_real || u.cuidadores || 0;
      current.carga30h += u.cads_30h || (u.cuidadores - (u.carga40 || 0)) || 0;
      current.carga40h += u.cads_40h || u.carga40 || 0;
    });
  }

  // Dados do recadastramento conforme planilha Recadastramento_CAD_geral_2_1-3.xlsx
  const recadastramento: RecadastramentoStats = {
    totalCriancasAtendidas: 1830,
    estudantesComDeficiencia: 1464, // Aproximado baseado nos dados TEA e outros
    tea: 1204,
    nivel1: 289,
    nivel2: 454,
    nivel3: 200,
    nivelNaoInformado: 887,
    autonomiaComSuporte: 330,
    autonomiaSemSuporte: 380,
    autonomiaNaoInformada: 1120,
    multiUnidade: 29,
    sobrecargaAlunos: 83,
    cad30h: 1083,
    cad40h: 747
  };

  return {
    stats: Array.from(porRegiao.values()).sort((a, b) => b.estudantes - a.estudantes),
    inconsistencias,
    recadastramento
  };
}
