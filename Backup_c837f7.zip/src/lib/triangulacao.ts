import type { Unidade } from "@/types/unidade";

export const META_RAZAO = 6;

export function distanciaMetros(
  a: { lat: number; lon: number },
  b: { lat: number; lon: number },
): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export type Aresta = {
  a: string;
  b: string;
  metros: number;
  coords: [[number, number], [number, number]];
};

export type Transferencia = {
  origem: string;
  destino: string;
  cads: number;
  metros: number;
};

export type Cluster = {
  id: string;
  nome: string;
  unidades: Unidade[];
  arestas: Aresta[];
  regioes: string[];
  estudantes: number;
  cuidadores: number;
  razaoAtual: number | null;
  cadsIdeais: number;
  razaoPos: number | null;
  transferencias: Transferencia[];
  cadsRealocados: number;
  cadsExcedentes: number;
  unidadesAcimaMeta: number;
  unidadesAbaixoMeta: number;
  raioMedio: number;
  meta: boolean;
};

/** CADs máximos para manter pelo menos META_RAZAO estudantes por CAD. */
export function cadsIdeais(estudantes: number, meta = META_RAZAO): number {
  if (estudantes <= 0) return 0;
  return Math.max(1, Math.floor(estudantes / meta));
}

export function razao(est: number, cads: number): number | null {
  return cads > 0 ? Number((est / cads).toFixed(2)) : null;
}

/** Agrupa unidades conectadas por proximidade (raio em metros) via union-find. */
export function construirClusters(
  unidades: Unidade[],
  raio = 1000,
  meta = META_RAZAO,
): Cluster[] {
  const validas = unidades.filter((u) => Number.isFinite(u.lat) && Number.isFinite(u.lon));
  const parent = validas.map((_, i) => i);
  const find = (i: number): number => (parent[i] === i ? i : (parent[i] = find(parent[i])));
  const union = (i: number, j: number) => {
    const a = find(i);
    const b = find(j);
    if (a !== b) parent[a] = b;
  };

  const arestas: Aresta[] = [];
  for (let i = 0; i < validas.length; i++) {
    for (let j = i + 1; j < validas.length; j++) {
      const d = distanciaMetros(validas[i], validas[j]);
      if (d <= raio) {
        union(i, j);
        arestas.push({
          a: validas[i].unidade,
          b: validas[j].unidade,
          metros: Math.round(d),
          coords: [
            [validas[i].lat, validas[i].lon],
            [validas[j].lat, validas[j].lon],
          ],
        });
      }
    }
  }

  const grupos = new Map<number, Unidade[]>();
  validas.forEach((u, i) => {
    const r = find(i);
    if (!grupos.has(r)) grupos.set(r, []);
    grupos.get(r)!.push(u);
  });

  const clusters: Cluster[] = [];
  for (const [, membros] of grupos) {
    if (membros.length < 2) continue;
    const nomes = new Set(membros.map((m) => m.unidade));
    const eArestas = arestas.filter((e) => nomes.has(e.a) && nomes.has(e.b));

    const estudantes = membros.reduce((a, u) => a + u.estudantes, 0);
    const cuidadores = membros.reduce((a, u) => a + u.cuidadores, 0);

    // Excedentes e déficits por unidade em relação à meta
    const saldos = membros.map((u) => ({
      unidade: u,
      alvo: cadsIdeais(u.estudantes, meta),
      saldo: u.cuidadores - cadsIdeais(u.estudantes, meta),
    }));

    const doadores = saldos.filter((s) => s.saldo > 0).sort((a, b) => b.saldo - a.saldo);
    const receptores = saldos.filter((s) => s.saldo < 0).sort((a, b) => a.saldo - b.saldo);

    const transferencias: Transferencia[] = [];
    const disponivel = doadores.map((d) => ({ ...d, restante: d.saldo }));
    for (const r of receptores) {
      let falta = -r.saldo;
      const ordenados = [...disponivel]
        .filter((d) => d.restante > 0)
        .sort(
          (x, y) =>
            distanciaMetros(x.unidade, r.unidade) - distanciaMetros(y.unidade, r.unidade),
        );
      for (const d of ordenados) {
        if (falta <= 0) break;
        const qtd = Math.min(falta, d.restante);
        d.restante -= qtd;
        falta -= qtd;
        transferencias.push({
          origem: d.unidade.unidade,
          destino: r.unidade.unidade,
          cads: qtd,
          metros: Math.round(distanciaMetros(d.unidade, r.unidade)),
        });
      }
    }

    const cadsRealocados = transferencias.reduce((a, t) => a + t.cads, 0);
    const cadsExcedentes = disponivel.reduce((a, d) => a + d.restante, 0);
    const alvoTotal = saldos.reduce((a, s) => a + s.alvo, 0);
    const razaoPos = razao(estudantes, Math.min(cuidadores, alvoTotal));
    const raioMedio = eArestas.length
      ? Math.round(eArestas.reduce((a, e) => a + e.metros, 0) / eArestas.length)
      : 0;

    const ordenadoPorEst = [...membros].sort((a, b) => b.estudantes - a.estudantes);

    clusters.push({
      id: ordenadoPorEst[0].unidade,
      nome: `Triangulação ${ordenadoPorEst[0].bairro || ordenadoPorEst[0].regiao} · ${membros.length} unidades`,
      unidades: ordenadoPorEst,
      arestas: eArestas,
      regioes: Array.from(new Set(membros.map((m) => m.regiao))).sort(),
      estudantes,
      cuidadores,
      razaoAtual: razao(estudantes, cuidadores),
      cadsIdeais: alvoTotal,
      razaoPos,
      transferencias,
      cadsRealocados,
      cadsExcedentes,
      unidadesAcimaMeta: saldos.filter((s) => (s.unidade.razao ?? 0) >= meta).length,
      unidadesAbaixoMeta: saldos.filter((s) => (s.unidade.razao ?? 0) < meta).length,
      raioMedio,
      meta: (razaoPos ?? 0) >= meta,
    });
  }

  return clusters.sort((a, b) => b.estudantes - a.estudantes);
}
