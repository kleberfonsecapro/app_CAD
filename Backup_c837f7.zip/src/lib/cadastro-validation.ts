import { z } from "zod";

/** Schema compartilhado entre a API de cadastro e a API de vistoria (celular). */
export const salaSchema = z.object({
  serie: z.string().trim().max(20),
  cads_matutino: z.number().int().min(0).max(50).optional().nullable(),
  cads_vespertino: z.number().int().min(0).max(50).optional().nullable(),
  alunos_matutino: z.number().int().min(0).max(200).optional().nullable(),
  alunos_vespertino: z.number().int().min(0).max(200).optional().nullable(),
});

export const cadastroSchema = z.object({
  unidade_id: z.string().trim().min(2).max(200),
  nome: z.string().trim().min(2).max(200),
  inep: z.string().trim().max(30).optional().nullable(),
  regiao: z.string().trim().max(40).optional().nullable(),
  logradouro: z.string().trim().max(200).optional().nullable(),
  numero: z.string().trim().max(20).optional().nullable(),
  bairro: z.string().trim().max(120).optional().nullable(),
  cep: z.string().trim().max(12).optional().nullable(),
  cidade: z.string().trim().max(80).optional().nullable(),
  uf: z.string().trim().max(2).optional().nullable(),
  telefone: z.string().trim().max(40).optional().nullable(),
  email: z.string().trim().max(160).optional().nullable(),
  diretor: z.string().trim().max(160).optional().nullable(),
  modalidades: z.string().trim().max(300).optional().nullable(),
  turnos: z.string().trim().max(120).optional().nullable(),
  qtd_salas: z.number().int().min(0).max(500).optional().nullable(),
  salas: z.array(salaSchema).max(200).optional(),
  qtd_alunos: z.number().int().min(0).max(20000).optional().nullable(),
  qtd_alunos_instituicao: z.number().int().min(0).max(50000).optional().nullable(),
  qtd_cads: z.number().int().min(0).max(500).optional().nullable(),
  situacao_imovel: z.string().trim().max(60).optional().nullable(),
  observacoes: z.string().trim().max(2000).optional().nullable(),
  atualizado_por: z.string().trim().max(160).optional().nullable(),
});

export type CadastroPayload = z.infer<typeof cadastroSchema>;
