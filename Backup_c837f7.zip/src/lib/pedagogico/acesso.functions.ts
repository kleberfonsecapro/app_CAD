import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const verificarSenhaPedagogico = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ senha: z.string().max(100) }).parse(d))
  .handler(async ({ data }) => {
    const MESTRA = "mestra-smpo";
    return { ok: data.senha === MESTRA };
  });
