// Definição das etapas e campos do formulário de LEVANTAMENTO PEDAGÓGICO
// Baseada no fluxo da vistoria, mas focada em indicadores educacionais

export const ETAPAS_PEDAGOGICAS = [
  { id: 1, label: "Identificação" },
  { id: 2, label: "Sala de Aula" },
] as const;

export function calcularNotaPedagogica(dados: Record<string, unknown>) {
  // Como removemos os itens de avaliação, retornamos null ou uma lógica simplificada se necessário
  return null;
}
