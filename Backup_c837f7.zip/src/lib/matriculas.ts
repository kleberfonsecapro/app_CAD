// Camada de dados do Painel de Matrículas da RME de Cuiabá (fonte: SIGEEC – CMPE/SME)
const BASE_A =
  "https://docs.google.com/spreadsheets/d/e/2PACX-1vRLLwC0i0TN6VqqrBj8gaSGawAkrxy4NwHFnLamNys62fT9Q94TeVKo7v8NmzAxo7wKBqEen4g3Xl_G/pub";
const BASE_B =
  "https://docs.google.com/spreadsheets/d/e/2PACX-1vRUG_t2xD8XDjPN50iS4-YAFjG3chCSbfnSJJzxTiGB9m3ADfXfE3AqnTolR2wms54tKWazw4l3t35_/pub";

export const CSV_URLS = {
  diario: `${BASE_A}?gid=350107829&single=true&output=csv`,
  unidades: `${BASE_A}?gid=115258057&single=true&output=csv`,
  canceladas: `${BASE_A}?gid=1338670254&single=true&output=csv`,
  filantropicas: `${BASE_A}?gid=637590009&single=true&output=csv`,
  vagas: `${BASE_B}?gid=43877016&single=true&output=csv`,
};

export function parseCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (quoted) {
      if (ch === '"' && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (ch === '"') quoted = false;
      else cur += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      out.push(cur.trim());
      cur = "";
    } else cur += ch;
  }
  out.push(cur.trim());
  return out;
}

export const num = (v?: string) => {
  if (!v || v === "-" || v === "") return 0;
  const n = Number(v.replace(/\./g, "").replace(",", "."));
  return isNaN(n) ? 0 : n;
};

async function getLines(url: string) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("Falha ao carregar dados da planilha");
  const text = await res.text();
  return text.split("\n").filter((l) => l.trim() !== "");
}

// ---------- Série diária ----------
export type DiaRegistro = {
  data: string;
  diaSemana: string;
  g0Bercario: number;
  g1Maternal: number;
  g2JardimI: number;
  g3JardimII: number;
  g3JardimIIEscolar: number;
  g4PreEscolaI: number;
  g5PreEscolaII: number;
  ano1: number;
  ano2: number;
  ano3: number;
  ano4: number;
  ano5: number;
  eja: number;
  total: number;
  evolucao: number;
};

export const ENTURMACAO_LABEL: Record<string, string> = {
  g0Bercario: "G0 - Berçário",
  g1Maternal: "G1 - Maternal",
  g2JardimI: "G2 - Jardim I",
  g3JardimII: "G3 - Jardim II",
  g3JardimIIEscolar: "G3 - Jardim II Escolar",
  g4PreEscolaI: "G4 - Pré-Escola I",
  g5PreEscolaII: "G5 - Pré-Escola II",
  ano1: "1º Ano",
  ano2: "2º Ano",
  ano3: "3º Ano",
  ano4: "4º Ano",
  ano5: "5º Ano",
  eja: "EJA - 1ª Fase",
};

export async function fetchDiario(): Promise<DiaRegistro[]> {
  const lines = await getLines(CSV_URLS.diario);
  const out: DiaRegistro[] = [];
  for (const line of lines) {
    const c = parseCsvLine(line);
    if (c.length < 17) continue;
    const data = (c[0] || "").replace(/"/g, "");
    if (!data || data === "Data" || !/^\d{2}\/\d{2}\/\d{4}$/.test(data)) continue;
    out.push({
      data,
      diaSemana: (c[16] || "").replace(/"/g, ""),
      g0Bercario: num(c[1]),
      g1Maternal: num(c[2]),
      g2JardimI: num(c[3]),
      g3JardimII: num(c[4]),
      g3JardimIIEscolar: num(c[5]),
      g4PreEscolaI: num(c[6]),
      g5PreEscolaII: num(c[7]),
      ano1: num(c[8]),
      ano2: num(c[9]),
      ano3: num(c[10]),
      ano4: num(c[11]),
      ano5: num(c[12]),
      eja: num(c[13]),
      total: num(c[14]),
      evolucao: num(c[15]),
    });
  }
  return out;
}

// ---------- Matrículas por unidade (2020–2026) ----------
export type UnidadeMatricula = {
  unidade: string;
  2020: number;
  2021: number;
  2022: number;
  2023: number;
  2024: number;
  2025: number;
  2026: number;
};

export const ANOS = [2020, 2021, 2022, 2023, 2024, 2025, 2026] as const;

export async function fetchUnidades(): Promise<UnidadeMatricula[]> {
  const lines = await getLines(CSV_URLS.unidades);
  const out: UnidadeMatricula[] = [];
  for (const line of lines) {
    const c = parseCsvLine(line);
    if (c.length < 9) continue;
    const idx = c[0]?.trim();
    const nome = c[1]?.replace(/"/g, "");
    if (!idx || isNaN(Number(idx)) || !nome) continue;
    if (nome === "Unidade Educacional" || nome.toLowerCase().includes("total de matrículas")) continue;
    out.push({
      unidade: nome,
      2020: num(c[2]),
      2021: num(c[3]),
      2022: num(c[4]),
      2023: num(c[5]),
      2024: num(c[6]),
      2025: num(c[7]),
      2026: num(c[8]),
    });
  }
  return out;
}

// ---------- Solicitações canceladas ----------
export type ItemEnturmacao = { enturmacao: string; quantidade: number };

export async function fetchCanceladas(): Promise<{ items: ItemEnturmacao[]; total: number }> {
  const lines = await getLines(CSV_URLS.canceladas);
  const items: ItemEnturmacao[] = [];
  let total = 0;
  for (let i = 1; i <= 4 && i < lines.length; i++) {
    const c = parseCsvLine(lines[i]);
    const enturmacao = (c[0] || "").trim();
    const quantidade = num(c[1]);
    if (enturmacao) {
      items.push({ enturmacao, quantidade });
      total += quantidade;
    }
  }
  return { items, total };
}

// ---------- Filantrópicas conveniadas (agregado) ----------
const FIL_ENTURMACOES = [
  "G0 - BERÇÁRIO",
  "G1 - MATERNAL",
  "G2 - JARDIM I",
  "G3 - JARDIM II",
  "G4 - PRÉ ESCOLA I",
  "G5 - PRÉ ESCOLA II",
];

export async function fetchFilantropicas(): Promise<{ items: ItemEnturmacao[]; total: number }> {
  const lines = await getLines(CSV_URLS.filantropicas);
  const items: ItemEnturmacao[] = [];
  const vistos = new Set<string>();
  for (const line of lines) {
    const c = parseCsvLine(line);
    const enturmacao = (c[15] || "").trim();
    const valor = (c[16] || "").trim();
    if (FIL_ENTURMACOES.includes(enturmacao) && valor && !vistos.has(enturmacao)) {
      const q = Number(valor);
      if (!isNaN(q) && q > 0) {
        items.push({ enturmacao, quantidade: q });
        vistos.add(enturmacao);
      }
    }
    if (vistos.size >= 6) break;
  }
  const total = items.reduce((s, i) => s + i.quantidade, 0);
  return { items, total };
}

// ---------- Vagas livres por unidade ----------
export type VagaGrupo = { chave: string; label: string; cols: number[] };

export const VAGAS_GRUPOS: VagaGrupo[] = [
  { chave: "g0", label: "G0 - Berçário", cols: [3] },
  { chave: "g1", label: "G1 - Maternal", cols: [4] },
  { chave: "g2", label: "G2 - Jardim I", cols: [5] },
  { chave: "g3", label: "G3 - Jardim II", cols: [6, 7, 8] },
  { chave: "g4", label: "G4 - Pré-escola I", cols: [9, 10, 11] },
  { chave: "g5", label: "G5 - Pré-escola II", cols: [12, 13, 14] },
  { chave: "a1", label: "1º Ano", cols: [15, 16, 17] },
  { chave: "a2", label: "2º Ano", cols: [18, 19, 20] },
  { chave: "a3", label: "3º Ano", cols: [21, 22, 23] },
  { chave: "a4", label: "4º Ano", cols: [24, 25, 26] },
  { chave: "a5", label: "5º Ano", cols: [27, 28, 29] },
];

export type VagaUnidade = {
  bairro: string;
  tipo: string;
  unidade: string;
  valores: Record<string, number>;
  total: number;
};

export async function fetchVagas(): Promise<VagaUnidade[]> {
  const lines = await getLines(CSV_URLS.vagas);
  const out: VagaUnidade[] = [];
  for (let i = 2; i < lines.length; i++) {
    const c = parseCsvLine(lines[i]);
    const bairro = (c[0] || "").trim();
    if (bairro.toUpperCase().startsWith("TOTAL")) break;
    const unidade = (c[2] || "").trim();
    if (!unidade) continue;
    const valores: Record<string, number> = {};
    let total = 0;
    for (const g of VAGAS_GRUPOS) {
      const v = g.cols.reduce((s, col) => s + num(c[col] || ""), 0);
      valores[g.chave] = v;
      total += v;
    }
    out.push({ bairro, tipo: (c[1] || "").trim(), unidade, valores, total });
  }
  return out;
}

// ---------- Série histórica por enturmação ----------
export const HISTORICO = [
  { enturmacao: "G0 - Berçário", 2020: 683, 2021: 756, 2022: 784, 2023: 830, 2024: 909, 2025: 1121, 2026: 970 },
  { enturmacao: "G1 - Maternal", 2020: 1258, 2021: 1633, 2022: 1777, 2023: 2187, 2024: 2365, 2025: 2632, 2026: 2558 },
  { enturmacao: "G2 - Jardim I", 2020: 3107, 2021: 3211, 2022: 3155, 2023: 3327, 2024: 3429, 2025: 3809, 2026: 3726 },
  { enturmacao: "G3 - Jardim II", 2020: 3470, 2021: 3595, 2022: 3582, 2023: 3863, 2024: 3837, 2025: 4215, 2026: 4322 },
  { enturmacao: "G3 - Jardim II Escolar", 2020: 209, 2021: 189, 2022: 223, 2023: 224, 2024: 219, 2025: 184, 2026: 103 },
  { enturmacao: "G4 - Pré-Escola I", 2020: 5723, 2021: 5328, 2022: 5613, 2023: 6074, 2024: 6003, 2025: 5898, 2026: 6063 },
  { enturmacao: "G5 - Pré-Escola II", 2020: 6386, 2021: 6298, 2022: 5833, 2023: 6395, 2024: 6603, 2025: 6308, 2026: 6219 },
  { enturmacao: "1º Ano", 2020: 6239, 2021: 6722, 2022: 6785, 2023: 6479, 2024: 6797, 2025: 6921, 2026: 6715 },
  { enturmacao: "2º Ano", 2020: 5881, 2021: 6262, 2022: 6502, 2023: 6898, 2024: 6563, 2025: 6861, 2026: 7034 },
  { enturmacao: "3º Ano", 2020: 6093, 2021: 5958, 2022: 6108, 2023: 6555, 2024: 6897, 2025: 6658, 2026: 6936 },
  { enturmacao: "4º Ano", 2020: 3904, 2021: 4518, 2022: 5675, 2023: 6056, 2024: 6933, 2025: 7073, 2026: 6707 },
  { enturmacao: "5º Ano", 2020: 3799, 2021: 3996, 2022: 4259, 2023: 4040, 2024: 6677, 2025: 6939, 2026: 7141 },
  { enturmacao: "EJA - 1ª Fase", 2020: 354, 2021: 255, 2022: 234, 2023: 630, 2024: 7, 2025: 9, 2026: 4 },
] as const;

export const HIST_KEY_BY_LABEL: Record<string, keyof DiaRegistro> = {
  "G0 - Berçário": "g0Bercario",
  "G1 - Maternal": "g1Maternal",
  "G2 - Jardim I": "g2JardimI",
  "G3 - Jardim II": "g3JardimII",
  "G3 - Jardim II Escolar": "g3JardimIIEscolar",
  "G4 - Pré-Escola I": "g4PreEscolaI",
  "G5 - Pré-Escola II": "g5PreEscolaII",
  "1º Ano": "ano1",
  "2º Ano": "ano2",
  "3º Ano": "ano3",
  "4º Ano": "ano4",
  "5º Ano": "ano5",
  "EJA - 1ª Fase": "eja",
};

export const fmt = (n: number) => n.toLocaleString("pt-BR");
