import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

import type { Unidade } from "@/types/unidade";
import { enderecoCompleto } from "@/lib/endereco";
import { COR_CLASSE, COR_INTERVENCAO, type Criticidade } from "@/lib/criticidade";
import { COR_TENDENCIA, type FluxoMatricula } from "@/lib/matriculaFluxo";
import {
  CONFIG_PADRAO,
  ROTULO_FAIXA,
  corPorRazao,
  faixaPorRazao,
  raioPorCads,
  type ConfigPadroes,
} from "@/lib/configPadroes";

export type { Unidade };

const esc = (s: unknown) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string,
  );

function blocoFluxo(f?: FluxoMatricula) {
  if (!f) return "";
  const max = Math.max(1, ...f.serie.map((s) => s.valor));
  const barras = f.serie
    .map(
      (s) =>
        `<div class="ue-spark-col"><i style="height:${Math.max(4, (s.valor / max) * 100)}%"></i><span>${String(
          s.ano,
        ).slice(2)}</span><b>${esc(s.valor)}</b></div>`,
    )
    .join("");
  const sinal = f.variacaoTotal > 0 ? "+" : "";
  const sinalAno = f.variacaoAno > 0 ? "+" : "";
  return `
    <div class="ue-pop-crit" style="--crit:${COR_TENDENCIA[f.classe]}">
      <p class="ue-pop-crit-tag">${esc(f.segmento)} · ${esc(f.classe)} (${sinal}${f.variacaoPct}% de 2020 a 2026)</p>
      <div class="ue-pop-grid">
        <div><span>Matrículas 2026</span><strong>${esc(f.m2026)}</strong></div>
        <div><span>Δ 2020→2026</span><strong>${sinal}${esc(f.variacaoTotal)}</strong></div>
        <div><span>Δ 2025→2026</span><strong>${sinalAno}${esc(f.variacaoAno)}</strong></div>
      </div>
      <p class="ue-pop-sub">Evolução das matrículas (SIGEEC) · pico em ${esc(f.pico.ano)} com ${esc(
        f.pico.valor,
      )}</p>
      <div class="ue-spark">${barras}</div>
    </div>`;
}


function blocoCriticidade(c?: Criticidade) {
  if (!c) return "";
  const mov = c.movimentos.length
    ? `<ul class="ue-pop-list">${c.movimentos
        .map(
          (m) =>
            `<li>Ceder <strong>${m.cads} CAD</strong> para <strong>${esc(m.destino)}</strong> · ${m.metros} m</li>`,
        )
        .join("")}</ul>`
    : "";
  const org = c.origens.length
    ? `<ul class="ue-pop-list">${c.origens
        .map(
          (o) =>
            `<li>Receber <strong>${o.cads} CAD</strong> de <strong>${esc(o.origem)}</strong> · ${o.metros} m</li>`,
        )
        .join("")}</ul>`
    : "";
  const riscos = c.riscos.length
    ? `<ul class="ue-pop-list ue-pop-risco">${c.riscos.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>`
    : "";
  const prio = c.prioridadeTop20
    ? `<p class="ue-pop-prio">🔥 Prioridade máxima de intervenção — #${c.rankIntervencao} entre os 20% mais críticos · índice ${c.intervencao}/100</p>`
    : `<p class="ue-pop-sub">Índice de intervenção ${c.intervencao}/100 · posição #${c.rankIntervencao}</p>`;
  const fat = c.fatores.length
    ? `<ul class="ue-pop-list">${c.fatores.map((f) => `<li>${esc(f)}</li>`).join("")}</ul>`
    : "";
  return `
    <div class="ue-pop-crit" style="--crit:${c.prioridadeTop20 ? COR_INTERVENCAO : COR_CLASSE[c.classe]}">
      <p class="ue-pop-crit-tag">${esc(c.classe)} · criticidade ${c.score}/100</p>
      ${prio}
      ${fat ? `<p class="ue-pop-sub">Necessidades de saneamento/reorganização</p>${fat}` : ""}
      <div class="ue-pop-grid">
        <div><span>CAD atual</span><strong>${c.analise.cadsAtuais}</strong></div>
        <div><span>CAD técnico</span><strong>${c.analise.cadTecnico}</strong></div>
        <div><span>Saldo</span><strong>${c.analise.saldo > 0 ? "+" : ""}${c.analise.saldo}</strong></div>
      </div>
      ${mov ? `<p class="ue-pop-sub">Plano de remanejamento (raio de análise)</p>${mov}` : ""}
      ${org ? `<p class="ue-pop-sub">Reforço sugerido</p>${org}` : ""}
      ${riscos ? `<p class="ue-pop-sub">Riscos identificados</p>${riscos}` : ""}
    </div>`;
}

function popupHtml(
  u: Unidade,
  metric: keyof Unidade,
  v: number,
  label: string,
  crit?: Criticidade,
  fluxo?: FluxoMatricula,
) {
  return `
  <div class="ue-pop">
    <div class="ue-pop-head">
      <span class="ue-pop-tag">Região ${esc(u.regiao)}${fluxo ? ` · ${esc(fluxo.segmento)}` : ""}</span>
      <h3>${esc(u.unidade)}</h3>
      <p class="ue-pop-addr"><span>Endereço:</span> ${esc(enderecoCompleto(u))}${
        u.coordenadaAproximada ? " <em>(localização aproximada)</em>" : ""
      }</p>
      ${u.semCadastro ? `<p class="ue-pop-addr"><strong>Unidade sem cadastro de CAD</strong> — incluída pela Agenda Telefônica da Rede Municipal</p>` : ""}
    </div>
    <div class="ue-pop-hero">
      <span>${esc(label)}</span>
      <strong>${esc(v)}</strong>
    </div>
    <div class="ue-pop-grid">
      <div><span>Estudantes</span><strong>${esc(u.estudantes)}</strong></div>
      <div><span>Cuidadores (CAD)</span><strong>${esc(u.cuidadores)}</strong></div>
      <div><span>Estudantes/CAD</span><strong>${esc(u.razao ?? "—")}</strong></div>
      <div><span>Casos TEA</span><strong>${esc(u.tea)}</strong></div>
      <div><span>Sem laudo</span><strong>${esc(u.semLaudo)}</strong></div>
      <div><span>TEA nível 3</span><strong>${esc(u.suporte3)}</strong></div>
    </div>
    ${blocoFluxo(fluxo)}
    ${blocoCriticidade(crit)}
    <p class="ue-pop-foot">Matutino ${esc(u.matutino)} · Vespertino ${esc(u.vespertino)} · Integral ${esc(
      u.integral,
    )} · CADs 40h ${esc(u.carga40)}</p>
  </div>`;
}

export default function HeatMap({
  unidades,
  metric,
  metricLabel,
  selected,
  onSelect,
  arestas = [],
  focoCluster = null,
  criticidade,
  modoCriticidade = false,
  fluxo,
  modoFluxo = false,
  config = CONFIG_PADRAO,
  modoPadrao = true,
}: {
  unidades: Unidade[];
  metric: keyof Unidade;
  metricLabel: string;
  selected: string | null;
  onSelect: (u: string) => void;
  arestas?: { coords: [[number, number], [number, number]]; metros: number }[];
  focoCluster?: string | null;
  criticidade?: Map<string, Criticidade>;
  modoCriticidade?: boolean;
  fluxo?: Map<string, FluxoMatricula>;
  modoFluxo?: boolean;
  config?: ConfigPadroes;
  modoPadrao?: boolean;
}) {

  const el = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const layer = useRef<L.LayerGroup | null>(null);
  const linhas = useRef<L.LayerGroup | null>(null);
  const markers = useRef<Record<string, L.CircleMarker>>({});


  useEffect(() => {
    if (!el.current || map.current) return;
    const m = L.map(el.current, { scrollWheelZoom: true, zoomControl: true }).setView(
      [-15.6, -56.1],
      11,
    );
    map.current = m;

    // Pane dedicado aos rótulos (ruas/bairros) — fica ACIMA dos círculos do mapa de calor
    m.createPane("rotulos");
    const rotulosPane = m.getPane("rotulos")!;
    rotulosPane.style.zIndex = "650";
    rotulosPane.style.pointerEvents = "none";

    // Mapas gratuitos, sem chave de acesso
    const osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap",
      maxZoom: 19,
    });
    const osmHot = L.tileLayer("https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap, HOT",
      maxZoom: 19,
    });
    const esriRuas = L.tileLayer(
      "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
      { attribution: "Tiles &copy; Esri", maxZoom: 19 },
    );
    const esriSatelite = L.tileLayer(
      "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      { attribution: "Tiles &copy; Esri", maxZoom: 19 },
    );

    osm.addTo(m);

    // Se o servidor principal falhar, troca automaticamente para o Esri
    let trocou = false;
    osm.on("tileerror", () => {
      if (trocou) return;
      trocou = true;
      m.removeLayer(osm);
      esriRuas.addTo(m);
    });

    L.control
      .layers(
        {
          "OpenStreetMap": osm,
          "OpenStreetMap (humanitário)": osmHot,
          "Ruas (Esri)": esriRuas,
          "Satélite (Esri)": esriSatelite,
        },
        undefined,
        { position: "topright", collapsed: true },
      )
      .addTo(m);

    L.control.scale({ imperial: false, position: "bottomleft" }).addTo(m);

    layer.current = L.layerGroup().addTo(m);
    linhas.current = L.layerGroup().addTo(m);
  }, []);

  // Traçados da triangulação (escolas a até X metros)
  useEffect(() => {
    if (!linhas.current) return;
    linhas.current.clearLayers();
    arestas.forEach((a) => {
      L.polyline(a.coords, {
        color: "hsl(45 95% 55%)",
        weight: 3,
        opacity: 0.9,
        dashArray: "6 6",
      })
        .bindTooltip(`${a.metros} m`, { sticky: true })
        .addTo(linhas.current!);
    });
    if (arestas.length && map.current && focoCluster) {
      const bounds = L.latLngBounds(arestas.flatMap((a) => a.coords.map((c) => L.latLng(c[0], c[1]))));
      map.current.fitBounds(bounds, { padding: [60, 60], maxZoom: 16 });
    }
  }, [arestas, focoCluster]);



  useEffect(() => {
    if (!layer.current || !map.current) return;
    layer.current.clearLayers();
    markers.current = {};
    const values = unidades.map((u) => Number(u[metric]) || 0);
    const max = Math.max(1, ...values);
    const porNome = new Map(unidades.map((u) => [u.unidade, u]));
    const maxCads = Math.max(1, ...unidades.map((u) => Number(u.cuidadores) || 0));

    unidades.forEach((u) => {
      const v = Number(u[metric]) || 0;
      const t = v / max;
      const hue = 190 - t * 190;
      const crit = criticidade?.get(u.unidade);
      const flx = fluxo?.get(u.unidade);
      const semCad = !!u.semCadastro || (Number(u.cuidadores) || 0) === 0;

      const quente = !!crit?.prioridadeTop20;
      const corFluxo = modoFluxo && flx ? COR_TENDENCIA[flx.classe] : null;

      const cor = corFluxo
        ? corFluxo
        : quente
        ? COR_INTERVENCAO
        : semCad
          ? "hsl(215 15% 45%)"
          : modoCriticidade && crit
            ? COR_CLASSE[crit.classe]
            : `hsl(${hue} 95% 45%)`;
      const preenche = corFluxo
        ? corFluxo
        : quente
        ? COR_INTERVENCAO
        : semCad
          ? "hsl(215 15% 60%)"
          : modoCriticidade && crit
            ? COR_CLASSE[crit.classe]
            : `hsl(${hue} 95% 50%)`;
      const raio = corFluxo
        ? 6 + Math.sqrt(Math.min(600, Math.abs(flx!.variacaoTotal))) * 1.6
        : semCad
        ? 6
        : modoCriticidade && crit
          ? 7 + Math.sqrt(Math.max(crit.excedente, crit.deficit)) * 5 + crit.score / 12
          : 5 + Math.sqrt(t) * 18;
      const critico =
        !semCad &&
        modoCriticidade &&
        crit &&
        (crit.classe === "Excedente crítico" || crit.classe === "Déficit crítico");

      if (quente) {
        // halo "quente" — 20% que mais necessitam de intervenção
        L.circleMarker([u.lat, u.lon], {
          radius: (semCad ? 10 : raio) + 10 + (crit!.intervencao / 100) * 10,
          color: COR_INTERVENCAO,
          weight: 1,
          opacity: 0.5,
          fillColor: COR_INTERVENCAO,
          fillOpacity: 0.16,
          interactive: false,
        }).addTo(layer.current!);
      }

      const padraoAtivo = modoPadrao && !modoFluxo;
      const corFinal = semCad
        ? "hsl(215 12% 45%)"
        : padraoAtivo
        ? corPorRazao(u.razao, config)
        : cor;
      const preencheFinal = semCad
        ? "hsl(215 12% 62%)"
        : padraoAtivo
        ? corPorRazao(u.razao, config)
        : preenche;
      const raioFinal = semCad
        ? 6
        : padraoAtivo
        ? raioPorCads(Number(u.cuidadores) || 0, maxCads, config)
        : raio;

      const m = L.circleMarker([u.lat, u.lon], {
        radius: raioFinal,
        color: corFinal,
        weight: u.unidade === selected ? 4 : critico ? 3 : 2,
        opacity: u.unidade === selected ? 1 : 0.9,
        fillColor: preencheFinal,
        fillOpacity: semCad
          ? 0.35
          : padraoAtivo
          ? 0.5
          : corFluxo
          ? 0.45
          : quente
          ? 0.55 + (crit!.intervencao / 100) * 0.35
          : modoCriticidade && crit
            ? critico
              ? 0.55
              : 0.25
            : 0.12 + t * 0.33,
        dashArray: semCad
          ? "3 4"
          : corFluxo
          ? flx!.segmento === "Creche"
            ? "5 4"
            : undefined
          : crit?.classe === "Excedente crítico" && modoCriticidade
            ? "4 4"
            : undefined,
      })
        .bindTooltip(
          corFluxo
            ? `<strong>${esc(u.unidade)}</strong><br/>${esc(flx!.segmento)} · ${esc(
                flx!.classe,
              )} · ${flx!.variacaoTotal > 0 ? "+" : ""}${flx!.variacaoTotal} matrículas (2020→2026)`
            : quente
            ? `<strong>${esc(u.unidade)}</strong><br/>🔥 Intervenção prioritária · índice ${crit!.intervencao}/100 (#${crit!.rankIntervencao})`
            : semCad
            ? `<strong>${esc(u.unidade)}</strong><br/>Sem cadastro de CAD`
            : modoCriticidade && crit
              ? `<strong>${esc(u.unidade)}</strong><br/>${esc(crit.classe)} · saldo ${
                  crit.analise.saldo > 0 ? "+" : ""
                }${crit.analise.saldo} CAD`
              : padraoAtivo
                ? `<strong>${esc(u.unidade)}</strong><br/>${esc(u.cuidadores)} CAD · ${esc(
                    u.razao ?? "—",
                  )} alunos por CAD · ${ROTULO_FAIXA[faixaPorRazao(u.razao, config)]}`
                : `<strong>${esc(u.unidade)}</strong>`,
          { direction: "top" },
        )
        .bindPopup(popupHtml(u, metric, v, metricLabel, crit, flx), {
          className: "ue-popup",
          maxWidth: 360,
          minWidth: 300,
          autoPanPadding: [24, 24],
        })
        .on("click", () => onSelect(u.unidade))
        .addTo(layer.current!);
      markers.current[u.unidade] = m;

      if (padraoAtivo && config.mostrarNumeroCads) {
        const cads = Number(u.cuidadores) || 0;
        const tam = Math.max(18, raioFinal * 2);
        L.marker([u.lat, u.lon], {
          interactive: false,
          keyboard: false,
          icon: L.divIcon({
            className: "ue-cad-label",
            html: `<span style="width:${tam}px;line-height:${tam}px;font-size:${Math.max(
              10,
              Math.min(16, raioFinal * 0.8),
            )}px">${esc(cads)}</span>`,
            iconSize: [tam, tam],
            iconAnchor: [tam / 2, tam / 2],
          }),
        }).addTo(layer.current!);
      }
    });


    // Setas de remanejamento sugerido (modo criticidade)
    if (modoCriticidade && criticidade) {
      criticidade.forEach((c) => {
        const origem = porNome.get(c.unidade);
        if (!origem) return;
        c.movimentos.forEach((mv) => {
          const destino = porNome.get(mv.destino);
          if (!destino) return;
          L.polyline(
            [
              [origem.lat, origem.lon],
              [destino.lat, destino.lon],
            ],
            { color: "hsl(280 70% 50%)", weight: 3, opacity: 0.85, dashArray: "8 6" },
          )
            .bindTooltip(`${mv.cads} CAD · ${mv.metros} m`, { sticky: true })
            .addTo(layer.current!);
        });
      });
    }
  }, [unidades, metric, metricLabel, selected, onSelect, criticidade, modoCriticidade, fluxo, modoFluxo, config, modoPadrao]);

  useEffect(() => {
    const u = unidades.find((x) => x.unidade === selected);
    if (u && map.current) {
      map.current.flyTo([u.lat, u.lon], 16, { duration: 0.6 });
      const m = markers.current[u.unidade];
      if (m) window.setTimeout(() => m.openPopup(), 650);
    }
  }, [selected, unidades]);

  return <div ref={el} className="h-full w-full rounded-xl" />;
}
