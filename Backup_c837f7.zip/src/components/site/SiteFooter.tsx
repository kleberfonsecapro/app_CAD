import logoAsset from "@/assets/pmc-logo.png.asset.json";

export default function SiteFooter() {
  return (
    <footer className="mt-10 border-t-4 border-chart-4 bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6 md:grid-cols-3 lg:px-8">
        <div className="flex min-w-0 items-start gap-3">
          <img
            src={logoAsset.url}
            alt="Prefeitura de Cuiabá"
            loading="lazy"
            className="h-12 w-auto shrink-0 rounded-md bg-primary-foreground px-2 py-1"
          />
          <div className="min-w-0">
            <p className="text-sm font-bold leading-tight">Prefeitura Municipal de Cuiabá</p>
            <p className="text-xs text-primary-foreground/80">
              Secretaria Municipal de Educação — SME
            </p>
          </div>
        </div>

        <div className="text-xs leading-relaxed text-primary-foreground/85">
          <p className="mb-2 text-sm font-semibold text-primary-foreground">Endereço</p>
          <p>Palácio Alencastro — Praça Alencastro, s/n, Centro</p>
          <p>Cuiabá — MT, CEP 78005-560</p>
          <p className="mt-1">Atendimento: seg. a sex., 8h às 18h</p>
        </div>

        <div className="text-xs leading-relaxed text-primary-foreground/85">
          <p className="mb-2 text-sm font-semibold text-primary-foreground">Canais</p>
          <a
            href="https://www.cuiaba.mt.gov.br"
            target="_blank"
            rel="noreferrer"
            className="block underline-offset-2 hover:underline"
          >
            Portal cuiaba.mt.gov.br
          </a>
          <p>Ouvidoria 156</p>
          <p>Transparência e Dados Abertos</p>
        </div>
      </div>

      <div className="border-t border-primary-foreground/15">
        <p className="mx-auto max-w-7xl px-4 py-3 text-center text-[11px] text-primary-foreground/70 sm:px-6 lg:px-8">
          © {new Date().getFullYear()} Prefeitura Municipal de Cuiabá · Painel PMC-MCEDU-CAD ·
          Dados de uso interno para planejamento educacional
        </p>
      </div>
    </footer>
  );
}
