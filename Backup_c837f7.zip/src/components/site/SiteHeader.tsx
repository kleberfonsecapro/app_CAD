import { Link } from "@tanstack/react-router";
import logoAsset from "@/assets/pmc-logo.png.asset.json";

const NAV = [
  { to: "/", label: "Mapa de Calor CAD" },
  { to: "/cadastro-cads", label: "Cadastro CADs" },
  { to: "/matriculas", label: "Matrículas 2026" },
  { to: "/cadastro", label: "Cadastro & Vistoria" },
  { to: "/vistoria", label: "Predial" },
  { to: "/levantamento-pedagogico", label: "Pedagógico" },
  { to: "/cids", label: "CIDs" },
] as const;


export default function SiteHeader() {
  return (
    <header className="sticky top-0 z-[900] shadow-sm">
      {/* faixa institucional superior */}
      <div className="bg-secondary text-secondary-foreground">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-1.5 text-[11px] sm:px-6 lg:px-8">
          <span className="truncate uppercase tracking-[0.18em]">
            Governo Municipal de Cuiabá · Mato Grosso
          </span>
          <a
            href="https://www.cuiaba.mt.gov.br"
            target="_blank"
            rel="noreferrer"
            className="hidden shrink-0 underline-offset-2 hover:underline sm:inline"
          >
            cuiaba.mt.gov.br
          </a>
        </div>
      </div>

      {/* faixa principal */}
      <div className="bg-primary text-primary-foreground">
        <div className="mx-auto grid max-w-7xl grid-cols-[auto_minmax(0,1fr)] items-center gap-3 px-4 py-3 sm:px-6 lg:grid-cols-[auto_minmax(0,1fr)_auto] lg:px-8">
          <Link to="/" className="flex shrink-0 items-center">
            <img
              src={logoAsset.url}
              alt="Prefeitura de Cuiabá"
              className="h-10 w-auto rounded-md bg-primary-foreground px-2 py-1 sm:h-12"
            />
          </Link>

          <div className="min-w-0">
            <p className="truncate text-[10px] uppercase tracking-[0.22em] text-primary-foreground/75 sm:text-[11px]">
              Prefeitura Municipal de Cuiabá
            </p>
            <p className="truncate text-base font-bold leading-tight sm:text-lg">
              Secretaria Municipal de Educação
            </p>
            <p className="truncate text-[11px] text-primary-foreground/80">
              Coordenadoria de Microplanejamento Educacional
            </p>
          </div>

          <nav className="col-span-2 -mx-1 flex gap-1 overflow-x-auto lg:col-span-1 lg:mx-0">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                activeOptions={{ exact: true }}
                activeProps={{ className: "bg-primary-foreground text-primary" }}
                inactiveProps={{
                  className:
                    "bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20",
                }}
                className="whitespace-nowrap rounded-md px-3 py-2 text-sm font-semibold transition-colors"
              >
                {n.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* filete verde/azul/amarelo — identidade PMC */}
      <div className="flex h-1">
        <span className="flex-1 bg-primary" />
        <span className="flex-1 bg-secondary" />
        <span className="flex-1 bg-chart-4" />
      </div>
    </header>
  );
}
