import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { listarVistorias, type Vistoria } from "@/lib/cadastro-api";
import { classificacaoPorNota, corDaNota } from "@/lib/cadastro-schema";

export default function PainelAtualizacoes() {
  const [vistorias, setVistorias] = useState<Vistoria[]>([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    listarVistorias()
      .then((v) => setVistorias(v.slice(0, 6)))
      .catch(() => setVistorias([]))
      .finally(() => setCarregando(false));
  }, []);

  return (
    <section className="rounded-xl border border-border bg-card p-4 sm:p-6">
      <header className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-bold">Atualizações Cadastrais e Vistorias</h2>
          <p className="text-xs text-muted-foreground">
            Registros enviados pelo módulo de cadastro e vistoria técnica das unidades.
          </p>
        </div>
        <Link
          to="/cadastro"
          className="rounded-md bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground"
        >
          Abrir módulo de cadastro
        </Link>
      </header>

      {carregando ? (
        <p className="text-sm text-muted-foreground">Carregando atualizações...</p>
      ) : vistorias.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          Nenhuma vistoria registrada ainda. Utilize o módulo de cadastro para iniciar.
        </p>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {vistorias.map((v) => (
            <li key={v.id} className="rounded-lg border border-border p-3">
              <p className="truncate text-sm font-semibold" title={v.unidade_nome}>
                {v.unidade_nome}
              </p>
              <p className="mt-1 text-[11px] text-muted-foreground">
                {v.data_vistoria ?? "—"} ·{" "}
                {v.status === "concluida" ? "Concluída" : "Rascunho"}
              </p>
              <div className="mt-2 flex items-center gap-2">
                <span
                  className={`rounded px-2 py-0.5 text-xs font-bold ${corDaNota(v.nota_media)}`}
                >
                  {v.nota_media ?? "—"}
                </span>
                <span className="text-xs text-muted-foreground">
                  {classificacaoPorNota(v.nota_media)}
                </span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
