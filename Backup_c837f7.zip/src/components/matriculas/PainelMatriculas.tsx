import { useQuery } from "@tanstack/react-query";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ANOS,
  ENTURMACAO_LABEL,
  HISTORICO,
  HIST_KEY_BY_LABEL,
  fetchCanceladas,
  fetchDiario,
  fmt,
  type DiaRegistro,
} from "@/lib/matriculas";

const FONTE = "Fonte: SIGEEC – CMPE/SME-Cuiabá, 2026";
const CORES = [
  "hsl(340, 65%, 47%)",
  "hsl(25, 85%, 55%)",
  "hsl(45, 85%, 50%)",
  "hsl(150, 55%, 42%)",
  "hsl(200, 65%, 48%)",
  "hsl(260, 55%, 55%)",
];

function Kpi({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 text-3xl font-semibold tabular-nums text-foreground">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export default function PainelMatriculas() {
  const diario = useQuery({ queryKey: ["mat-diario"], queryFn: fetchDiario, staleTime: 300000 });
  const canceladas = useQuery({ queryKey: ["mat-canceladas"], queryFn: fetchCanceladas, staleTime: 300000 });

  const registros: DiaRegistro[] = diario.data ?? [];
  const ultimo = registros[registros.length - 1];
  const primeiro = registros[0];
  const crescimento = ultimo && primeiro ? ultimo.total - primeiro.total : 0;
  const mediaDiaria = registros.length > 1 ? Math.round(crescimento / (registros.length - 1)) : 0;

  const serie = registros.map((r) => ({ data: r.data.slice(0, 5), total: r.total, evolucao: r.evolucao }));

  const porEnturmacao = ultimo
    ? Object.entries(ENTURMACAO_LABEL).map(([key, label]) => ({
        label,
        atual: ultimo[key as keyof DiaRegistro] as number,
      }))
    : [];

  const historicoSerie = ANOS.map((ano) => ({
    ano: String(ano),
    total: HISTORICO.reduce((s, h) => s + (h[ano as unknown as keyof typeof h] as number), 0),
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi
          label="Matrículas no dia"
          value={ultimo ? fmt(ultimo.total) : "—"}
          hint={ultimo ? `${ultimo.data} · ${ultimo.diaSemana}` : "Carregando…"}
        />
        <Kpi
          label="Evolução do dia"
          value={ultimo ? `${ultimo.evolucao >= 0 ? "+" : ""}${fmt(ultimo.evolucao)}` : "—"}
          hint="Diferença sobre o dia anterior"
        />
        <Kpi
          label="Crescimento no período"
          value={`${crescimento >= 0 ? "+" : ""}${fmt(crescimento)}`}
          hint={`${registros.length} dias registrados`}
        />
        <Kpi label="Média diária" value={`${mediaDiaria >= 0 ? "+" : ""}${fmt(mediaDiaria)}`} hint="Novas matrículas por dia" />
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Evolução acumulada das matrículas em 2026</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={serie}>
              <defs>
                <linearGradient id="gradTotal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(215, 75%, 42%)" stopOpacity={0.5} />
                  <stop offset="95%" stopColor="hsl(215, 75%, 42%)" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="data" tick={{ fontSize: 11 }} minTickGap={24} />
              <YAxis tick={{ fontSize: 11 }} domain={["dataMin - 500", "dataMax + 500"]} />
              <Tooltip formatter={(v: number) => [fmt(v), "Total"]} />
              <Area type="monotone" dataKey="total" stroke="hsl(215, 75%, 42%)" strokeWidth={2} fill="url(#gradTotal)" />
            </AreaChart>
          </ResponsiveContainer>
          <p className="mt-3 text-right text-[10px] text-muted-foreground">{FONTE}</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Evolução diária (entradas por dia)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={serie}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="data" tick={{ fontSize: 10 }} minTickGap={20} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip formatter={(v: number) => [fmt(v), "Diferença"]} />
                <Bar dataKey="evolucao" radius={[4, 4, 0, 0]}>
                  {serie.map((d, i) => (
                    <Cell key={i} fill={d.evolucao >= 0 ? "hsl(168, 55%, 42%)" : "hsl(0, 72%, 55%)"} opacity={0.85} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <p className="mt-3 text-right text-[10px] text-muted-foreground">{FONTE}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Matrículas por enturmação (último dia)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={porEnturmacao} layout="vertical" margin={{ left: 40 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis type="number" tick={{ fontSize: 10 }} />
                <YAxis type="category" dataKey="label" width={130} tick={{ fontSize: 10 }} />
                <Tooltip formatter={(v: number) => [fmt(v), "Matrículas"]} />
                <Bar dataKey="atual" fill="hsl(215, 75%, 42%)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <p className="mt-3 text-right text-[10px] text-muted-foreground">{FONTE}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Série histórica da rede (2020–2026)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={historicoSerie}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="ano" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={["dataMin - 2000", "dataMax + 2000"]} />
              <Tooltip formatter={(v: number) => [fmt(v), "Matrículas"]} />
              <Legend />
              <Line type="monotone" dataKey="total" name="Total da rede" stroke="hsl(168, 55%, 38%)" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  <th className="py-1.5 pr-3 text-left font-medium text-foreground">Enturmação</th>
                  {ANOS.map((a) => (
                    <th key={a} className="px-2 py-1.5 text-right font-medium text-foreground">
                      {a}
                    </th>
                  ))}
                  <th className="px-2 py-1.5 text-right font-medium text-foreground">Hoje</th>
                </tr>
              </thead>
              <tbody className="text-muted-foreground">
                {HISTORICO.map((h) => (
                  <tr key={h.enturmacao} className="border-b border-border/50">
                    <td className="py-1.5 pr-3 font-medium text-foreground">{h.enturmacao}</td>
                    {ANOS.map((a) => (
                      <td key={a} className="px-2 py-1.5 text-right tabular-nums">
                        {fmt(h[a as unknown as keyof typeof h] as number)}
                      </td>
                    ))}
                    <td className="px-2 py-1.5 text-right font-semibold tabular-nums text-foreground">
                      {ultimo ? fmt(ultimo[HIST_KEY_BY_LABEL[h.enturmacao]] as number) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-right text-[10px] text-muted-foreground">{FONTE}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">
            Solicitações de matrícula canceladas em creche · Total {fmt(canceladas.data?.total ?? 0)}
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={canceladas.data?.items ?? []} dataKey="quantidade" nameKey="enturmacao" outerRadius={95} label>
                {(canceladas.data?.items ?? []).map((_, i) => (
                  <Cell key={i} fill={CORES[i % CORES.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(v: number) => [fmt(v), "Cancelamentos"]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="self-center">
            <table className="w-full text-sm">
              <tbody>
                {(canceladas.data?.items ?? []).map((i, idx) => (
                  <tr key={i.enturmacao} className="border-b border-border/50">
                    <td className="flex items-center gap-2 py-2 text-foreground">
                      <span className="inline-block h-3 w-3 rounded-full" style={{ backgroundColor: CORES[idx % CORES.length] }} />
                      {i.enturmacao}
                    </td>
                    <td className="py-2 text-right font-semibold tabular-nums text-foreground">{fmt(i.quantidade)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-3 text-right text-[10px] text-muted-foreground">{FONTE}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
