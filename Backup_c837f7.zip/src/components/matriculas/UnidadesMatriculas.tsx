import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ANOS, fetchUnidades, fmt } from "@/lib/matriculas";

export default function UnidadesMatriculas() {
  const [busca, setBusca] = useState("");
  const { data, isLoading } = useQuery({ queryKey: ["mat-unidades"], queryFn: fetchUnidades, staleTime: 300000 });

  const lista = useMemo(() => {
    const l = data ?? [];
    const q = busca.trim().toLowerCase();
    return q ? l.filter((u) => u.unidade.toLowerCase().includes(q)) : l;
  }, [data, busca]);

  const totais = useMemo(() => {
    const t: Record<number, number> = {};
    for (const a of ANOS) t[a] = lista.reduce((s, u) => s + (u[a] as number), 0);
    return t;
  }, [lista]);

  return (
    <Card>
      <CardHeader className="gap-3 pb-3 sm:flex-row sm:items-center sm:justify-between">
        <CardTitle className="text-base">Matrículas por unidade educacional · {fmt(lista.length)} unidades</CardTitle>
        <Input
          placeholder="Buscar unidade…"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          className="sm:max-w-xs"
        />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <p className="p-8 text-center text-muted-foreground">Carregando matrículas por unidade…</p>
        ) : (
          <div className="max-h-[70vh] overflow-auto rounded-lg border border-border">
            <table className="w-full text-xs">
              <thead className="sticky top-0 z-10 bg-card">
                <tr className="border-b border-border">
                  <th className="sticky left-0 bg-card px-3 py-2 text-left font-semibold text-foreground">Unidade</th>
                  {ANOS.map((a) => (
                    <th key={a} className="px-3 py-2 text-right font-semibold text-foreground">
                      {a}
                    </th>
                  ))}
                  <th className="px-3 py-2 text-right font-semibold text-foreground">Δ 25→26</th>
                </tr>
              </thead>
              <tbody>
                {lista.map((u) => {
                  const delta = u[2026] - u[2025];
                  return (
                    <tr key={u.unidade} className="border-b border-border/50 hover:bg-muted/40">
                      <td className="sticky left-0 bg-card px-3 py-1.5 font-medium text-foreground">{u.unidade}</td>
                      {ANOS.map((a) => (
                        <td key={a} className="px-3 py-1.5 text-right tabular-nums text-muted-foreground">
                          {fmt(u[a] as number)}
                        </td>
                      ))}
                      <td
                        className={`px-3 py-1.5 text-right font-semibold tabular-nums ${
                          delta > 0 ? "text-emerald-600" : delta < 0 ? "text-destructive" : "text-muted-foreground"
                        }`}
                      >
                        {delta > 0 ? "+" : ""}
                        {fmt(delta)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="sticky bottom-0 bg-card">
                <tr className="border-t-2 border-border">
                  <td className="sticky left-0 bg-card px-3 py-2 font-bold text-foreground">Total</td>
                  {ANOS.map((a) => (
                    <td key={a} className="px-3 py-2 text-right font-bold tabular-nums text-foreground">
                      {fmt(totais[a] ?? 0)}
                    </td>
                  ))}
                  <td className="px-3 py-2 text-right font-bold tabular-nums text-foreground">
                    {fmt((totais[2026] ?? 0) - (totais[2025] ?? 0))}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
        <p className="mt-3 text-right text-[10px] text-muted-foreground">
          Fonte: SIGEEC · CIE – Coordenadoria de Informação e Estatística · CMPE/SME-Cuiabá
        </p>
      </CardContent>
    </Card>
  );
}
