import { useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { fetchFilantropicas, fmt } from "@/lib/matriculas";

const CORES = [
  "hsl(340, 65%, 47%)",
  "hsl(25, 85%, 55%)",
  "hsl(45, 85%, 50%)",
  "hsl(150, 55%, 42%)",
  "hsl(200, 65%, 48%)",
  "hsl(260, 55%, 55%)",
];

export default function Filantropicas() {
  const { data, isLoading } = useQuery({
    queryKey: ["mat-filantropicas"],
    queryFn: fetchFilantropicas,
    staleTime: 300000,
  });

  const items = data?.items ?? [];
  const total = data?.total ?? 0;

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-muted-foreground">
          Carregando dados das instituições filantrópicas…
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-foreground">Matrículas em Instituições Filantrópicas Conveniadas</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Vagas na Educação Infantil ofertadas pela RME em convênio com instituições parceiras · Total:{" "}
          <span className="font-semibold text-foreground">{fmt(total)}</span> matrículas
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Matrículas por enturmação</CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="py-2 text-left font-medium text-muted-foreground">Enturmação</th>
                  <th className="py-2 text-right font-medium text-muted-foreground">Matrículas</th>
                </tr>
              </thead>
              <tbody>
                {items.map((i, idx) => (
                  <tr key={i.enturmacao} className="border-b border-border/50">
                    <td className="flex items-center gap-2 py-2 font-medium text-foreground">
                      <span className="inline-block h-3 w-3 rounded-full" style={{ backgroundColor: CORES[idx % CORES.length] }} />
                      {i.enturmacao}
                    </td>
                    <td className="py-2 text-right font-semibold tabular-nums text-foreground">{fmt(i.quantidade)}</td>
                  </tr>
                ))}
                <tr className="border-t-2 border-border">
                  <td className="py-2 font-bold text-foreground">Total</td>
                  <td className="py-2 text-right font-bold tabular-nums text-foreground">{fmt(total)}</td>
                </tr>
              </tbody>
            </table>
            <p className="mt-3 text-right text-[10px] text-muted-foreground">Fonte: SIGEEC – CMPE/SME-Cuiabá, 2026</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Distribuição por enturmação</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={340}>
              <BarChart data={items} layout="vertical" margin={{ left: 40 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis type="number" tick={{ fontSize: 10 }} />
                <YAxis type="category" dataKey="enturmacao" width={130} tick={{ fontSize: 10 }} />
                <Tooltip formatter={(v: number) => [fmt(v), "Matrículas"]} />
                <Bar dataKey="quantidade" radius={[0, 4, 4, 0]}>
                  {items.map((_, i) => (
                    <Cell key={i} fill={CORES[i % CORES.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <p className="mt-3 text-right text-[10px] text-muted-foreground">Fonte: SIGEEC – CMPE/SME-Cuiabá, 2026</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
