import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const fmt = (n: number) => n.toLocaleString("pt-BR");

// ── Matrículas por grupo de enturmação (2015–2026) ─────────────────────────
type LinhaGrupo = {
  ano: number;
  creche: number;
  pre: number;
  a1: number;
  a2: number;
  a3: number;
  a4: number;
  a5: number;
};

const GRUPOS: LinhaGrupo[] = [
  { ano: 2015, creche: 7000, pre: 9987, a1: 5638, a2: 5482, a3: 5621, a4: 3704, a5: 3250 },
  { ano: 2016, creche: 7541, pre: 10506, a1: 5313, a2: 5551, a3: 5848, a4: 3696, a5: 3363 },
  { ano: 2017, creche: 7730, pre: 11418, a1: 5323, a2: 5440, a3: 6071, a4: 3848, a5: 3608 },
  { ano: 2018, creche: 8342, pre: 11486, a1: 5733, a2: 5267, a3: 5777, a4: 3907, a5: 3614 },
  { ano: 2019, creche: 8378, pre: 12105, a1: 5817, a2: 5659, a3: 5678, a4: 3747, a5: 3750 },
  { ano: 2020, creche: 8493, pre: 12132, a1: 6109, a2: 5807, a3: 6023, a4: 3852, a5: 3689 },
  { ano: 2021, creche: 8630, pre: 11622, a1: 6680, a2: 6356, a3: 5952, a4: 4495, a5: 3930 },
  { ano: 2022, creche: 9943, pre: 11658, a1: 6737, a2: 6529, a3: 6094, a4: 5587, a5: 4335 },
  { ano: 2023, creche: 10256, pre: 12714, a1: 6483, a2: 6896, a3: 6533, a4: 6044, a5: 4087 },
  { ano: 2024, creche: 10811, pre: 12708, a1: 6782, a2: 6565, a3: 6919, a4: 6965, a5: 6687 },
  { ano: 2025, creche: 11797, pre: 12282, a1: 6941, a2: 6881, a3: 6643, a4: 7062, a5: 6973 },
  { ano: 2026, creche: 11471, pre: 12334, a1: 6725, a2: 7025, a3: 6928, a4: 6705, a5: 7137 },
];

const COLS: { key: keyof LinhaGrupo; label: string; cor: string }[] = [
  { key: "creche", label: "Creche", cor: "hsl(150, 55%, 40%)" },
  { key: "pre", label: "Pré-Escola", cor: "hsl(200, 65%, 45%)" },
  { key: "a1", label: "1º Ano", cor: "hsl(45, 85%, 45%)" },
  { key: "a2", label: "2º Ano", cor: "hsl(25, 85%, 52%)" },
  { key: "a3", label: "3º Ano", cor: "hsl(340, 60%, 50%)" },
  { key: "a4", label: "4º Ano", cor: "hsl(260, 50%, 55%)" },
  { key: "a5", label: "5º Ano", cor: "hsl(190, 45%, 35%)" },
];

const totalLinha = (l: LinhaGrupo) => l.creche + l.pre + l.a1 + l.a2 + l.a3 + l.a4 + l.a5;

// ── Efeito coorte (geração 2015) ───────────────────────────────────────────
const COORTE = [
  { ano: 2021, enturmacao: "G4 – Pré-Escola I", coorte: 5328, anterior: 5723 },
  { ano: 2022, enturmacao: "G5 – Pré-Escola II", coorte: 5833, anterior: 6298 },
  { ano: 2023, enturmacao: "1º Ano", coorte: 6479, anterior: 6785 },
  { ano: 2024, enturmacao: "2º Ano", coorte: 6563, anterior: 6898 },
  { ano: 2025, enturmacao: "3º Ano", coorte: 6658, anterior: 6897 },
  { ano: 2026, enturmacao: "4º Ano", coorte: 6707, anterior: 7073 },
];

// ── Desalinhamento oferta × matrícula ──────────────────────────────────────
const DESALINHAMENTO = [
  { etapa: "Ensino Fundamental", vagas: 38200, matriculas: 34545, deficit: 3655 },
  { etapa: "Pré-escola", vagas: 13670, matriculas: 12300, deficit: 1370 },
  { etapa: "Creche", vagas: 12600, matriculas: 11600, deficit: 1000 },
];

const EIXOS = [
  "Sazonalidade do período pré-inicial do ano letivo",
  "Mudança metodológica no processo de matrículas",
  "Restrição às matrículas presenciais nas unidades",
  "Inconsistências no sistema de transparência de vagas",
  "Resistência operacional de unidades escolares",
  "Atraso na entrega de unidades em obras",
  "Insuficiência de soluções emergenciais de infraestrutura",
  "Condições estruturais das unidades de creche",
];

const ENCAMINHAMENTOS = [
  {
    titulo: "Requalificação do Acesso",
    texto: "Revisão dos fluxos operacionais e recomposição dos canais presenciais de matrícula.",
  },
  {
    titulo: "Transparência e Comunicação",
    texto: "Publicização integral da oferta e campanhas ativas de mobilização da demanda.",
  },
  {
    titulo: "Planejamento e Execução",
    texto: "Alinhamento entre órgão central e unidades, com ativação de soluções emergenciais.",
  },
];

// ── Plano Creche 50% ───────────────────────────────────────────────────────
const CRECHE_KPIS = [
  { valor: "15,1%", label: "Cobertura atual G0", hint: "Berçário em 2025" },
  { valor: "35%", label: "Meta do Plano", hint: "Cobertura projetada" },
  { valor: "46", label: "Unidades mapeadas", hint: "Com potencial de expansão" },
  { valor: "+19,9%", label: "Incremento proposto", hint: "Ganho de cobertura" },
];

const ANOS_EI = [2020, 2021, 2022, 2023, 2024, 2025];
const EI = [
  { grupo: "G0 - Berçário", vals: [699, 773, 784, 830, 909, 1050] },
  { grupo: "G1 - Maternal", vals: [1274, 1651, 1777, 2187, 2365, 2605] },
  { grupo: "G2 - Jardim I", vals: [3128, 3232, 3155, 3327, 3429, 3828] },
  { grupo: "G3 - Jardim II", vals: [3491, 3615, 3582, 3863, 3837, 4280] },
  { grupo: "G4 - Pré-escola I", vals: [5723, 5331, 5642, 6097, 6003, 5934] },
  { grupo: "G5 - Pré-escola II", vals: [6390, 6302, 5862, 6418, 6603, 6325] },
];

const eiChart = ANOS_EI.map((ano, i) => {
  const linha: Record<string, number | string> = { ano };
  EI.forEach((e) => (linha[e.grupo] = e.vals[i]));
  return linha;
});

function Fonte({ children }: { children: React.ReactNode }) {
  return <p className="mt-3 text-xs text-muted-foreground">{children}</p>;
}

function Kpi({ valor, label, hint }: { valor: string; label: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <p className="text-3xl font-semibold tabular-nums text-primary">{valor}</p>
      <p className="mt-1 text-sm font-medium text-foreground">{label}</p>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export default function Estudos() {
  return (
    <div className="space-y-8">
      {/* Grupos de enturmação */}
      <Card>
        <CardHeader>
          <CardTitle>Matrículas por Grupo de Enturmação (2015–2026)</CardTitle>
          <p className="text-sm text-muted-foreground">
            Evolução anual das matrículas por grupo na RME de Cuiabá — Creche, Pré-Escola e Anos
            Iniciais do Ensino Fundamental.
          </p>
        </CardHeader>
        <CardContent>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={GRUPOS} margin={{ top: 8, right: 12, bottom: 0, left: -8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="ano" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v: number) => fmt(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                {COLS.map((c) => (
                  <Line
                    key={c.key}
                    type="monotone"
                    dataKey={c.key}
                    name={c.label}
                    stroke={c.cor}
                    strokeWidth={2}
                    dot={false}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-6 overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="py-2 pr-3">Ano</th>
                  {COLS.map((c) => (
                    <th key={c.key} className="py-2 pr-3 text-right">
                      {c.label}
                    </th>
                  ))}
                  <th className="py-2 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {GRUPOS.map((l) => (
                  <tr key={l.ano} className="border-b border-border/60">
                    <td className="py-2 pr-3 font-medium">{l.ano}</td>
                    {COLS.map((c) => (
                      <td key={c.key} className="py-2 pr-3 text-right tabular-nums">
                        {fmt(l[c.key] as number)}
                      </td>
                    ))}
                    <td className="py-2 text-right font-semibold tabular-nums">
                      {fmt(totalLinha(l))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Fonte>Fonte: SIGEEC · CIE – Coordenadoria de Informação e Estatística · CMPE/SME-Cuiabá</Fonte>
        </CardContent>
      </Card>

      {/* Efeito coorte */}
      <Card>
        <CardHeader>
          <CardTitle>Efeito Coorte: A Onda de Depressão nas Matrículas (Geração 2015)</CardTitle>
          <p className="text-sm text-muted-foreground">
            Rastreamento longitudinal da coorte nascida em 2015 através das enturmações da RME de
            Cuiabá — a "onda de depressão" desloca-se ano a ano pelas séries, de G4 (2021) ao 4º Ano
            (2026), com projeção ao 5º Ano em 2027.
          </p>
        </CardHeader>
        <CardContent>
          <p className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-foreground">
            <strong>Fenômeno identificado:</strong> a queda de nascidos vivos em Cuiabá em 2015 —
            associada à epidemia de Zika vírus, mudanças demográficas e comportamentais — gerou uma
            coorte reduzida cuja depressão de matrículas avança sequencialmente pelas séries da RME.{" "}
            <a
              className="font-medium text-primary underline"
              href="https://doi.org/10.5281/zenodo.19198528"
              target="_blank"
              rel="noreferrer"
            >
              Leia o estudo completo →
            </a>
          </p>

          <div className="mt-5 h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={COORTE} margin={{ top: 8, right: 12, bottom: 0, left: -8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="enturmacao" tick={{ fontSize: 11 }} interval={0} />
                <YAxis tick={{ fontSize: 12 }} domain={["dataMin - 400", "dataMax + 400"]} />
                <Tooltip formatter={(v: number) => fmt(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line
                  type="monotone"
                  dataKey="anterior"
                  name="Ano anterior (mesma série)"
                  stroke="hsl(200, 65%, 45%)"
                  strokeWidth={2}
                  strokeDasharray="5 4"
                />
                <Line
                  type="monotone"
                  dataKey="coorte"
                  name="Matrículas da coorte"
                  stroke="hsl(0, 72%, 50%)"
                  strokeWidth={3}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-6 overflow-x-auto">
            <table className="w-full min-w-[600px] text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="py-2 pr-3">Ano letivo</th>
                  <th className="py-2 pr-3">Enturmação</th>
                  <th className="py-2 pr-3 text-right">Matrículas da coorte</th>
                  <th className="py-2 pr-3 text-right">Ano anterior</th>
                  <th className="py-2 text-right">Variação</th>
                </tr>
              </thead>
              <tbody>
                {COORTE.map((c) => (
                  <tr key={c.ano} className="border-b border-border/60">
                    <td className="py-2 pr-3 font-medium">{c.ano}</td>
                    <td className="py-2 pr-3">{c.enturmacao}</td>
                    <td className="py-2 pr-3 text-right tabular-nums">{fmt(c.coorte)}</td>
                    <td className="py-2 pr-3 text-right tabular-nums">{fmt(c.anterior)}</td>
                    <td className="py-2 text-right font-semibold tabular-nums text-destructive">
                      {fmt(c.coorte - c.anterior)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Fonte>
            Fonte: SIGEEC · CMPE/SME-Cuiabá · Estudo: LENA, Â.V. (2025). DOI: 10.5281/zenodo.19198528
          </Fonte>
        </CardContent>
      </Card>

      {/* Causas do declínio */}
      <Card>
        <CardHeader>
          <CardTitle>Análise das Causas do Declínio no Fluxo de Matrículas</CardTitle>
          <p className="text-sm text-muted-foreground">
            Investigação do comportamento atípico do fluxo de matrículas da RME-Cuiabá em 2026 ·
            Microplanejamento Educacional · Demanda Latente · Março 2026 · v2
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-wrap gap-2">
            <a
              className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground"
              href="https://docs.google.com/document/d/e/2PACX-1vQv_ke4uHn7l3IZDfyLOLS9a36PvEFL1KFxBPZQ8qAziCavNDS3P3U41NJ9vq3q4wowMlNk-CNNS0ag/pub"
              target="_blank"
              rel="noreferrer"
            >
              Ler completo
            </a>
            <a
              className="rounded-md border border-border px-3 py-1.5 text-sm font-medium text-foreground"
              href="https://doi.org/10.5281/zenodo.19410091"
              target="_blank"
              rel="noreferrer"
            >
              DOI / Zenodo
            </a>
          </div>

          <div className="rounded-lg border border-border bg-muted/40 p-4">
            <p className="text-sm font-semibold text-foreground">
              Conceito-chave: Demanda Latente Não Capturada
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              Situação em que a necessidade social por acesso à educação não se converte em matrícula
              efetiva, não por ausência de oferta, mas por limitações nos dispositivos institucionais
              de mediação entre o sistema educacional e as famílias.
            </p>
          </div>

          <div>
            <p className="mb-3 text-sm font-semibold">Quadro síntese do desalinhamento por etapa</p>
            <div className="grid gap-3 sm:grid-cols-3">
              {DESALINHAMENTO.map((d) => (
                <div key={d.etapa} className="rounded-xl border border-border bg-card p-4">
                  <p className="text-sm font-semibold text-foreground">{d.etapa}</p>
                  <dl className="mt-2 space-y-1 text-sm">
                    <div className="flex justify-between">
                      <dt className="text-muted-foreground">Vagas ofertadas</dt>
                      <dd className="tabular-nums">{fmt(d.vagas)}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-muted-foreground">Matrículas realizadas</dt>
                      <dd className="tabular-nums">{fmt(d.matriculas)}</dd>
                    </div>
                    <div className="flex justify-between font-semibold text-destructive">
                      <dt>Déficit</dt>
                      <dd className="tabular-nums">~{fmt(d.deficit)}</dd>
                    </div>
                  </dl>
                </div>
              ))}
            </div>
            <div className="mt-4 h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={DESALINHAMENTO} margin={{ top: 8, right: 12, bottom: 0, left: -8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="etapa" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip formatter={(v: number) => fmt(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="vagas" name="Vagas ofertadas" fill="hsl(200, 65%, 45%)" />
                  <Bar dataKey="matriculas" name="Matrículas realizadas" fill="hsl(150, 55%, 40%)" />
                  <Bar dataKey="deficit" name="Déficit" fill="hsl(0, 72%, 50%)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold">Resumo do estudo</p>
            <p className="text-sm text-muted-foreground">
              O estudo analisa o comportamento atípico do fluxo de matrículas na RME-Cuiabá em 2026,
              caracterizado por <strong>desaceleração na inserção de novos alunos</strong> após o
              período inicial do calendário letivo. A investigação parte da leitura do gráfico de
              Variação Diária do Painel de Matrículas 2026. O fenômeno é confrontado com projeções
              técnicas que indicavam continuidade da expansão, com estimativa próxima de{" "}
              <strong>60 mil matrículas</strong> para 2026. A análise conclui que o declínio não
              decorre de ausência de demanda social, mas de{" "}
              <strong>limitações nos mecanismos institucionais de acesso</strong> à rede.
            </p>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold">8 eixos analíticos identificados</p>
            <ol className="grid gap-2 sm:grid-cols-2">
              {EIXOS.map((e, i) => (
                <li
                  key={e}
                  className="flex gap-2 rounded-lg border border-border bg-card p-3 text-sm"
                >
                  <span className="font-semibold text-primary">{i + 1}.</span>
                  <span>{e}</span>
                </li>
              ))}
            </ol>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold">Encaminhamentos propostos pela CMPE</p>
            <div className="grid gap-3 sm:grid-cols-3">
              {ENCAMINHAMENTOS.map((e) => (
                <div key={e.titulo} className="rounded-xl border border-border bg-muted/40 p-4">
                  <p className="text-sm font-semibold text-foreground">{e.titulo}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{e.texto}</p>
                </div>
              ))}
            </div>
          </div>

          <Fonte>
            Autoria: Ângelo Valentim Lena · Coordenador de Microplanejamento Educacional –
            CMPE/SME-Cuiabá · ORCID: 0000-0002-7868-2703 · DOI: 10.5281/zenodo.19410091
          </Fonte>
        </CardContent>
      </Card>

      {/* Plano Creche 50% */}
      <Card>
        <CardHeader>
          <CardTitle>Plano Creche 50%</CardTitle>
          <p className="text-sm text-muted-foreground">
            Expansão estratégica do atendimento ao Berçário na Rede Municipal de Ensino de Cuiabá ·
            Microplanejamento Educacional · PNE Meta 1 · Junho 2025
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-wrap gap-2">
            <a
              className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground"
              href="https://docs.google.com/document/d/e/2PACX-1vQf38sVephbfs6ilhqloRQfo5MO1RqckO-ugsU1UdgDG3m4cgFCmg374ZOvghzINCCBZwGxhwwwN8pv/pub"
              target="_blank"
              rel="noreferrer"
            >
              Ler completo
            </a>
            <a
              className="rounded-md border border-border px-3 py-1.5 text-sm font-medium text-foreground"
              href="https://doi.org/10.5281/zenodo.17373789"
              target="_blank"
              rel="noreferrer"
            >
              DOI / Zenodo
            </a>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {CRECHE_KPIS.map((k) => (
              <Kpi key={k.label} valor={k.valor} label={k.label} hint={k.hint} />
            ))}
          </div>

          <p className="text-sm text-muted-foreground">
            O <strong>Plano Creche 50%</strong> é uma proposta técnico-estratégica para expansão do
            atendimento ao Grupo G0 (Berçário) na RME de Cuiabá, com vistas a aproximar-se da meta de
            50% de cobertura prevista pelo Plano Nacional de Educação. A partir da análise da
            cobertura atual e da identificação de <strong>46 unidades escolares</strong> com
            potencial de expansão, propõe-se a implantação de ao menos uma sala de Berçário em cada
            unidade. Em 2025 foram registradas apenas <strong>1.050 matrículas</strong> no grupo G0,
            frente a uma estimativa populacional de aproximadamente{" "}
            <strong>6.950 crianças</strong> nessa faixa etária.
          </p>

          <div>
            <p className="mb-3 text-sm font-semibold">
              Evolução das matrículas na Educação Infantil — RME Cuiabá
            </p>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={eiChart} margin={{ top: 8, right: 12, bottom: 0, left: -8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="ano" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip formatter={(v: number) => fmt(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  {EI.map((e, i) => (
                    <Line
                      key={e.grupo}
                      type="monotone"
                      dataKey={e.grupo}
                      stroke={COLS[i].cor}
                      strokeWidth={2}
                      dot={false}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[620px] text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground">
                    <th className="py-2 pr-3">Enturmação</th>
                    {ANOS_EI.map((a) => (
                      <th key={a} className="py-2 pr-3 text-right">
                        {a}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {EI.map((e) => (
                    <tr key={e.grupo} className="border-b border-border/60">
                      <td className="py-2 pr-3 font-medium">{e.grupo}</td>
                      {e.vals.map((v, i) => (
                        <td key={i} className="py-2 pr-3 text-right tabular-nums">
                          {fmt(v)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <Fonte>Fonte: SIGEEC/Cuiabá, jul. 2025</Fonte>
        </CardContent>
      </Card>
    </div>
  );
}
