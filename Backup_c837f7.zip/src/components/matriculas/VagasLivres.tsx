import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { VAGAS_GRUPOS, fetchVagas, fmt } from "@/lib/matriculas";

export default function VagasLivres() {
  const [busca, setBusca] = useState("");
  const [bairro, setBairro] = useState("Todos");
  const { data, isLoading } = useQuery({ queryKey: ["mat-vagas"], queryFn: fetchVagas, staleTime: 300000 });

  const bairros = useMemo(
    () => ["Todos", ...Array.from(new Set((data ?? []).map((v) => v.bairro).filter(Boolean))).sort()],
    [data],
  );

  const lista = useMemo(() => {
    const q = busca.trim().toLowerCase();
    return (data ?? []).filter(
      (v) => (bairro === "Todos" || v.bairro === bairro) && (!q || v.unidade.toLowerCase().includes(q)),
    );
  }, [data, busca, bairro]);

  const porGrupo = useMemo(
    () =>
      VAGAS_GRUPOS.map((g) => ({
        label: g.label,
        vagas: lista.reduce((s, v) => s + Math.max(0, v.valores[g.chave] ?? 0), 0),
      })),
    [lista],
  );

  const totalVagas = porGrupo.reduce((s, g) => s + g.vagas, 0);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Vagas livres por enturmação · Total {fmt(totalVagas)}</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={porGrupo} layout="vertical" margin={{ left: 40 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis type="number" tick={{ fontSize: 10 }} />
              <YAxis type="category" dataKey="label" width={130} tick={{ fontSize: 10 }} />
              <Tooltip formatter={(v: number) => [fmt(v), "Vagas livres"]} />
              <Bar dataKey="vagas" fill="hsl(168, 55%, 42%)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <p className="mt-3 text-right text-[10px] text-muted-foreground">Fonte: CMPE/SME-Cuiabá, 2026</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="gap-3 pb-3 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="text-base">Vagas livres por unidade · {fmt(lista.length)} unidades</CardTitle>
          <div className="flex flex-wrap gap-2">
            <select
              value={bairro}
              onChange={(e) => setBairro(e.target.value)}
              className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground"
            >
              {bairros.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
            <Input
              placeholder="Buscar unidade…"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="sm:max-w-xs"
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="p-8 text-center text-muted-foreground">Carregando dados de vagas livres…</p>
          ) : (
            <div className="max-h-[70vh] overflow-auto rounded-lg border border-border">
              <table className="w-full text-xs">
                <thead className="sticky top-0 z-10 bg-card">
                  <tr className="border-b border-border">
                    <th className="sticky left-0 bg-card px-3 py-2 text-left font-semibold text-foreground">Unidade</th>
                    <th className="px-3 py-2 text-left font-semibold text-foreground">Bairro</th>
                    {VAGAS_GRUPOS.map((g) => (
                      <th key={g.chave} className="px-2 py-2 text-center font-semibold text-foreground">
                        {g.label.replace(" - ", " ")}
                      </th>
                    ))}
                    <th className="px-3 py-2 text-right font-semibold text-foreground">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {lista.map((v) => (
                    <tr key={`${v.unidade}-${v.bairro}`} className="border-b border-border/50 hover:bg-muted/40">
                      <td className="sticky left-0 bg-card px-3 py-1.5 font-medium text-foreground">{v.unidade}</td>
                      <td className="px-3 py-1.5 text-muted-foreground">{v.bairro}</td>
                      {VAGAS_GRUPOS.map((g) => {
                        const val = v.valores[g.chave] ?? 0;
                        return (
                          <td
                            key={g.chave}
                            className={`px-2 py-1.5 text-center tabular-nums ${
                              val < 0 ? "font-semibold text-destructive" : val === 0 ? "text-muted-foreground" : "text-foreground"
                            }`}
                          >
                            {val === 0 ? "-" : fmt(val)}
                          </td>
                        );
                      })}
                      <td className="px-3 py-1.5 text-right font-semibold tabular-nums text-foreground">{fmt(v.total)}</td>
                    </tr>
                  ))}
                  {lista.length === 0 && (
                    <tr>
                      <td colSpan={VAGAS_GRUPOS.length + 3} className="py-8 text-center text-muted-foreground">
                        Nenhuma unidade encontrada com os filtros aplicados.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
          <p className="mt-3 text-right text-[10px] text-muted-foreground">
            Fonte: SIGEEC – CMPE/SME-Cuiabá · CIE – Coordenadoria de Informação e Estatística/SME-Cuiabá, 2026
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
