import { useMemo } from "react";
import type { Cluster } from "@/lib/triangulacao";
import { META_RAZAO } from "@/lib/triangulacao";

export default function TriangulacaoPanel({
  clusters,
  raio,
  onRaio,
  selecionado,
  onSelecionar,
  onSelecionarUnidade,
}: {
  clusters: Cluster[];
  raio: number;
  onRaio: (r: number) => void;
  selecionado: string | null;
  onSelecionar: (id: string | null) => void;
  onSelecionarUnidade: (u: string) => void;
}) {
  const resumo = useMemo(() => {
    const est = clusters.reduce((a, c) => a + c.estudantes, 0);
    const cads = clusters.reduce((a, c) => a + c.cuidadores, 0);
    const ideais = clusters.reduce((a, c) => a + c.cadsIdeais, 0);
    return {
      grupos: clusters.length,
      unidades: clusters.reduce((a, c) => a + c.unidades.length, 0),
      est,
      cads,
      razaoAtual: cads ? (est / cads).toFixed(2) : "—",
      razaoPos: ideais ? (est / Math.min(cads, ideais)).toFixed(2) : "—",
      realocar: clusters.reduce((a, c) => a + c.cadsRealocados, 0),
      excedente: clusters.reduce((a, c) => a + c.cadsExcedentes, 0),
    };
  }, [clusters]);

  const atual = clusters.find((c) => c.id === selecionado) ?? null;

  return (
    <section className="mt-6 rounded-xl border border-border bg-card">
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border p-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">
            Triangulação de escolas próximas & remanejamento de CADs
          </h2>
          <p className="text-sm text-muted-foreground">
            Grupos de unidades conectadas dentro do raio definido, com plano de remanejamento para
            atingir a meta de <strong>{META_RAZAO} estudantes por CAD</strong>.
          </p>
        </div>
        <label className="flex items-center gap-2 text-sm text-muted-foreground">
          Raio
          <select
            value={raio}
            onChange={(e) => onRaio(Number(e.target.value))}
            className="rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground"
          >
            {[500, 750, 1000, 1500, 2000].map((r) => (
              <option key={r} value={r}>
                {r} m
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="grid grid-cols-2 gap-3 border-b border-border p-4 lg:grid-cols-6">
        {[
          ["Triangulações", String(resumo.grupos)],
          ["Unidades agrupadas", String(resumo.unidades)],
          ["Estudantes nos grupos", resumo.est.toLocaleString("pt-BR")],
          ["Razão atual", resumo.razaoAtual],
          ["Razão pós-remanejamento", resumo.razaoPos],
          ["CADs a remanejar / liberar", `${resumo.realocar} / ${resumo.excedente}`],
        ].map(([l, v]) => (
          <div key={l} className="rounded-lg border border-border bg-background p-3">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{l}</p>
            <p className="mt-1 text-2xl font-semibold tabular-nums text-foreground">{v}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-4 p-4 lg:grid-cols-[1fr_1.2fr]">
        <div className="max-h-[420px] overflow-y-auto rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-muted text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-3 py-2 text-left">Triangulação</th>
                <th className="px-2 py-2 text-right">Un.</th>
                <th className="px-2 py-2 text-right">Est.</th>
                <th className="px-2 py-2 text-right">CAD</th>
                <th className="px-2 py-2 text-right">Razão</th>
                <th className="px-3 py-2 text-right">Meta</th>
              </tr>
            </thead>
            <tbody>
              {clusters.map((c) => (
                <tr
                  key={c.id}
                  onClick={() => onSelecionar(c.id === selecionado ? null : c.id)}
                  className={`cursor-pointer border-t border-border transition-colors hover:bg-accent ${
                    selecionado === c.id ? "bg-accent" : ""
                  }`}
                >
                  <td className="px-3 py-2">
                    <span className="block truncate">{c.nome}</span>
                    <span className="text-xs text-muted-foreground">
                      {c.regioes.join(" / ")} · distância média {c.raioMedio} m
                    </span>
                  </td>
                  <td className="px-2 py-2 text-right tabular-nums">{c.unidades.length}</td>
                  <td className="px-2 py-2 text-right tabular-nums">{c.estudantes}</td>
                  <td className="px-2 py-2 text-right tabular-nums">{c.cuidadores}</td>
                  <td className="px-2 py-2 text-right tabular-nums">{c.razaoAtual ?? "—"}</td>
                  <td className="px-3 py-2 text-right tabular-nums font-semibold">
                    {c.razaoPos ?? "—"}
                  </td>
                </tr>
              ))}
              {clusters.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-3 py-6 text-center text-muted-foreground">
                    Nenhum grupo de escolas dentro do raio selecionado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="rounded-lg border border-border p-3 text-sm">
          {!atual && (
            <p className="text-muted-foreground">
              Selecione uma triangulação para ver o traçado no mapa, as estatísticas do grupo e o
              plano de remanejamento de cuidadores entre as escolas próximas.
            </p>
          )}
          {atual && (
            <div className="space-y-3">
              <div>
                <p className="font-semibold text-foreground">{atual.nome}</p>
                <p className="text-xs text-muted-foreground">
                  {atual.estudantes} estudantes · {atual.cuidadores} CADs · razão{" "}
                  {atual.razaoAtual} → <strong>{atual.razaoPos ?? "—"}</strong> · CADs ideais{" "}
                  {atual.cadsIdeais} · {atual.cadsExcedentes} CADs liberáveis para outras regiões
                </p>
                <p
                  className={`mt-1 text-xs font-semibold ${
                    atual.meta ? "text-emerald-500" : "text-amber-500"
                  }`}
                >
                  {atual.meta
                    ? `Meta atingida: acima de ${META_RAZAO} estudantes por CAD após remanejamento.`
                    : `Mesmo com o remanejamento o grupo não atinge ${META_RAZAO}:1 — avaliar fusão de turmas ou realocação externa.`}
                </p>
              </div>

              <div>
                <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Unidades do traçado
                </p>
                <ul className="max-h-32 space-y-1 overflow-y-auto text-xs">
                  {atual.unidades.map((u) => (
                    <li key={u.unidade}>
                      <button
                        onClick={() => onSelecionarUnidade(u.unidade)}
                        className="w-full text-left hover:underline"
                      >
                        {u.unidade} — {u.estudantes} est. / {u.cuidadores} CAD (razão{" "}
                        {u.razao ?? "—"})
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Plano de remanejamento
                </p>
                {atual.transferencias.length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    Nenhuma transferência interna necessária — o excedente de {atual.cadsExcedentes}{" "}
                    CADs pode ser realocado para outras triangulações.
                  </p>
                ) : (
                  <table className="w-full text-xs">
                    <thead className="text-muted-foreground">
                      <tr>
                        <th className="py-1 text-left">Origem (excedente)</th>
                        <th className="py-1 text-left">Destino (déficit)</th>
                        <th className="py-1 text-right">CADs</th>
                        <th className="py-1 text-right">Dist.</th>
                      </tr>
                    </thead>
                    <tbody>
                      {atual.transferencias.map((t, i) => (
                        <tr key={i} className="border-t border-border">
                          <td className="py-1 pr-2">{t.origem}</td>
                          <td className="py-1 pr-2">{t.destino}</td>
                          <td className="py-1 text-right tabular-nums font-semibold">{t.cads}</td>
                          <td className="py-1 text-right tabular-nums">{t.metros} m</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
