import { processarBI } from "@/lib/bi-cads";
import { Unidade } from "@/types/unidade";
import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { listarCADs, type CAD } from "@/lib/cadastro-api";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell,
} from "recharts";
import { Users } from "lucide-react";

const COLORS = ["#0056b3", "#28a745", "#ffc107", "#dc3545", "#6f42c1", "#e83e8c"];

export default function BICads({ unidades }: { unidades: Unidade[] }) {
  const { data: cadsReais = [], isLoading } = useQuery({
    queryKey: ["cads-total-bi"],
    queryFn: () => listarCADs(),
  });

  const { stats, inconsistencias, recadastramento } = useMemo(() => processarBI(unidades, cadsReais), [unidades, cadsReais]);

  const totais = useMemo(() => {
    return stats.reduce(
      (acc, s) => ({
        unidades: acc.unidades + s.unidades,
        estudantes: acc.estudantes + s.estudantes,
        cads: acc.cads + s.cads,
        carga30h: acc.carga30h + s.carga30h,
        carga40h: acc.carga40h + s.carga40h,
      }),
      { unidades: 0, estudantes: 0, cads: 0, carga30h: 0, carga40h: 0 }
    );
  }, [stats]);


  return (
    <div className="space-y-6">
      {/* Recadastramento 2026 Indicators */}
      {recadastramento && (
        <Card className="border-primary/20 bg-primary/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Recadastramento 2026 (Analítico)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
              <div className="bg-background/80 p-3 rounded-lg border border-border/50">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Estudantes Atendidos</p>
                <p className="text-2xl font-bold">{recadastramento.totalCriancasAtendidas}</p>
                <p className="text-[10px] text-muted-foreground">{recadastramento.estudantesComDeficiencia} com Deficiência</p>
              </div>
              <div className="bg-background/80 p-3 rounded-lg border border-border/50">
                <p className="text-xs font-semibold uppercase text-muted-foreground">TEA & Suporte</p>
                <p className="text-2xl font-bold text-blue-600">{recadastramento.tea}</p>
                <div className="flex gap-1.5 text-[10px] font-bold">
                  <span className="text-blue-500">L1: {recadastramento.nivel1}</span>
                  <span className="text-orange-500">L2: {recadastramento.nivel2}</span>
                  <span className="text-red-500">L3: {recadastramento.nivel3}</span>
                </div>
              </div>
              <div className="bg-background/80 p-3 rounded-lg border border-border/50">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Distorções Detectadas</p>
                <div className="space-y-1 mt-1">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] uppercase font-semibold">Múltiplas Unid.</span>
                    <span className="text-sm font-bold text-orange-600">{recadastramento.multiUnidade}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] uppercase font-semibold">Sobrecarga (+2)</span>
                    <span className="text-sm font-bold text-red-600">{recadastramento.sobrecargaAlunos}</span>
                  </div>
                </div>
              </div>
              <div className="bg-background/80 p-3 rounded-lg border border-border/50">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Carga Horária (Auto)</p>
                <div className="flex gap-2 items-baseline">
                  <p className="text-xl font-bold">{recadastramento.cad30h}</p>
                  <span className="text-[10px] text-muted-foreground">30h</span>
                  <p className="text-xl font-bold ml-2">{recadastramento.cad40h}</p>
                  <span className="text-[10px] text-muted-foreground">40h</span>
                </div>
              </div>
            </div>

            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div className="bg-background/40 p-3 rounded-lg border border-border/30">
                <p className="text-xs font-semibold mb-2">Perfil de Autonomia (TEA)</p>
                <div className="flex gap-4">
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">Sem Suporte</p>
                    <p className="text-lg font-bold">{recadastramento.autonomiaSemSuporte}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">Com Suporte</p>
                    <p className="text-lg font-bold">{recadastramento.autonomiaComSuporte}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">Não Inf.</p>
                    <p className="text-lg font-bold text-muted-foreground">{recadastramento.autonomiaNaoInformada}</p>
                  </div>
                </div>
              </div>
              <div className="bg-yellow-50/50 dark:bg-yellow-950/20 p-3 rounded-lg border border-yellow-200/50">
                <p className="text-xs font-bold text-yellow-800 dark:text-yellow-400 mb-1">Nota da Auditoria</p>
                <p className="text-[11px] text-yellow-700 dark:text-yellow-300 leading-tight">
                  Identificamos {recadastramento.multiUnidade} profissionais atuando em mais de uma unidade simultaneamente e {recadastramento.sobrecargaAlunos} CADs com carga superior a 2 alunos por turno, o que pode impactar a qualidade do atendimento especializado.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de CADs</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-2xl font-bold animate-pulse text-muted-foreground">Carregando...</div>
            ) : (
              <>
                <div className="text-2xl font-bold">{totais.cads || cadsReais.length}</div>
                <p className="text-xs text-muted-foreground">
                  {totais.carga30h} (30h) / {totais.carga40h} (40h)
                </p>
              </>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estudantes Atendidos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totais.estudantes}</div>
            <p className="text-xs text-muted-foreground">
              Média de {(totais.estudantes / totais.cads).toFixed(2)} por CAD
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unidades com CAD</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totais.unidades}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Carga Horária Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(totais.carga30h * 30 + totais.carga40h * 40).toLocaleString()}h
            </div>
            <p className="text-xs text-muted-foreground">Semanal</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>CADs por Zoneamento</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                <XAxis type="number" hide />
                <YAxis dataKey="regiao" type="category" width={80} fontSize={12} />
                <Tooltip />
                <Legend />
                <Bar dataKey="cads" name="Total CADs" fill="#0056b3" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Alunos Atendidos por Região</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="regiao" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Bar dataKey="estudantes" name="Alunos" radius={[4, 4, 0, 0]}>
                  {stats.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Distribuição de Carga Horária por Região</CardTitle>
        </CardHeader>
        <CardContent className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="regiao" fontSize={12} />
              <YAxis fontSize={12} />
              <Tooltip />
              <Legend />
              <Bar dataKey="carga30h" name="30 Horas" stackId="a" fill="#0056b3" />
              <Bar dataKey="carga40h" name="40 Horas" stackId="a" fill="#28a745" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="border-red-200">
        <CardHeader className="bg-red-50/50">
          <CardTitle className="text-red-800 flex items-center gap-2">
            Relatório de Inconsistências (Mapa vs Cadastro)
            <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded-full text-xs font-bold">
              {inconsistencias.length}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-muted-foreground">
                  <th className="pb-2 font-medium">Tipo</th>
                  <th className="pb-2 font-medium">Entidade</th>
                  <th className="pb-2 font-medium">Inconsistência</th>
                  <th className="pb-2 font-medium text-right">Esp.</th>
                  <th className="pb-2 font-medium text-right">Real</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {inconsistencias.map((inc) => (
                  <tr key={inc.id} className="hover:bg-muted/50 transition-colors">
                    <td className="py-3 pr-4">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                        inc.tipo === 'CAD_SEM_MAPA' ? 'bg-orange-100 text-orange-700' :
                        inc.tipo === 'UNIDADE_SEM_CAD' ? 'bg-red-100 text-red-700' :
                        inc.tipo === 'RECADASTRAMENTO_MISSING' ? 'bg-purple-100 text-purple-700' :
                        inc.tipo === 'MULTI_LOTACAO' ? 'bg-yellow-100 text-yellow-700' :
                        inc.tipo === 'DISTORCAO_CARGA' ? 'bg-indigo-100 text-indigo-700' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {inc.tipo.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="py-3 pr-4 font-medium">{inc.entidade}</td>
                    <td className="py-3 pr-4 text-muted-foreground">{inc.detalhe}</td>
                    <td className="py-3 pr-4 text-right font-mono">
                      {inc.valorEsperado !== undefined ? inc.valorEsperado : '-'}
                    </td>
                    <td className="py-3 text-right font-mono text-red-600 font-bold">
                      {inc.valorEncontrado !== undefined ? inc.valorEncontrado : '-'}
                    </td>
                  </tr>
                ))}
                {inconsistencias.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-muted-foreground italic">
                      Nenhuma inconsistência detectada entre a base de cadastro e o mapa.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
