import { useMemo, useState } from "react";
import unidadesData from "@/data/unidades.json";
import type { Unidade } from "@/types/unidade";
import { analisarUnidade, consolidar, MEDIA_NACIONAL, META_GESTAO } from "@/lib/analiseTecnica";
import FichaTecnica from "@/components/FichaTecnica";

const UNIDADES = unidadesData as Unidade[];

const CLASSES = ["Todas", "Déficit crítico", "Déficit", "Adequado", "Excedente"] as const;

const badge: Record<string, string> = {
  Excedente: "bg-secondary/10 text-secondary",
  Adequado: "bg-primary/10 text-primary",
  "Déficit": "bg-chart-5/15 text-chart-5",
  "Déficit crítico": "bg-destructive/10 text-destructive",
};

export default function MapaDistorcao() {
  const [busca, setBusca] = useState("");
  const [regiao, setRegiao] = useState("Todas");
  const [classe, setClasse] = useState<(typeof CLASSES)[number]>("Todas");
  const [aberta, setAberta] = useState<string | null>(null);

  const regioes = useMemo(
    () => ["Todas", ...Array.from(new Set(UNIDADES.map((u) => u.regiao))).sort()],
    [],
  );

  const analises = useMemo(() => UNIDADES.map(analisarUnidade), []);
  const total = useMemo(() => consolidar(analises), [analises]);

  const lista = useMemo(() => {
    const t = busca.trim().toLowerCase();
    return analises
      .filter((a) => {
        const u = UNIDADES.find((x) => x.unidade === a.unidade)!;
        if (regiao !== "Todas" && u.regiao !== regiao) return false;
        if (classe !== "Todas" && a.classificacao !== classe) return false;
        if (t && !a.unidade.toLowerCase().includes(t)) return false;
        return true;
      })
      .sort((x, y) => y.prioridade - x.prioridade || x.distorcao - y.distorcao);
  }, [analises, busca, regiao, classe]);

  return (
    <section className="space-y-4">
      <header className="pmc-secao">
        <h2 className="pmc-titulo text-lg">Mapa de distorção do atendimento especializado</h2>
        <p className="text-xs text-muted-foreground">
          Dimensionamento técnico por unidade a partir do perfil de autonomia dos estudantes,
          comparado à média nacional ({MEDIA_NACIONAL} alunos/CAD) e à meta de gestão ({META_GESTAO}{" "}
          alunos/CAD).
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-6">
        <Kpi titulo="Unidades" valor={total.unidades} />
        <Kpi titulo="Estudantes" valor={total.estudantes.toLocaleString("pt-BR")} />
        <Kpi titulo="CADs hoje" valor={total.cadsAtuais.toLocaleString("pt-BR")} />
        <Kpi
          titulo="Necessário técnico"
          valor={total.cadTecnico.toLocaleString("pt-BR")}
          nota={`faixa ${total.faixaMin}–${total.faixaMax}`}
        />
        <Kpi
          titulo="Média nacional pura"
          valor={total.cadMediaNacional.toLocaleString("pt-BR")}
          nota={`estudantes ÷ ${MEDIA_NACIONAL}`}
        />
        <Kpi
          titulo="Distorção da rede"
          valor={`${total.distorcao > 0 ? "+" : ""}${total.distorcao}%`}
          nota={`saldo ${total.saldo > 0 ? "+" : ""}${total.saldo} CADs`}
        />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi titulo="Déficit crítico" valor={total.criticas} nota="prioridade máxima" />
        <Kpi titulo="Com déficit" valor={total.deficit} />
        <Kpi titulo="Adequadas" valor={total.adequadas} />
        <Kpi titulo="Com excedente" valor={total.excedente} nota="passíveis de remanejamento" />
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <input
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          placeholder="Buscar unidade educacional…"
          className="min-w-0 rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground outline-none focus:border-ring"
        />
        <select
          value={regiao}
          onChange={(e) => setRegiao(e.target.value)}
          className="min-w-0 rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground"
        >
          {regioes.map((r) => (
            <option key={r}>{r}</option>
          ))}
        </select>
        <select
          value={classe}
          onChange={(e) => setClasse(e.target.value as (typeof CLASSES)[number])}
          className="min-w-0 rounded-md border border-input bg-card px-3 py-2 text-sm text-foreground"
        >
          {CLASSES.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="hidden grid-cols-[minmax(0,3fr)_repeat(5,minmax(0,1fr))] gap-2 border-b border-border bg-muted px-3 py-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground md:grid">
          <span>Unidade ({lista.length})</span>
          <span className="text-right">Estudantes</span>
          <span className="text-right">CAD hoje</span>
          <span className="text-right">Necessário</span>
          <span className="text-right">Saldo</span>
          <span className="text-right">Situação</span>
        </div>
        <ul className="max-h-[620px] divide-y divide-border overflow-y-auto">
          {lista.map((a) => {
            const u = UNIDADES.find((x) => x.unidade === a.unidade)!;
            const open = aberta === a.unidade;
            return (
              <li key={a.unidade}>
                <button
                  onClick={() => setAberta(open ? null : a.unidade)}
                  className="grid w-full grid-cols-2 gap-1 px-3 py-2 text-left text-sm transition-colors hover:bg-accent md:grid-cols-[minmax(0,3fr)_repeat(5,minmax(0,1fr))] md:gap-2"
                >
                  <span className="col-span-2 truncate font-medium text-foreground md:col-span-1">
                    {a.unidade}
                  </span>
                  <span className="tabular-nums text-muted-foreground md:text-right">
                    <i className="not-italic md:hidden">Estudantes </i>
                    {a.estudantes}
                  </span>
                  <span className="tabular-nums text-muted-foreground md:text-right">
                    <i className="not-italic md:hidden">CAD </i>
                    {a.cadsAtuais}
                  </span>
                  <span className="tabular-nums text-foreground md:text-right">
                    <i className="not-italic md:hidden">Necessário </i>
                    {a.cadTecnico}
                  </span>
                  <span
                    className={`tabular-nums md:text-right ${
                      a.saldo < 0 ? "text-destructive" : "text-secondary"
                    }`}
                  >
                    {a.saldo > 0 ? "+" : ""}
                    {a.saldo}
                  </span>
                  <span className="md:text-right">
                    <span
                      className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold ${badge[a.classificacao]}`}
                    >
                      {a.classificacao}
                    </span>
                  </span>
                </button>
                {open && (
                  <div className="bg-muted/40 p-3">
                    <FichaTecnica unidade={u} />
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      </div>

      <p className="text-xs text-muted-foreground">
        Base legal: Lei nº 13.146/2015 e Decreto nº 12.686/2025 — não há proporção fixa de CAD por
        estudante; o apoio deve ser individual, compartilhado ou intermitente conforme estudo de
        caso. A média nacional (1 CAD : {MEDIA_NACIONAL} alunos, Inep/MEC — Censo Escolar) é
        referência comparativa, não parâmetro legal.
      </p>
    </section>
  );
}

function Kpi({ titulo, valor, nota }: { titulo: string; valor: number | string; nota?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-3">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{titulo}</p>
      <p className="text-xl font-bold tabular-nums text-foreground">{valor}</p>
      {nota && <p className="text-[10px] text-muted-foreground">{nota}</p>}
    </div>
  );
}
