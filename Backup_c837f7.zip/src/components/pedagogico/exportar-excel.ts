import unidadesData from "@/data/unidades.json";
import type { Unidade } from "@/types/unidade";
import { enderecoCompleto } from "@/lib/endereco";
import { listarCADs, type CAD, type CadastroUnidade, type LevantamentoPedagogico } from "@/lib/cadastro-api";

const norm = (s: unknown) =>
  String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim().toUpperCase();

export async function exportarExcelCompleto(
  levantamentos: LevantamentoPedagogico[],
  cadastros: CadastroUnidade[],
) {
  const [{ default: ExcelJS }, cads] = await Promise.all([import("exceljs"), listarCADs()]);
  const unidades = unidadesData as Unidade[];

  const cadPorUnidadeId = new Map(cadastros.map((c) => [c.unidade_id, c]));
  const cadPorNomeEscola = new Map(cadastros.map((c) => [norm(c.nome), c]));
  const mapaPorNome = new Map(unidades.map((u) => [norm(u.unidade), u]));

  const endereco = (nomeOuId?: string | null) => {
    const k = norm(nomeOuId);
    const c = cadPorUnidadeId.get(nomeOuId ?? "") ?? cadPorNomeEscola.get(k);
    const nome = c?.nome ?? nomeOuId ?? "";
    const u = mapaPorNome.get(norm(nome));
    const end = c?.logradouro
      ? [[c.logradouro, c.numero].filter(Boolean).join(", "), c.bairro, c.cep, [c.cidade || "Cuiabá", c.uf || "MT"].join("/")]
          .filter(Boolean).join(" · ")
      : u ? enderecoCompleto(u) : "";
    return { nome, regiao: c?.regiao ?? u?.regiao ?? "", endereco: end, telefone: c?.telefone ?? "", email: c?.email ?? "", inep: c?.inep ?? "" };
  };

  const cadPorNome = new Map<string, CAD>();
  for (const c of cads) if (!cadPorNome.has(norm(c.nome))) cadPorNome.set(norm(c.nome), c);

  const wb = new ExcelJS.Workbook();
  wb.creator = "PMC-MCEDU-CAD";
  const estilo = (ws: any) => {
    ws.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    ws.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF006633" } };
    ws.views = [{ state: "frozen", ySplit: 1 }];
    ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: ws.columnCount } };
  };
  const col = (h: string, w = 18) => ({ header: h, key: h, width: w });

  const cadCols = ["Nome", "Sexo", "Matrícula", "CPF", "Cargo", "Cód. cargo", "Jornada (h)", "Situação", "Situação funcional", "Status", "Data admissão", "Vencimento", "Telefone", "E-mail", "Observações"];
  const cadRow = (c?: CAD) => c ? [c.nome, c.sexo, c.matricula, c.cpf, c.cargo, c.cod_cargo, c.jornada, c.situacao, c.situacao_funcional, c.status, c.data_admissao, c.vencimento, c.telefone, c.email, c.observacoes].map((v) => v ?? "") : cadCols.map(() => "");

  // Aba 1: CADs (cadastro completo)
  const ws1 = wb.addWorksheet("CADs");
  ws1.columns = [...cadCols.map((h) => col(h, h === "Nome" ? 34 : 16)), col("Escola (cadastro)", 34), col("Endereço da escola", 50), col("Região", 12)];
  for (const c of cads) {
    const e = endereco(c.unidade_id);
    ws1.addRow([...cadRow(c), e.nome, e.endereco, e.regiao]);
  }
  estilo(ws1);

  // Aba 2: CAD × alunos × turma × escola
  const ws2 = wb.addWorksheet("CADs x Alunos");
  ws2.columns = [
    col("Escola", 34), col("INEP", 12), col("Região", 12), col("Endereço completo", 50), col("Telefone escola", 16),
    col("Série", 10), col("Turma", 8), col("Turno/Período", 14),
    ...cadCols.map((h) => col(`CAD - ${h}`, h === "Nome" ? 34 : 16)),
    col("Aluno", 34), col("CID", 12), col("Deficiência", 14), col("TEA nível suporte", 16), col("TEA autonomia", 16),
    col("Transtorno comportamental", 16), col("Transtornos", 14), col("Altas habilidades", 14), col("Obs. transtornos", 30), col("Possui laudo", 14),
    col("Data levantamento", 14), col("Responsável", 24),
  ];
  for (const l of levantamentos) {
    const sa = ((l.dados_pedagogicos ?? {}) as any).salaAula ?? {};
    const e = endereco(l.unidade_id) ;
    const esc = e.endereco ? e : endereco(l.unidade_nome);
    for (const v of (sa.vinculos ?? []) as any[]) {
      const c = cadPorNome.get(norm(v?.cadNome));
      const cr = cadRow(c);
      if (!c) cr[0] = v?.cadNome ?? "";
      const alunos = ((v?.alunos ?? []) as any[]).length ? v.alunos : [{}];
      for (const a of alunos) {
        ws2.addRow([
          l.unidade_nome, esc.inep, esc.regiao, esc.endereco, esc.telefone,
          sa.ano ?? "", sa.turma ?? "", sa.periodo ?? "",
          ...cr,
          a.nome ?? "", a.cid ?? "", a.deficiencia ?? "", a.teaNivelSuporte ?? "", a.teaAutonomia ?? "",
          a.transtornoComportamental ?? "", a.transtornos ?? "", a.altasHabilidades ?? "", a.transtornosObs ?? a.observacaoTranstorno ?? "", a.possuiLaudo ?? "",
          l.data_levantamento ?? "", l.responsavel ?? "",
        ]);
      }
    }
  }
  estilo(ws2);

  // Aba 3: Escolas
  const ws3 = wb.addWorksheet("Escolas");
  ws3.columns = [col("Escola", 40), col("INEP", 12), col("Região", 12), col("Endereço completo", 60), col("Telefone", 16), col("E-mail", 28), col("Diretor", 28)];
  const vistas = new Set<string>();
  for (const u of unidades) {
    const c = cadPorNomeEscola.get(norm(u.unidade));
    vistas.add(norm(u.unidade));
    ws3.addRow([u.unidade, c?.inep ?? "", u.regiao, endereco(u.unidade).endereco, c?.telefone ?? "", c?.email ?? "", c?.diretor ?? ""]);
  }
  for (const c of cadastros) if (!vistas.has(norm(c.nome))) {
    const e = endereco(c.unidade_id);
    ws3.addRow([c.nome, c.inep ?? "", e.regiao, e.endereco, c.telefone ?? "", c.email ?? "", c.diretor ?? ""]);
  }
  estilo(ws3);

  const buf = await wb.xlsx.writeBuffer();
  const url = URL.createObjectURL(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `exportacao-cads-alunos-${new Date().toISOString().slice(0, 10)}.xlsx`;
  a.click();
  URL.revokeObjectURL(url);
}
