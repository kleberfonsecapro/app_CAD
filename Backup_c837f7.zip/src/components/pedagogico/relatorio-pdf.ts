import logoAsset from "@/assets/pmc-logo.png.asset.json";

export type LinhaPdf = string[];
export type GrupoPdf = { nome: string; conflito: string; colunas: string[]; linhas: LinhaPdf[] };

async function carregarLogo(): Promise<string | null> {
  try {
    const r = await fetch(logoAsset.url);
    const b = await r.blob();
    return await new Promise((res) => {
      const fr = new FileReader();
      fr.onload = () => res(fr.result as string);
      fr.onerror = () => res(null);
      fr.readAsDataURL(b);
    });
  } catch {
    return null;
  }
}

export async function gerarPdfRelatorio(opts: {
  titulo: string;
  filtros: string;
  resumo: string;
  grupos: GrupoPdf[];
}) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const logo = await carregarLogo();
  const verde: [number, number, number] = [11, 107, 58];
  const agora = new Date().toLocaleString("pt-BR");
  const TOPO = 34;

  const cabecalho = () => {
    doc.setFillColor(...verde);
    doc.rect(0, 0, W, 26, "F");
    if (logo) {
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(8, 4, 34, 18, 2, 2, "F");
      try { doc.addImage(logo, "PNG", 9, 5, 32, 16); } catch { /* sem logo */ }
    }
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text("PMC-MCEDU-CAD · Levantamento Pedagógico", 48, 10);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.text("Secretaria Municipal de Educação · Coordenadoria de Microplanejamento Educacional", 48, 15);
    doc.text(`${opts.titulo} · Emitido em ${agora}`, 48, 20);
    doc.setTextColor(0, 0, 0);
  };

  const rodape = (pagina: number, total: number) => {
    doc.setDrawColor(...verde);
    doc.setLineWidth(0.6);
    doc.line(8, H - 14, W - 8, H - 14);
    doc.setFontSize(8);
    doc.setTextColor(80, 80, 80);
    doc.text("Prefeitura Municipal de Cuiabá · Secretaria Municipal de Educação", 8, H - 9);
    doc.text("Cuiabá - MT · www.cuiaba.mt.gov.br", 8, H - 5);
    doc.text(`Página ${pagina} de ${total}`, W - 8, H - 7, { align: "right" });
    doc.setTextColor(0, 0, 0);
  };

  let y = TOPO;
  doc.setFontSize(9);
  doc.text(opts.filtros, 8, y);
  y += 5;
  doc.setFont("helvetica", "bold");
  doc.text(opts.resumo, 8, y);
  doc.setFont("helvetica", "normal");
  y += 6;

  if (opts.grupos.length === 0) {
    doc.text("Nenhuma duplicidade encontrada.", 8, y);
  }

  for (const g of opts.grupos) {
    if (y > H - 40) { doc.addPage(); y = TOPO; }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text(`${g.nome}  (${g.linhas.length} ocorrências)`, 8, y);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(180, 30, 30);
    doc.text(`Inconsistência: ${g.conflito}`, 8, y + 4);
    doc.setTextColor(0, 0, 0);
    autoTable(doc, {
      startY: y + 6,
      head: [g.colunas],
      body: g.linhas,
      margin: { top: TOPO, bottom: 18, left: 8, right: 8 },
      styles: { fontSize: 7.5, cellPadding: 1.5 },
      headStyles: { fillColor: verde },
    });
    y = (doc as any).lastAutoTable.finalY + 7;
  }

  const total = doc.getNumberOfPages();
  for (let p = 1; p <= total; p++) {
    doc.setPage(p);
    cabecalho();
    rodape(p, total);
  }
  doc.save(`relatorio-referencia-cruzada-${new Date().toISOString().slice(0, 10)}.pdf`);
}
