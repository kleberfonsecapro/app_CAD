import { useMemo, useState } from "react";
import { AlertTriangle, Users, UserCheck, Trash2, CheckCheck, FileDown } from "lucide-react";
import { toast } from "sonner";
import { gerarPdfRelatorio } from "./relatorio-pdf";
import {
  atualizarDadosLevantamentoPedagogico,
  type LevantamentoPedagogico,
} from "@/lib/cadastro-api";

type Ocorrencia = {
  levantamentoId: string;
  vIdx: number;
  aIdx?: number;
  escola: string;
  periodo: string;
  serie: string;
  turma: string;
  cad: string;
  aluno?: string;
  alunosAtendidos?: { nome: string; cid: string; tea: string }[];
  cid?: string;
  tea?: string;
  laudo?: string;
  data: string;
};

type Grupo = { chave: string; nome: string; itens: Ocorrencia[]; conflito: string };

const norm = (s: unknown) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();

const salaKey = (o: Ocorrencia) =>
  [norm(o.escola), norm(o.periodo), norm(o.serie), norm(o.turma)].join("|");

function analisar(levs: LevantamentoPedagogico[]) {
  const cads = new Map<string, Ocorrencia[]>();
  const alunos = new Map<string, Ocorrencia[]>();
  for (const l of levs) {
    if (!l.id) continue;
    const sa = ((l.dados_pedagogicos ?? {}) as any).salaAula ?? {};
    const base = {
      levantamentoId: l.id,
      escola: l.unidade_nome,
      periodo: sa.periodo || "—",
      serie: sa.ano || "—",
      turma: sa.turma || "—",
      data: l.data_levantamento ?? "",
    };
    ((sa.vinculos ?? []) as any[]).forEach((v, vIdx) => {
      const cadNome = v?.cadNome || "";
      if (!cadNome) return;
      const lista = ((v.alunos ?? []) as any[]).filter((a) => norm(a?.nome));
      const kc = norm(cadNome);
      if (!cads.has(kc)) cads.set(kc, []);
      cads.get(kc)!.push({
        ...base,
        vIdx,
        cad: cadNome,
        alunosAtendidos: lista.map((a) => ({
          nome: a.nome,
          cid: a.cid || "",
          tea: a.teaNivelSuporte || "",
        })),
      });
      ((v.alunos ?? []) as any[]).forEach((a, aIdx) => {
        const ka = norm(a?.nome);
        if (!ka) return;
        if (!alunos.has(ka)) alunos.set(ka, []);
        alunos.get(ka)!.push({
          ...base,
          vIdx,
          aIdx,
          cad: cadNome,
          aluno: a.nome,
          cid: a.cid || "",
          tea: a.teaNivelSuporte || "",
          laudo: a.possuiLaudo || "",
        });
      });
    });
  }

  const gruposCad: Grupo[] = [];
  for (const [k, itens] of cads) {
    if (itens.length < 2) continue;
    const escolas = new Set(itens.map((i) => norm(i.escola)));
    const salas = new Set(itens.map(salaKey));
    const porTurno = new Map<string, Set<string>>();
    for (const i of itens) {
      const t = norm(i.periodo);
      if (!porTurno.has(t)) porTurno.set(t, new Set());
      porTurno.get(t)!.add(salaKey(i));
    }
    let conflito = "Mesma sala em mais de um lançamento";
    if ([...porTurno.values()].some((s) => s.size > 1))
      conflito = "Mesmo turno em salas/escolas diferentes";
    else if (escolas.size > 1) conflito = "Atua em mais de uma escola";
    else if (salas.size > 1) conflito = "Mais de uma sala na mesma escola";
    gruposCad.push({ chave: k, nome: itens[0].cad, itens, conflito });
  }

  const gruposAluno: Grupo[] = [];
  for (const [k, itens] of alunos) {
    if (itens.length < 2) continue;
    const salas = new Set(itens.map(salaKey));
    const cadsSet = new Set(itens.map((i) => norm(i.cad)));
    let conflito = "Lançamento repetido";
    if (salas.size > 1) conflito = "Aluno lançado em salas/escolas diferentes";
    else if (cadsSet.size > 1) conflito = "Aluno vinculado a mais de um CAD";
    gruposAluno.push({ chave: k, nome: itens[0].aluno!, itens, conflito });
  }

  const ord = (a: Grupo, b: Grupo) =>
    b.itens.length - a.itens.length || a.nome.localeCompare(b.nome, "pt-BR");
  return { gruposCad: gruposCad.sort(ord), gruposAluno: gruposAluno.sort(ord) };
}

export default function RelatorioReferenciaCruzada({
  levantamentos,
  onChange,
}: {
  levantamentos: LevantamentoPedagogico[];
  onChange: () => void | Promise<void>;
}) {
  const [aba, setAba] = useState<"cads" | "alunos">("cads");
  const [busca, setBusca] = useState("");
  const [filtroConflito, setFiltroConflito] = useState("");
  const [filtroEscola, setFiltroEscola] = useState("");
  const [salvando, setSalvando] = useState(false);
  const { gruposCad, gruposAluno } = useMemo(() => analisar(levantamentos), [levantamentos]);
  const grupos = aba === "cads" ? gruposCad : gruposAluno;
  const tiposConflito = [...new Set(grupos.map((g) => g.conflito))];
  const escolas = [...new Set(grupos.flatMap((g) => g.itens.map((i) => i.escola)))].sort((a, b) =>
    a.localeCompare(b, "pt-BR"),
  );
  const lista = grupos.filter(
    (g) =>
      (!busca || g.chave.includes(norm(busca))) &&
      (!filtroConflito || g.conflito === filtroConflito) &&
      (!filtroEscola || g.itens.some((i) => i.escola === filtroEscola)),
  );

  const [selecionados, setSelecionados] = useState<Set<string>>(new Set());
  const chaveOc = (o: Ocorrencia) => `${o.levantamentoId}|${o.vIdx}|${o.aIdx ?? ""}`;
  const selecionadasLista = (() => {
    const vistos = new Set<string>();
    const out: Ocorrencia[] = [];
    for (const g of grupos)
      for (const i of g.itens) {
        const k = chaveOc(i);
        if (selecionados.has(k) && !vistos.has(k)) {
          vistos.add(k);
          out.push(i);
        }
      }
    return out;
  })();
  function alternar(ocs: Ocorrencia[]) {
    setSelecionados((prev) => {
      const next = new Set(prev);
      const todos = ocs.every((o) => next.has(chaveOc(o)));
      for (const o of ocs) {
        if (todos) next.delete(chaveOc(o));
        else next.add(chaveOc(o));
      }
      return next;
    });
  }

  async function cancelar(ocorrencias: Ocorrencia[]) {
    const porLev = new Map<string, Ocorrencia[]>();
    for (const o of ocorrencias) {
      if (!porLev.has(o.levantamentoId)) porLev.set(o.levantamentoId, []);
      porLev.get(o.levantamentoId)!.push(o);
    }
    setSalvando(true);
    try {
      for (const [id, ocs] of porLev) {
        const lev = levantamentos.find((l) => l.id === id);
        if (!lev) continue;
        const dados = structuredClone((lev.dados_pedagogicos ?? {}) as any);
        const vinculos: any[] = dados.salaAula?.vinculos ?? [];
        if (aba === "cads") {
          const idx = [...new Set(ocs.map((o) => o.vIdx))].sort((a, b) => b - a);
          for (const i of idx) vinculos.splice(i, 1);
        } else {
          const pares = ocs.sort((a, b) => b.vIdx - a.vIdx || (b.aIdx ?? 0) - (a.aIdx ?? 0));
          for (const o of pares) vinculos[o.vIdx]?.alunos?.splice(o.aIdx!, 1);
        }
        dados.salaAula = { ...(dados.salaAula ?? {}), vinculos };
        await atualizarDadosLevantamentoPedagogico(id, dados);
      }
      toast.success(`${ocorrencias.length} registro(s) duplicado(s) cancelado(s).`);
      setSelecionados(new Set());
      await onChange();
    } catch {
      toast.error("Não foi possível cancelar. Tente novamente.");
    } finally {
      setSalvando(false);
    }
  }

  function confirmarCancelar(ocs: Ocorrencia[], texto: string) {
    if (window.confirm(texto)) cancelar(ocs);
  }

  async function imprimirPdf() {
    const ehCad = aba === "cads";
    const colunas = ehCad
      ? ["#", "Escola", "Turno", "Série", "Turma", "Alunos atendidos", "Data"]
      : ["#", "Escola", "Turno", "Série", "Turma", "CAD que atende", "CID", "TEA", "Laudo", "Data"];
    try {
      await gerarPdfRelatorio({
        titulo: `Referência cruzada — ${ehCad ? "CADs" : "Alunos"} em duplicidade`,
        filtros: `Filtros: nome "${busca || "todos"}" · inconsistência "${filtroConflito || "todas"}" · escola "${filtroEscola || "todas"}"`,
        resumo: `${lista.length} ${ehCad ? "CAD(s)" : "aluno(s)"} em duplicidade · ${levantamentos.length} levantamentos analisados`,
        grupos: lista.map((g) => ({
          nome: g.nome,
          conflito: g.conflito,
          colunas,
          linhas: g.itens.map((i, idx) =>
            ehCad
              ? [String(idx + 1), i.escola, i.periodo, i.serie, i.turma,
                 (i.alunosAtendidos ?? []).map((a) => [a.nome, a.cid, a.tea && `TEA ${a.tea}`].filter(Boolean).join(" · ")).join("\n") || "Nenhum aluno",
                 i.data || "—"]
              : [String(idx + 1), i.escola, i.periodo, i.serie, i.turma, i.cad, i.cid || "—", i.tea || "—", i.laudo || "—", i.data || "—"],
          ),
        })),
      });
    } catch {
      toast.error("Não foi possível gerar o PDF.");
    }
  }

  const sel = "rounded-md border border-input bg-background px-3 py-2 text-sm";

  return (
    <section className="space-y-3">
      <header className="rounded-xl border border-border bg-card p-4">
        <h2 className="flex items-center gap-2 text-base font-bold">
          <AlertTriangle className="h-4 w-4 text-primary" />
          Relatório de referência cruzada
        </h2>
        <p className="mt-1 text-xs text-muted-foreground">
          Confere todos os levantamentos enviados ({levantamentos.length}) e aponta CADs e alunos que
          aparecem mais de uma vez. Use as ações para sanear o cadastro cancelando os lançamentos
          duplicados.
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="rounded-lg bg-muted p-3">
            <p className="text-[11px] text-muted-foreground">CADs em duplicidade</p>
            <p className="text-xl font-bold">{gruposCad.length}</p>
          </div>
          <div className="rounded-lg bg-muted p-3">
            <p className="text-[11px] text-muted-foreground">Alunos em duplicidade</p>
            <p className="text-xl font-bold">{gruposAluno.length}</p>
          </div>
        </div>
      </header>

      <div className="flex gap-2">
        {(["cads", "alunos"] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => {
              setAba(t);
              setFiltroConflito("");
              setSelecionados(new Set());
            }}
            className={`flex flex-1 items-center justify-center gap-2 rounded-md px-3 py-2 text-sm font-semibold ${aba === t ? "bg-primary text-primary-foreground" : "bg-muted"}`}
          >
            {t === "cads" ? <UserCheck className="h-4 w-4" /> : <Users className="h-4 w-4" />}
            {t === "cads" ? "CADs" : "Alunos"}
          </button>
        ))}
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <input
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          placeholder={aba === "cads" ? "Filtrar por nome do CAD" : "Filtrar por nome do aluno"}
          className={sel}
        />
        <select value={filtroConflito} onChange={(e) => setFiltroConflito(e.target.value)} className={sel}>
          <option value="">Todas as inconsistências</option>
          {tiposConflito.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        <select value={filtroEscola} onChange={(e) => setFiltroEscola(e.target.value)} className={sel}>
          <option value="">Todas as escolas</option>
          {escolas.map((e) => (
            <option key={e} value={e}>{e}</option>
          ))}
        </select>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-[11px] text-muted-foreground">{lista.length} resultado(s)</p>
        <div className="flex flex-wrap items-center gap-2">
          {selecionadasLista.length > 0 && (
            <>
              <button
                type="button"
                onClick={() => setSelecionados(new Set())}
                className="rounded-md bg-muted px-3 py-2 text-sm font-semibold"
              >
                Limpar seleção
              </button>
              <button
                type="button"
                disabled={salvando}
                onClick={() =>
                  confirmarCancelar(
                    selecionadasLista,
                    `Cancelar ${selecionadasLista.length} ocorrência(s) selecionada(s)? Esta ação não pode ser desfeita.`,
                  )
                }
                className="inline-flex items-center gap-1.5 rounded-md bg-destructive px-3 py-2 text-sm font-semibold text-destructive-foreground disabled:opacity-60"
              >
                <Trash2 className="h-4 w-4" /> Cancelar selecionados ({selecionadasLista.length})
              </button>
            </>
          )}
          <button
            type="button"
            onClick={imprimirPdf}
            className="inline-flex items-center gap-1.5 rounded-md bg-secondary px-3 py-2 text-sm font-semibold text-secondary-foreground"
          >
            <FileDown className="h-4 w-4" /> Imprimir PDF
          </button>
        </div>
      </div>

      {lista.length === 0 ? (
        <p className="rounded-xl border border-border bg-card p-4 text-sm text-muted-foreground">
          Nenhuma duplicidade encontrada.
        </p>
      ) : (
        <ul className="space-y-3">
          {lista.map((g) => (
            <li key={g.chave} className="rounded-xl border border-border bg-card p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-bold">{g.nome}</p>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold">
                    {g.itens.length} ocorrências
                  </span>
                  <button
                    type="button"
                    disabled={salvando}
                    onClick={() =>
                      confirmarCancelar(
                        g.itens.slice(1),
                        `Manter apenas a 1ª ocorrência de "${g.nome}" e cancelar as outras ${g.itens.length - 1}?`,
                      )
                    }
                    className="inline-flex items-center gap-1 rounded-md bg-primary px-2 py-1 text-[11px] font-semibold text-primary-foreground disabled:opacity-60"
                  >
                    <CheckCheck className="h-3 w-3" /> Manter 1ª e cancelar demais
                  </button>
                </div>
              </div>
              <p className="mt-1 inline-flex items-center gap-1 rounded-md bg-destructive/10 px-2 py-1 text-[11px] font-semibold text-destructive">
                <AlertTriangle className="h-3 w-3" /> {g.conflito}
              </p>
              <div className="mt-2 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="text-muted-foreground">
                    <tr>
                      <th className="py-1 pr-2">
                        <input
                          type="checkbox"
                          aria-label="Selecionar todas deste nome"
                          checked={g.itens.every((i) => selecionados.has(chaveOc(i)))}
                          onChange={() => alternar(g.itens)}
                          className="h-4 w-4 accent-primary"
                        />
                      </th>
                      <th className="py-1 pr-2">#</th>
                      <th className="py-1 pr-2">Escola</th>
                      <th className="py-1 pr-2">Turno</th>
                      <th className="py-1 pr-2">Série</th>
                      <th className="py-1 pr-2">Turma</th>
                      {aba === "cads" ? (
                        <th className="py-1 pr-2">Alunos atendidos</th>
                      ) : (
                        <>
                          <th className="py-1 pr-2">CAD que atende</th>
                          <th className="py-1 pr-2">CID</th>
                          <th className="py-1 pr-2">TEA</th>
                          <th className="py-1 pr-2">Laudo</th>
                        </>
                      )}
                      <th className="py-1 pr-2">Data</th>
                      <th className="py-1">Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {g.itens.map((i, idx) => (
                      <tr key={idx} className={`border-t border-border align-top ${selecionados.has(chaveOc(i)) ? "bg-destructive/5" : ""}`}>
                        <td className="py-1 pr-2">
                          <input
                            type="checkbox"
                            aria-label={`Selecionar ocorrência ${idx + 1}`}
                            checked={selecionados.has(chaveOc(i))}
                            onChange={() => alternar([i])}
                            className="h-4 w-4 accent-primary"
                          />
                        </td>
                        <td className="py-1 pr-2 font-semibold">{idx + 1}</td>
                        <td className="py-1 pr-2">{i.escola}</td>
                        <td className="py-1 pr-2">{i.periodo}</td>
                        <td className="py-1 pr-2">{i.serie}</td>
                        <td className="py-1 pr-2">{i.turma}</td>
                        {aba === "cads" ? (
                          <td className="py-1 pr-2">
                            {i.alunosAtendidos?.length ? (
                              <ul className="space-y-0.5">
                                {i.alunosAtendidos.map((a, k) => (
                                  <li key={k}>
                                    {a.nome}
                                    {(a.cid || a.tea) && (
                                      <span className="text-muted-foreground">
                                        {" "}· {[a.cid, a.tea && `TEA ${a.tea}`].filter(Boolean).join(" · ")}
                                      </span>
                                    )}
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              <span className="text-muted-foreground">Nenhum aluno</span>
                            )}
                          </td>
                        ) : (
                          <>
                            <td className="py-1 pr-2">{i.cad}</td>
                            <td className="py-1 pr-2">{i.cid || "—"}</td>
                            <td className="py-1 pr-2">{i.tea || "—"}</td>
                            <td className="py-1 pr-2">{i.laudo || "—"}</td>
                          </>
                        )}
                        <td className="py-1 pr-2">{i.data || "—"}</td>
                        <td className="py-1">
                          <button
                            type="button"
                            disabled={salvando}
                            onClick={() =>
                              confirmarCancelar(
                                [i],
                                aba === "cads"
                                  ? `Cancelar o vínculo de "${i.cad}" em ${i.escola} (${i.periodo}, ${i.serie} ${i.turma})? Os alunos desse vínculo também saem do lançamento.`
                                  : `Cancelar "${i.aluno}" do CAD ${i.cad} em ${i.escola} (${i.periodo}, ${i.serie} ${i.turma})?`,
                              )
                            }
                            className="inline-flex items-center gap-1 rounded-md bg-destructive/10 px-2 py-1 text-[11px] font-semibold text-destructive disabled:opacity-60"
                          >
                            <Trash2 className="h-3 w-3" /> Cancelar
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
