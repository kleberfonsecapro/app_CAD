import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { fetchUnidades } from "@/lib/matriculas";
import {
  salvarCadastro,
  salvarLevantamentoPedagogico,
  listarCADs,
  type CadastroUnidade,
  type LevantamentoPedagogico,
  type CAD,
} from "@/lib/cadastro-api";
import {
  ETAPAS_PEDAGOGICAS,
  calcularNotaPedagogica,
} from "@/lib/pedagogico/pedagogico-schema";
import { corDaNota } from "@/lib/cadastro-schema";
import { Check, Plus, Search, Trash2, UserPlus, X, ChevronDown, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { salvarCAD } from "@/lib/cadastro-api";
import cidData from "@/data/cid10.json";

type JsonRecord = Record<string, any>;

type UnidadeMapa = {
  unidade: string;
  regiao: string;
  rua?: string | null;
  numero?: string | null;
  bairro?: string | null;
  cep?: string | null;
  endereco?: string | null;
  lat?: number;
  lon?: number;
  estudantes?: number;
  cuidadores?: number;
};

const normalizar = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .trim();

type Props = {
  unidades: UnidadeMapa[];
  cadastros: CadastroUnidade[];
  levantamentoInicial?: LevantamentoPedagogico | null;
  onSaved: () => void;
  onCancel: () => void;
};

const inputCls =
  "w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary";
const labelCls = "text-xs font-semibold uppercase tracking-wide text-muted-foreground";

export default function LevantamentoPedagogicoForm({
  unidades,
  cadastros,
  levantamentoInicial,
  onSaved,
  onCancel,
}: Props) {
  const [etapa, setEtapa] = useState(1);
  const [salvando, setSalvando] = useState(false);
  // Controle de validação do campo obrigatório "Responsável Técnico".
  const [erroResponsavel, setErroResponsavel] = useState(false);

  /** Verifica se o nome do responsável técnico foi realmente preenchido. */
  const responsavelPreenchido = () => (gerais.responsavel ?? "").trim().length > 0;

  /** Bloqueia o prosseguimento enquanto o nome do responsável técnico estiver em branco. */
  const exigirResponsavelTecnico = (mensagem: string) => {
    if (responsavelPreenchido()) return true;
    setErroResponsavel(true);
    setEtapa(1);
    toast.error(mensagem);
    return false;
  };
  const [carregandoCADs, setCarregandoCADs] = useState(false);
  const [cadsDisponiveis, setCadsDisponiveis] = useState<CAD[]>([]);
  const [termoBuscaCAD, setTermoBuscaCAD] = useState("");
  const [termoBuscaCID, setTermoBuscaCID] = useState<{ vIdx: number, aIdx: number, termo: string } | null>(null);
  const [modalNovoCAD, setModalNovoCAD] = useState(false);
  const [salvandoNovoCAD, setSalvandoNovoCAD] = useState(false);
  const [novoCADForm, setNovoCADForm] = useState<{
    nome: string;
    jornada: number;
    cargo: string;
    matricula: string;
    situacao: string;
    data_admissao: string;
  }>({
    nome: "",
    jornada: 30,
    cargo: "CUIDADOR DE ALUNO COM DEFICIÊNCIA",
    matricula: "",
    situacao: "Em Exercício",
    data_admissao: "",
  });

  const [unidadeId, setUnidadeId] = useState(levantamentoInicial?.unidade_id ?? "");
  // Filtro de unidades: ao digitar o nome, lista as unidades cadastradas no sistema.
  const [buscaUnidade, setBuscaUnidade] = useState(levantamentoInicial?.unidade_id ?? "");
  const [mostrarListaUnidade, setMostrarListaUnidade] = useState(false);

  const unidadesFiltradas = useMemo(() => {
    const termo = normalizar(buscaUnidade);
    if (!termo) return unidades;
    return unidades.filter(
      (u) =>
        normalizar(u.unidade).includes(termo) || normalizar(u.regiao).includes(termo),
    );
  }, [unidades, buscaUnidade]);
  
  const unidadeSelecionada = useMemo(
    () => unidades.find((u) => u.unidade === unidadeId),
    [unidades, unidadeId],
  );

  const [gerais, setGerais] = useState({
    data_levantamento: levantamentoInicial?.data_levantamento ?? new Date().toISOString().slice(0, 10),
    responsavel: levantamentoInicial?.responsavel ?? "",
  });

  const [dadosPedagogicos, setDadosPedagogicos] = useState<JsonRecord>(levantamentoInicial?.dados_pedagogicos ?? {
    salaAula: {
      ano: "",
      turma: "",
      periodo: "",
      vinculos: []
    }
  });

  const carregarCADs = useCallback(async () => {
    setCarregandoCADs(true);
    try {
      const list = await listarCADs();
      setCadsDisponiveis(list);
    } catch (error) {
      console.error("Erro ao carregar profissionais CAD:", error);
      toast.error("Não foi possível carregar os profissionais CAD cadastrados.");
    } finally {
      setCarregandoCADs(false);
    }
  }, []);

  useEffect(() => {
    if (etapa === 2) {
      void carregarCADs();
    }
  }, [etapa, carregarCADs]);

  const notaMedia = calcularNotaPedagogica(dadosPedagogicos);

  function proxima() {
    if (etapa === 1 && !unidadeId) {
      toast.error("Selecione a unidade educacional.");
      return;
    }
    if (etapa === 1 && !exigirResponsavelTecnico("Informe o nome do Responsável Técnico (campo obrigatório).")) {
      return;
    }
    // Agora só temos 3 etapas
    setEtapa((e) => Math.min(2, e + 1));
  }

  async function finalizar(status: "rascunho" | "concluida") {
    if (!unidadeId) {
      toast.error("Selecione a unidade educacional.");
      return;
    }
    // Campo obrigatório: o levantamento (rascunho ou concluído) não aceita
    // Responsável Técnico em branco.
    if (
      !exigirResponsavelTecnico(
        status === "concluida"
          ? "Preencha o nome do Responsável Técnico para concluir o levantamento."
          : "Preencha o nome do Responsável Técnico para salvar o levantamento.",
      )
    ) {
      return;
    }
    setSalvando(true);
    try {
      await salvarLevantamentoPedagogico({
        id: levantamentoInicial?.id,
        unidade_id: unidadeId,
        unidade_nome: unidadeId,
        data_levantamento: gerais.data_levantamento || null,
        responsavel: (gerais.responsavel ?? "").trim() || null,
        dados_pedagogicos: dadosPedagogicos,
        etapa,
        status,
      });
      toast.success(
        status === "concluida" ? "Levantamento concluído com sucesso." : "Rascunho salvo.",
      );
      onSaved();
    } catch (e) {
      toast.error((e as Error).message ?? "Falha ao salvar.");
    } finally {
      setSalvando(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {ETAPAS_PEDAGOGICAS.map((e) => (
          <button
            key={e.id}
            type="button"
            onClick={() => {
              // Não deixa ir para a Sala de Aula sem informar o Responsável Técnico.
              if (e.id > 1 && !responsavelPreenchido()) {
                setErroResponsavel(true);
                setEtapa(1);
                toast.error("Informe o nome do Responsável Técnico (campo obrigatório).");
                return;
              }
              setEtapa(e.id);
            }}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
              etapa === e.id
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/70"
            }`}
          >
            {e.id}. {e.label}
          </button>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-4 sm:p-6">
        {etapa === 1 && (
          <section className="space-y-4">
            <header>
              <h3 className="text-base font-bold">1. Identificação da Unidade</h3>
              <p className="text-xs text-muted-foreground">
                Selecione a unidade para iniciar o levantamento pedagógico.
              </p>
            </header>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className={labelCls}>Unidade Educacional *</label>
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    className={`${inputCls} pl-9 pr-9`}
                    placeholder="Digite o nome da unidade educacional..."
                    autoComplete="off"
                    value={buscaUnidade}
                    onChange={(ev) => {
                      const valor = ev.target.value;
                      setBuscaUnidade(valor);
                      setMostrarListaUnidade(true);
                      if (valor.trim() !== unidadeId) setUnidadeId("");
                    }}
                    onFocus={() => {
                      setBuscaUnidade((atual) => atual || unidadeId);
                      setMostrarListaUnidade(true);
                    }}
                    onBlur={() => window.setTimeout(() => setMostrarListaUnidade(false), 150)}
                    onKeyDown={(ev) => {
                      if (
                        ev.key === "Enter" &&
                        mostrarListaUnidade &&
                        unidadesFiltradas.length > 0
                      ) {
                        ev.preventDefault();
                        const escolhida = unidadesFiltradas[0];
                        setUnidadeId(escolhida.unidade);
                        setBuscaUnidade(escolhida.unidade);
                        setMostrarListaUnidade(false);
                      }
                      if (ev.key === "Escape") setMostrarListaUnidade(false);
                    }}
                  />
                  {(buscaUnidade || unidadeId) && (
                    <button
                      type="button"
                      aria-label="Limpar unidade selecionada"
                      onMouseDown={(ev) => ev.preventDefault()}
                      onClick={() => {
                        setBuscaUnidade("");
                        setUnidadeId("");
                        setMostrarListaUnidade(true);
                      }}
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground transition-colors hover:text-foreground"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}

                  {mostrarListaUnidade && (
                    <div className="absolute left-0 right-0 z-50 mt-1 max-h-64 overflow-y-auto rounded-md border border-border bg-popover shadow-xl">
                      <p className="border-b border-border px-3 py-2 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                        {unidadesFiltradas.length} unidade
                        {unidadesFiltradas.length === 1 ? "" : "s"} cadastrada
                        {unidadesFiltradas.length === 1 ? "" : "s"} no sistema
                      </p>

                      {unidadesFiltradas.length === 0 ? (
                        <p className="px-3 py-3 text-xs text-muted-foreground">
                          Nenhuma unidade encontrada para{" "}
                          <strong>&ldquo;{buscaUnidade}&rdquo;</strong>. Confira a grafia ou tente
                          apenas parte do nome.
                        </p>
                      ) : (
                        <>
                          {unidadesFiltradas.slice(0, 60).map((u) => (
                            <button
                              key={u.unidade}
                              type="button"
                              onMouseDown={(ev) => ev.preventDefault()}
                              onClick={() => {
                                setUnidadeId(u.unidade);
                                setBuscaUnidade(u.unidade);
                                setMostrarListaUnidade(false);
                              }}
                              className={`flex w-full items-center justify-between gap-3 border-b border-border/60 px-3 py-2 text-left text-sm transition-colors last:border-b-0 hover:bg-accent ${
                                unidadeId === u.unidade ? "bg-accent font-semibold" : ""
                              }`}
                            >
                              <span className="truncate">{u.unidade}</span>
                              <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-[10px] font-semibold text-muted-foreground">
                                {u.regiao}
                              </span>
                            </button>
                          ))}
                          {unidadesFiltradas.length > 60 && (
                            <p className="px-3 py-2 text-[11px] italic text-muted-foreground">
                              Mostrando as 60 primeiras de {unidadesFiltradas.length} unidades —
                              continue digitando para refinar.
                            </p>
                          )}
                        </>
                      )}
                    </div>
                  )}
                </div>
                {unidadeSelecionada && !mostrarListaUnidade && (
                  <p className="mt-1 text-[11px] text-primary">
                    Unidade selecionada: {unidadeSelecionada.unidade} · Região{" "}
                    {unidadeSelecionada.regiao}
                  </p>
                )}
              </div>

              <div>
                <label className={labelCls}>Data do Levantamento</label>
                <input
                  type="date"
                  className={inputCls}
                  value={gerais.data_levantamento}
                  onChange={(ev) => setGerais((g) => ({ ...g, data_levantamento: ev.target.value }))}
                />
              </div>
              <div>
                <label className={labelCls}>
                  Responsável Técnico <span className="text-destructive">*</span>
                </label>
                <input
                  className={`${inputCls} ${
                    erroResponsavel
                      ? "border-destructive focus:border-destructive ring-2 ring-destructive/20"
                      : ""
                  }`}
                  placeholder="Nome do avaliador (obrigatório)"
                  aria-required="true"
                  aria-invalid={erroResponsavel || undefined}
                  value={gerais.responsavel}
                  onChange={(ev) => {
                    setErroResponsavel(false);
                    setGerais((g) => ({ ...g, responsavel: ev.target.value }));
                  }}
                  onBlur={() => {
                    if (!responsavelPreenchido()) setErroResponsavel(true);
                  }}
                />
                {erroResponsavel && (
                  <p className="mt-1 text-[11px] font-semibold text-destructive">
                    Campo obrigatório — informe o nome do Responsável Técnico.
                  </p>
                )}
              </div>
            </div>
          </section>
        )}

        {etapa === 2 && (
          <section className="space-y-6">
            <header>
              <h3 className="text-base font-bold">2. Sala de Aula</h3>
              <p className="text-xs text-muted-foreground">
                Informações detalhadas sobre a turma, profissionais e inclusão.
              </p>
            </header>

            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label className={labelCls}>Ano/Série</label>
                <select
                  className={inputCls}
                  value={dadosPedagogicos.salaAula?.ano ?? ""}
                  onChange={(ev) => setDadosPedagogicos(d => ({
                    ...d,
                    salaAula: { ...d.salaAula, ano: ev.target.value }
                  }))}
                >
                  <option value="">Selecione...</option>
                  {["G1", "G2", "G3", "G4", "G5", "1º Ano", "2º Ano", "3º Ano", "4º Ano", "5º Ano"].map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelCls}>Turma</label>
                <select
                  className={inputCls}
                  value={dadosPedagogicos.salaAula?.turma ?? ""}
                  onChange={(ev) => setDadosPedagogicos(d => ({
                    ...d,
                    salaAula: { ...d.salaAula, turma: ev.target.value }
                  }))}
                >
                  <option value="">Selecione...</option>
                  {["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"].map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelCls}>Período</label>
                <select
                  className={inputCls}
                  value={dadosPedagogicos.salaAula?.periodo ?? ""}
                  onChange={(ev) => setDadosPedagogicos(d => ({
                    ...d,
                    salaAula: { ...d.salaAula, periodo: ev.target.value }
                  }))}
                >
                  <option value="">Selecione...</option>
                  <option value="Matutino">Matutino</option>
                  <option value="Vespertino">Vespertino</option>
                  <option value="Integral">Integral</option>
                  <option value="Transporte">Transporte</option>
                  
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className={labelCls}>Profissionais CADs & Alunos Atendidos</label>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                  <input
                    className={`${inputCls} pl-9`}
                    placeholder="Vincular novo CAD..."
                    value={termoBuscaCAD}
                    onChange={(ev) => setTermoBuscaCAD(ev.target.value)}
                  />
                  {termoBuscaCAD.length >= 2 && (
                    <div className="absolute z-10 mt-1 max-h-48 w-full overflow-y-auto rounded-md border border-border bg-popover shadow-lg">
                      {carregandoCADs && (
                        <div className="flex items-center gap-2 px-3 py-3 text-xs text-muted-foreground">
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          Atualizando profissionais cadastrados...
                        </div>
                      )}
                      {(() => {
                        const filtrados = cadsDisponiveis
                          .filter(c => normalizar(c.nome).includes(normalizar(termoBuscaCAD)))
                          .slice(0, 10);
                        if (filtrados.length === 0) {
                          return (
                            <div className="flex flex-col items-center gap-2 px-3 py-4 text-center">
                              <p className="text-xs text-muted-foreground">Nenhum profissional encontrado para <strong>&ldquo;{termoBuscaCAD}&rdquo;</strong>.</p>
                              <button
                                type="button"
                                className="flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
                                onClick={() => {
                                  setNovoCADForm(f => ({ ...f, nome: termoBuscaCAD }));
                                  setModalNovoCAD(true);
                                  setTermoBuscaCAD("");
                                }}
                              >
                                <Plus className="h-3 w-3" />
                                Cadastrar novo CAD
                              </button>
                            </div>
                          );
                        }
                        return filtrados.map(cad => (
                          <button
                            key={cad.id}
                            type="button"
                            className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-muted"
                            onClick={() => {
                              const vinculos = dadosPedagogicos.salaAula?.vinculos || [];
                              if (!vinculos.find((v: any) => v.cadNome === cad.nome)) {
                                setDadosPedagogicos(d => ({
                                  ...d,
                                  salaAula: {
                                    ...d.salaAula,
                                    vinculos: [...vinculos, { cadId: cad.id, cadNome: cad.nome, alunos: [] }]
                                  }
                                }));
                              }
                              setTermoBuscaCAD("");
                            }}
                          >
                            <span>
                              <span className="block font-medium">{cad.nome}</span>
                              {cad.matricula && (
                                <span className="block text-[11px] text-muted-foreground">
                                  Matrícula: {cad.matricula}
                                </span>
                              )}
                            </span>
                            <Plus className="h-3 w-3 shrink-0" />
                          </button>
                        ));
                      })()}
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                {(dadosPedagogicos.salaAula?.vinculos || []).map((vinculo: any, vIdx: number) => (
                  <div key={vIdx} className="rounded-xl border border-border bg-muted/20 p-4">
                    <div className="mb-4 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="rounded-full bg-primary/10 p-2">
                          <UserPlus className="h-4 w-4 text-primary" />
                        </div>
                        <span className="font-bold text-sm">{vinculo.cadNome}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                          newVinculos.splice(vIdx, 1);
                          setDadosPedagogicos(d => ({
                            ...d,
                            salaAula: { ...d.salaAula, vinculos: newVinculos }
                          }));
                        }}
                        className="text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="space-y-4">
                      {vinculo.alunos.map((aluno: any, aIdx: number) => (
                        <div key={aIdx} className="relative rounded-lg border border-border bg-background p-4 shadow-sm">
                          <button
                            type="button"
                            onClick={() => {
                              const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                              newVinculos[vIdx].alunos.splice(aIdx, 1);
                              setDadosPedagogicos(d => ({
                                ...d,
                                salaAula: { ...d.salaAula, vinculos: newVinculos }
                              }));
                            }}
                            className="absolute -right-2 -top-2 rounded-full bg-destructive/10 p-1 text-destructive hover:bg-destructive/20 transition-colors"
                          >
                            <X className="h-3 w-3" />
                          </button>
                          
                          <div className="grid gap-3 sm:grid-cols-2">
                            <div>
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">Estudante</label>
                              <input
                                className={inputCls}
                                value={aluno.nome}
                                onChange={(ev) => {
                                  const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                  newVinculos[vIdx].alunos[aIdx].nome = ev.target.value;
                                  setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                }}
                              />
                            </div>
                            <div className="relative">
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">CID</label>
                              <div className="relative">
                                <input
                                  className={inputCls}
                                  placeholder="Ex: F84.0"
                                  value={aluno.cid}
                                  onChange={(ev) => {
                                    const val = ev.target.value;
                                    const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                    newVinculos[vIdx].alunos[aIdx].cid = val;
                                    setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                    setTermoBuscaCID({ vIdx, aIdx, termo: val });
                                  }}
                                  onFocus={() => setTermoBuscaCID({ vIdx, aIdx, termo: aluno.cid })}
                                />
                                {termoBuscaCID?.vIdx === vIdx && termoBuscaCID?.aIdx === aIdx && termoBuscaCID.termo.length >= 1 && (
                                  <div className="absolute z-50 mt-1 max-h-48 w-full overflow-y-auto rounded-md border border-border bg-popover shadow-xl animate-in fade-in zoom-in duration-200">
                                    {cidData
                                      .filter(c => 
                                        c.codigo.toLowerCase().includes(termoBuscaCID.termo.toLowerCase()) || 
                                        c.descricao.toLowerCase().includes(termoBuscaCID.termo.toLowerCase())
                                      )
                                      .slice(0, 50)
                                      .map(cid => (
                                        <button
                                          key={cid.codigo}
                                          type="button"
                                          className="flex w-full flex-col px-3 py-2 text-left text-xs hover:bg-muted border-b border-border/50 last:border-0"
                                          onClick={() => {
                                            const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                            newVinculos[vIdx].alunos[aIdx].cid = cid.codigo;
                                            setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                            setTermoBuscaCID(null);
                                          }}
                                        >
                                          <span className="font-bold text-primary">{cid.codigo}</span>
                                          <span className="text-muted-foreground truncate">{cid.descricao}</span>
                                        </button>
                                      ))}
                                    {cidData.filter(c => 
                                      c.codigo.toLowerCase().includes(termoBuscaCID.termo.toLowerCase()) || 
                                      c.descricao.toLowerCase().includes(termoBuscaCID.termo.toLowerCase())
                                    ).length === 0 && (
                                      <div className="px-3 py-2 text-xs text-muted-foreground italic">
                                        Nenhum CID encontrado.
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div>
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">Nível Suporte (TEA)</label>
                              <select
                                className={inputCls}
                                value={aluno.teaNivelSuporte}
                                onChange={(ev) => {
                                  const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                  newVinculos[vIdx].alunos[aIdx].teaNivelSuporte = ev.target.value;
                                  setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                }}
                              >
                                <option value="">Selecione...</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="Não se aplica">Não se aplica</option>
                                <option value="Não informado">Não informado</option>
                              </select>
                            </div>
                            <div>
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">Autonomia (TEA)</label>
                              <select
                                className={inputCls}
                                value={aluno.teaAutonomia}
                                onChange={(ev) => {
                                  const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                  newVinculos[vIdx].alunos[aIdx].teaAutonomia = ev.target.value;
                                  setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                }}
                              >
                                <option value="">Selecione...</option>
                                <option value="Autonomia com o suporte">Autonomia com o suporte</option>
                                <option value="Autonomia sem suporte">Autonomia sem suporte</option>
                                <option value="Não se aplica">Não se aplica</option>
                              </select>
                            </div>
                            <div>
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">Transtornos</label>
                              <select
                                className={inputCls}
                                value={aluno.possuiTranstornos}
                                onChange={(ev) => {
                                  const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                  newVinculos[vIdx].alunos[aIdx].possuiTranstornos = ev.target.value;
                                  // Limpa campos dependentes se mudar para NÃO ou vazio
                                  if (ev.target.value !== "SIM") {
                                    newVinculos[vIdx].alunos[aIdx].altasHabilidades = "";
                                    newVinculos[vIdx].alunos[aIdx].observacoesTranstorno = "";
                                  }
                                  setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                }}
                              >
                                <option value="">Selecione...</option>
                                <option value="SIM">SIM</option>
                                <option value="NÃO">NÃO</option>
                              </select>
                            </div>

                            {aluno.possuiTranstornos === "SIM" && (
                              <>
                                <div>
                                  <label className="text-[10px] font-bold uppercase text-muted-foreground text-primary">Altas Habilidades / Superdotação</label>
                                  <select
                                    className={`${inputCls} border-primary/30`}
                                    value={aluno.altasHabilidades}
                                    onChange={(ev) => {
                                      const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                      newVinculos[vIdx].alunos[aIdx].altasHabilidades = ev.target.value;
                                      setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                    }}
                                  >
                                    <option value="">Selecione...</option>
                                    <option value="SIM">SIM</option>
                                    <option value="NÃO">NÃO</option>
                                  </select>
                                </div>
                                <div className="sm:col-span-2">
                                  <label className="text-[10px] font-bold uppercase text-muted-foreground text-primary">Observação</label>
                                  <textarea
                                    className={`${inputCls} h-16 border-primary/30 py-2`}
                                    placeholder="Detalhes sobre o transtorno ou altas habilidades..."
                                    value={aluno.observacoesTranstorno}
                                    onChange={(ev) => {
                                      const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                      newVinculos[vIdx].alunos[aIdx].observacoesTranstorno = ev.target.value;
                                      setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                    }}
                                  />
                                </div>
                              </>
                            )}

                            <div>
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">Transt. Comportamental</label>
                              <select
                                className={inputCls}
                                value={aluno.transtornoComportamental}
                                onChange={(ev) => {
                                  const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                  newVinculos[vIdx].alunos[aIdx].transtornoComportamental = ev.target.value;
                                  setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                }}
                              >
                                <option value="">Selecione...</option>
                                <option value="SIM">SIM</option>
                                <option value="NÃO">NÃO</option>
                              </select>
                            </div>
                            <div>
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">Possui Laudo</label>
                              <select
                                className={inputCls}
                                value={aluno.possuiLaudo}
                                onChange={(ev) => {
                                  const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                  newVinculos[vIdx].alunos[aIdx].possuiLaudo = ev.target.value;
                                  setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                }}
                              >
                                <option value="">Selecione...</option>
                                <option value="SIM">SIM</option>
                                <option value="NÃO">NÃO</option>
                                <option value="EM INVESTIGAÇÃO">EM INVESTIGAÇÃO</option>
                              </select>
                            </div>
                            <div>
                              <label className="text-[10px] font-bold uppercase text-muted-foreground">Deficiência</label>
                              <select
                                className={inputCls}
                                value={aluno.deficiencia}
                                onChange={(ev) => {
                                  const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                                  newVinculos[vIdx].alunos[aIdx].deficiencia = ev.target.value;
                                  setDadosPedagogicos(d => ({ ...d, salaAula: { ...d.salaAula, vinculos: newVinculos } }));
                                }}
                              >
                                <option value="">Selecione...</option>
                                <option value="Visual">Visual</option>
                                <option value="Sensorial">Sensorial</option>
                                <option value="Física">Física</option>
                                <option value="Mental">Mental</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      <button
                        type="button"
                        onClick={() => {
                          const newVinculos = [...dadosPedagogicos.salaAula.vinculos];
                          newVinculos[vIdx].alunos.push({
                            nome: "",
                            cid: "",
                            teaNivelSuporte: "",
                            teaAutonomia: "",
                            possuiTranstornos: "",
                            altasHabilidades: "",
                            observacoesTranstorno: "",
                            transtornoComportamental: "",
                            possuiLaudo: "",
                            deficiencia: ""
                          });
                          setDadosPedagogicos(d => ({
                            ...d,
                            salaAula: { ...d.salaAula, vinculos: newVinculos }
                          }));
                        }}
                        className="flex w-full items-center justify-center gap-2 rounded-lg border-2 border-dashed border-border py-3 text-xs font-bold text-muted-foreground hover:border-primary/50 hover:bg-primary/5 hover:text-primary transition-all"
                      >
                        <Plus className="h-4 w-4" />
                        ADICIONAR ESTUDANTE PARA {vinculo.cadNome.split(' ')[0]}
                      </button>
                    </div>
                  </div>
                ))}

                {(dadosPedagogicos.salaAula?.vinculos || []).length === 0 && (
                  <div className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-border py-12 text-center text-muted-foreground">
                    <UserPlus className="mb-2 h-10 w-10 opacity-20" />
                    <p className="text-sm font-medium">Nenhum profissional vinculado a esta sala.</p>
                    <p className="text-xs">Use a busca acima para adicionar um CAD.</p>
                  </div>
                )}
              </div>
            </div>
          </section>
        )}


      {/* Modal de cadastro rápido de CAD */}
      <Dialog open={modalNovoCAD} onOpenChange={(open) => !open && setModalNovoCAD(false)}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-primary" />
              Cadastrar novo CAD
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="col-span-2 space-y-1.5">
              <Label>Nome Completo *</Label>
              <input
                className={inputCls}
                placeholder="NOME DO PROFISSIONAL (maiúsculas)"
                value={novoCADForm.nome}
                onChange={e => setNovoCADForm(f => ({ ...f, nome: e.target.value.toUpperCase() }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Jornada</Label>
              <select
                className={inputCls}
                value={novoCADForm.jornada}
                onChange={e => setNovoCADForm(f => ({ ...f, jornada: Number(e.target.value) }))}
              >
                <option value={30}>30h</option>
                <option value={40}>40h</option>
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Matrícula</Label>
              <input
                className={inputCls}
                placeholder="Nº de matrícula"
                value={novoCADForm.matricula}
                onChange={e => setNovoCADForm(f => ({ ...f, matricula: e.target.value }))}
              />
            </div>
            <div className="col-span-2 space-y-1.5">
              <Label>Cargo</Label>
              <input
                className={inputCls}
                value={novoCADForm.cargo}
                onChange={e => setNovoCADForm(f => ({ ...f, cargo: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Situação</Label>
              <select
                className={inputCls}
                value={novoCADForm.situacao}
                onChange={e => setNovoCADForm(f => ({ ...f, situacao: e.target.value }))}
              >
                <option value="Em Exercício">Em Exercício</option>
                <option value="Contrato Temporário">Contrato Temporário</option>
                <option value="Licença">Licença</option>
                <option value="Afastado">Afastado</option>
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Data de Admissão</Label>
              <input
                type="date"
                className={inputCls}
                value={novoCADForm.data_admissao}
                onChange={e => setNovoCADForm(f => ({ ...f, data_admissao: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalNovoCAD(false)}>Cancelar</Button>
            <Button
              disabled={!novoCADForm.nome || salvandoNovoCAD}
              onClick={async () => {
                if (!novoCADForm.nome) return;
                setSalvandoNovoCAD(true);
                try {
                  const cadSalvo = await salvarCAD({
                    nome: novoCADForm.nome,
                    jornada: novoCADForm.jornada as 30 | 40,
                    cargo: novoCADForm.cargo || null,
                    matricula: novoCADForm.matricula || null,
                    situacao: novoCADForm.situacao || null,
                    data_admissao: novoCADForm.data_admissao || null,
                    unidade_id: unidadeId || null,
                  });
                  // Atualiza lista local
                  setCadsDisponiveis(prev => [...prev, cadSalvo]);
                  // Vincula automaticamente à sala
                  const vinculos = dadosPedagogicos.salaAula?.vinculos || [];
                  if (!vinculos.find((v: any) => v.cadNome === cadSalvo.nome)) {
                    setDadosPedagogicos(d => ({
                      ...d,
                      salaAula: {
                        ...d.salaAula,
                        vinculos: [...vinculos, { cadId: cadSalvo.id, cadNome: cadSalvo.nome, alunos: [] }]
                      }
                    }));
                  }
                  setModalNovoCAD(false);
                  setNovoCADForm({ nome: "", jornada: 30, cargo: "CUIDADOR DE ALUNO COM DEFICIÊNCIA", matricula: "", situacao: "Em Exercício", data_admissao: "" });
                  toast.success("CAD cadastrado e vinculado com sucesso!");
                } catch (e) {
                  toast.error((e as Error).message ?? "Falha ao cadastrar CAD.");
                } finally {
                  setSalvandoNovoCAD(false);
                }
              }}
            >
              {salvandoNovoCAD ? <><Loader2 className="h-4 w-4 animate-spin" /> Salvando...</> : "Cadastrar e Vincular"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

        <div className="mt-8 flex items-center justify-between gap-3 border-t border-border pt-6">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-md px-4 py-2 text-sm font-semibold text-muted-foreground hover:text-foreground"
          >
            Cancelar
          </button>

          <div className="flex gap-2">
            {etapa < 2 ? (
              <button
                type="button"
                onClick={proxima}
                className="rounded-md bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground shadow-sm hover:bg-primary/90"
              >
                Próxima etapa
              </button>
            ) : (
              <>
                <button
                  type="button"
                  disabled={salvando}
                  onClick={() => finalizar("rascunho")}
                  className="rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold hover:bg-muted disabled:opacity-50"
                >
                  Salvar Rascunho
                </button>
                <button
                  type="button"
                  disabled={salvando}
                  onClick={() => finalizar("concluida")}
                  className="rounded-md bg-emerald-600 px-6 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700 disabled:opacity-50"
                >
                  {salvando ? "Salvando..." : "Finalizar Levantamento"}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
