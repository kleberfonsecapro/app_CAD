import type { FluxoMatricula, ResumoFluxo } from "@/lib/matriculaFluxo";
import { COR_TENDENCIA } from "@/lib/matriculaFluxo";

const fmt = (n: number) => n.toLocaleString("pt-BR");
const sinal = (n: number) => (n > 0 ? `+${fmt(n)}` : fmt(n));

function Linha({ f, onSelecionar }: { f: FluxoMatricula; onSelecionar: (u: string) => void }) {
  return (
    <li>
      <button
        onClick={() => onSelecionar(f.unidade)}
        className="flex w-full items-center justify-between gap-3 border-b border-border px-3 py-2 text-left text-xs transition-colors hover:bg-accent"
      >
        <span className="min-w-0 truncate">
          <span
            className="mr-2 inline-block h-2.5 w-2.5 shrink-0 rounded-full align-middle"
            style={{ background: COR_TENDENCIA[f.classe] }}
          />
          {f.unidade}
          <span className="ml-2 text-[10px] uppercase tracking-wide text-muted-foreground">
            {f.segmento}
          </span>
        </span>
        <span className="shrink-0 tabular-nums">
          <span className="text-muted-foreground">{fmt(f.m2020)} → {fmt(f.m2026)}</span>{" "}
          <strong style={{ color: COR_TENDENCIA[f.classe] }}>{sinal(f.variacaoTotal)}</strong>
        </span>
      </button>
    </li>
  );
}

export default function PainelFluxoMatriculas({
  resumo,
  carregando,
  onSelecionar,
}: {
  resumo: ResumoFluxo;
  carregando: boolean;
  onSelecionar: (u: string) => void;
}) {
  if (carregando) {
    return (
      <section className="mt-8 rounded-xl border border-border bg-card p-6 text-sm text-muted-foreground">
        Carregando matrículas 2020–2026 por unidade…
      </section>
    );
  }
  if (!resumo.comDados) return null;

  const delta = resumo.total2026 - resumo.total2020;

  return (
    <section className="mt-8 space-y-4">
      <div className="pmc-secao">
        <h2 className="pmc-titulo text-xl">Fluxo e migração de matrículas (2020 → 2026)</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Cruzamento das matrículas do SIGEEC com as unidades do mapa de calor — apoio à decisão
          sobre construção de novas unidades na periferia ou remanejamento de unidades deficitárias.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        {[
          { l: "Unidades cruzadas", v: fmt(resumo.comDados) },
          { l: "Em crescimento", v: fmt(resumo.crescimento) },
          { l: "Em retração", v: fmt(resumo.retracao) },
          { l: "Matrículas 2026", v: fmt(resumo.total2026) },
          { l: "Δ 2020→2026", v: sinal(delta) },
        ].map((k) => (
          <div key={k.l} className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">{k.l}</p>
            <p className="mt-1 text-2xl font-semibold tabular-nums text-foreground">{k.v}</p>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="mb-2 text-sm font-semibold text-foreground">
          Movimento por região — indício de migração territorial
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border text-left text-muted-foreground">
                <th className="py-2">Região</th>
                <th className="py-2 text-right">Unidades</th>
                <th className="py-2 text-right">2020</th>
                <th className="py-2 text-right">2026</th>
                <th className="py-2 text-right">Δ</th>
                <th className="py-2 text-right">%</th>
              </tr>
            </thead>
            <tbody>
              {resumo.porRegiao.map((r) => (
                <tr key={r.regiao} className="border-b border-border/50">
                  <td className="py-1.5 font-medium text-foreground">{r.regiao}</td>
                  <td className="py-1.5 text-right tabular-nums">{fmt(r.unidades)}</td>
                  <td className="py-1.5 text-right tabular-nums text-muted-foreground">{fmt(r.t2020)}</td>
                  <td className="py-1.5 text-right tabular-nums text-muted-foreground">{fmt(r.t2026)}</td>
                  <td
                    className={`py-1.5 text-right font-semibold tabular-nums ${
                      r.delta > 0 ? "text-emerald-600" : r.delta < 0 ? "text-destructive" : ""
                    }`}
                  >
                    {sinal(r.delta)}
                  </td>
                  <td className="py-1.5 text-right tabular-nums">{r.pct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">
          Regiões com saldo positivo indicam pressão de demanda (avaliar novas unidades ou ampliação);
          saldo negativo indica ociosidade (avaliar remanejamento de turmas e de CADs).
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-border bg-card">
          <div className="border-b border-border p-3 text-sm font-semibold text-foreground">
            Maiores crescimentos — demanda em expansão
          </div>
          <ul>
            {resumo.maioresAltas.map((f) => (
              <Linha key={f.unidade} f={f} onSelecionar={onSelecionar} />
            ))}
          </ul>
        </div>
        <div className="rounded-xl border border-border bg-card">
          <div className="border-b border-border p-3 text-sm font-semibold text-foreground">
            Maiores quedas — unidades deficitárias
          </div>
          <ul>
            {resumo.maioresQuedas.map((f) => (
              <Linha key={f.unidade} f={f} onSelecionar={onSelecionar} />
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
