import { useEffect, useState } from "react";
import {
  COR_PADRAO,
  CONFIG_PADRAO,
  ROTULO_FAIXA,
  type ConfigPadroes,
} from "@/lib/configPadroes";

function Campo({
  label,
  hint,
  value,
  onChange,
  step = 1,
  min = 0,
  max = 100,
}: {
  label: string;
  hint?: string;
  value: number;
  onChange: (n: number) => void;
  step?: number;
  min?: number;
  max?: number;
}) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <input
        type="number"
        value={value}
        step={step}
        min={min}
        max={max}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-ring"
      />
      {hint && <span className="mt-1 block text-[11px] text-muted-foreground">{hint}</span>}
    </label>
  );
}

export default function ConfiguracaoPadroes({
  config,
  onSalvar,
  onRestaurar,
}: {
  config: ConfigPadroes;
  onSalvar: (c: ConfigPadroes) => void;
  onRestaurar: () => void;
}) {
  const [aberto, setAberto] = useState(false);
  const [form, setForm] = useState<ConfigPadroes>(config);

  useEffect(() => setForm(config), [config]);

  const set = <K extends keyof ConfigPadroes>(k: K, v: ConfigPadroes[K]) =>
    setForm((p) => ({ ...p, [k]: v }));

  return (
    <section className="mb-3 rounded-xl border border-border bg-card">
      <button
        onClick={() => setAberto((a) => !a)}
        className="flex w-full items-center justify-between gap-3 px-3 py-3 text-left"
      >
        <span className="text-sm font-semibold text-foreground">
          ⚙️ Configuração de padrões técnicos
        </span>
        <span className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
          <span>Média nacional {config.mediaNacional}:1</span>
          <span className="flex items-center gap-1.5">
            <i
              className="inline-block h-3 w-3 rounded-full"
              style={{ background: COR_PADRAO.vermelho }}
            />
            ≤ {config.limiteVermelho}
          </span>
          <span className="flex items-center gap-1.5">
            <i
              className="inline-block h-3 w-3 rounded-full"
              style={{ background: COR_PADRAO.amarelo }}
            />
            {config.limiteVermelho}–{config.limiteAmarelo}
          </span>
          <span className="flex items-center gap-1.5">
            <i
              className="inline-block h-3 w-3 rounded-full"
              style={{ background: COR_PADRAO.verde }}
            />
            &gt; {config.limiteAmarelo}
          </span>
          <span className="font-semibold text-foreground">{aberto ? "Fechar" : "Editar"}</span>
        </span>
      </button>

      {aberto && (
        <div className="border-t border-border p-3">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Campo
              label="Média nacional (alunos por CAD)"
              hint={`Referência técnica — padrão ${CONFIG_PADRAO.mediaNacional}:1`}
              value={form.mediaNacional}
              onChange={(n) => set("mediaNacional", n)}
              step={0.5}
            />
            <Campo
              label="Limite vermelho (até)"
              hint={ROTULO_FAIXA.vermelho}
              value={form.limiteVermelho}
              onChange={(n) => set("limiteVermelho", n)}
              step={0.5}
            />
            <Campo
              label="Limite amarelo (até)"
              hint={`${ROTULO_FAIXA.amarelo} — acima disso fica verde`}
              value={form.limiteAmarelo}
              onChange={(n) => set("limiteAmarelo", n)}
              step={0.5}
            />
            <Campo
              label="Tamanho mínimo da bola"
              hint="Unidade com menos CADs"
              value={form.raioMin}
              onChange={(n) => set("raioMin", n)}
              min={4}
              max={40}
            />
            <Campo
              label="Tamanho máximo da bola"
              hint="Unidade com mais CADs"
              value={form.raioMax}
              onChange={(n) => set("raioMax", n)}
              min={8}
              max={80}
            />
            <label className="flex items-end gap-2 pb-1 text-sm text-foreground">
              <input
                type="checkbox"
                checked={form.mostrarNumeroCads}
                onChange={(e) => set("mostrarNumeroCads", e.target.checked)}
                className="h-4 w-4 accent-primary"
              />
              Mostrar o número de CADs no centro da bola
            </label>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              onClick={() => onSalvar(form)}
              className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
            >
              Salvar padrões
            </button>
            <button
              onClick={onRestaurar}
              className="rounded-md border border-border px-4 py-2 text-sm font-semibold text-foreground"
            >
              Restaurar padrão ({CONFIG_PADRAO.mediaNacional}:1)
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
