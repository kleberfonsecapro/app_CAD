import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  CLASSIFICACOES_CONSERVACAO,
  ETAPAS,
  FAIXAS_NOTA,
  ITENS_ENTORNO,
  ITENS_ESTRUTURAIS,
  ITENS_FOTOGRAFICOS,
  PADROES_CONSTRUTIVOS,
  SERIES_SALA,
  ajustarSalas,
  calcularNotaMedia,
  corDaNota,
  totalCadsSalas,
  totalAlunosSalas,
  type SalaCadastro,
} from "@/lib/cadastro-schema";
import { fetchUnidades } from "@/lib/matriculas";
import {
  salvarCadastro,
  salvarVistoria,
  type CadastroUnidade,
  type Vistoria,
} from "@/lib/cadastro-api";
import CadastroIndividualCAD from "./CadastroIndividualCAD";


type JsonRecord = Record<string, any>;

type UnidadeMapa = {
  unidade: string;
  regiao: string;
  rua?: string | null;
  numero?: string | null;
  bairro?: string | null;
  cep?: string | null;
  endereco?: string | null;
  lat?: number;
  lon?: number;
  estudantes?: number;
  cuidadores?: number;
};

const normalizar = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .trim();

type Props = {
  unidades: UnidadeMapa[];
  cadastros: CadastroUnidade[];
  vistoriaInicial?: Vistoria | null;
  onSaved: () => void;
  onCancel: () => void;
};

const inputCls =
  "w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary";
const labelCls = "text-xs font-semibold uppercase tracking-wide text-muted-foreground";

export default function VistoriaForm({
  unidades,
  cadastros,
  vistoriaInicial,
  onSaved,
  onCancel,
}: Props) {
  const [etapa, setEtapa] = useState(1);
  const [matriculas2026, setMatriculas2026] = useState<Record<string, number>>({});

  useEffect(() => {
    let ativo = true;
    fetchUnidades()
      .then((lista) => {
        if (!ativo) return;
        const mapa: Record<string, number> = {};
        for (const u of lista) mapa[normalizar(u.unidade)] = u[2026] as number;
        setMatriculas2026(mapa);
      })
      .catch(() => undefined);
    return () => {
      ativo = false;
    };
  }, []);

  const [salvando, setSalvando] = useState(false);

  const [unidadeId, setUnidadeId] = useState(vistoriaInicial?.unidade_id ?? "");
  const unidadeSelecionada = useMemo(
    () => unidades.find((u) => u.unidade === unidadeId),
    [unidades, unidadeId],
  );

  const cadastroExistente = useMemo(
    () => cadastros.find((c) => c.unidade_id === unidadeId),
    [cadastros, unidadeId],
  );

  function montarCadastro(nome: string): CadastroUnidade {
    const base = unidades.find((u) => u.unidade === nome);
    const existente = cadastros.find((c) => c.unidade_id === nome);
    return {
      unidade_id: nome,
      nome,
      regiao: existente?.regiao ?? base?.regiao ?? "",
      inep: existente?.inep ?? "",
      logradouro: existente?.logradouro ?? base?.rua ?? "",
      numero: existente?.numero ?? base?.numero ?? "",
      bairro: existente?.bairro ?? base?.bairro ?? "",
      cep: existente?.cep ?? base?.cep ?? "",
      cidade: existente?.cidade ?? "Cuiabá",
      uf: existente?.uf ?? "MT",
      telefone: existente?.telefone ?? "",
      email: existente?.email ?? "",
      diretor: existente?.diretor ?? "",
      turnos: existente?.turnos ?? "",
      qtd_salas: existente?.qtd_salas ?? null,
      salas: ajustarSalas(
        (existente?.salas as SalaCadastro[] | null) ?? [],
        existente?.qtd_salas ?? null,
      ),
      qtd_alunos: existente?.qtd_alunos ?? base?.estudantes ?? null,
      qtd_alunos_instituicao:
        existente?.qtd_alunos_instituicao ?? matriculas2026[normalizar(nome)] ?? null,
      qtd_cads: existente?.qtd_cads ?? base?.cuidadores ?? null,
      observacoes: existente?.observacoes ?? "",
      atualizado_por: existente?.atualizado_por ?? "",
    };
  }

  const [cadastro, setCadastro] = useState<CadastroUnidade>(() =>
    vistoriaInicial?.unidade_id
      ? montarCadastro(vistoriaInicial.unidade_id)
      : { unidade_id: "", nome: "" },
  );

  // Ao editar, recarrega os dados cadastrais assim que a lista chegar do backend.
  useEffect(() => {
    if (!unidadeId) return;
    setCadastro((atual) => {
      if (atual.unidade_id !== unidadeId || !atual.logradouro) return montarCadastro(unidadeId);
      if (atual.qtd_alunos_instituicao == null) {
        const mat = matriculas2026[normalizar(unidadeId)];
        if (mat != null) return { ...atual, qtd_alunos_instituicao: mat };
      }
      return atual;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cadastros, unidades, unidadeId, matriculas2026]);

  function aplicarUnidade(nome: string) {
    setUnidadeId(nome);
    setCadastro(nome ? montarCadastro(nome) : { unidade_id: "", nome: "" });
  }

  const salas: SalaCadastro[] = useMemo(
    () => ajustarSalas((cadastro.salas as SalaCadastro[]) ?? [], cadastro.qtd_salas ?? null),
    [cadastro.salas, cadastro.qtd_salas],
  );

  function atualizarSala(indice: number, patch: Partial<SalaCadastro>) {
    setCadastro((c) => {
      const lista = ajustarSalas((c.salas as SalaCadastro[]) ?? [], c.qtd_salas ?? null);
      lista[indice] = { ...lista[indice], ...patch };
      return { ...c, salas: lista };
    });
  }




  const [gerais, setGerais] = useState({
    data_vistoria: vistoriaInicial?.data_vistoria ?? new Date().toISOString().slice(0, 10),
    imovel_proprio_alugado: vistoriaInicial?.imovel_proprio_alugado ?? "",
    responsavel: vistoriaInicial?.responsavel ?? "",
    uso_tipo: vistoriaInicial?.uso_tipo ?? "educacional",
  });
  const [estrutural, setEstrutural] = useState<JsonRecord>(vistoriaInicial?.estrutural ?? {});
  const [fotografico, setFotografico] = useState<JsonRecord>(vistoriaInicial?.fotografico ?? {});
  const [entorno, setEntorno] = useState<JsonRecord>(vistoriaInicial?.entorno ?? {});
  const [parecer, setParecer] = useState<JsonRecord>(vistoriaInicial?.parecer ?? {});

  const notaMedia = calcularNotaMedia(estrutural);

  function proxima() {
    if (etapa === 1 && !unidadeId) {
      toast.error("Selecione a unidade educacional.");
      return;
    }
    setEtapa((e) => Math.min(6, e + 1));
  }

  async function finalizar(status: "rascunho" | "concluida") {
    if (!unidadeId) {
      toast.error("Selecione a unidade educacional.");
      return;
    }
    setSalvando(true);
    try {
      await salvarCadastro({ ...cadastro, unidade_id: unidadeId, nome: unidadeId });
      await salvarVistoria({
        id: vistoriaInicial?.id,
        unidade_id: unidadeId,
        unidade_nome: unidadeId,
        data_vistoria: gerais.data_vistoria || null,
        imovel_proprio_alugado: gerais.imovel_proprio_alugado || null,
        responsavel: gerais.responsavel || null,
        uso_tipo: gerais.uso_tipo || null,
        estrutural,
        fotografico,
        entorno,
        parecer,
        etapa,
        status,
      });
      toast.success(
        status === "concluida" ? "Levantamento concluído e cadastro atualizado." : "Rascunho salvo.",
      );
      onSaved();
    } catch (e) {
      toast.error((e as Error).message ?? "Falha ao salvar.");
    } finally {
      setSalvando(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* stepper */}
      <div className="flex flex-wrap gap-2">
        {ETAPAS.map((e) => (
          <button
            key={e.id}
            type="button"
            onClick={() => setEtapa(e.id)}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
              etapa === e.id
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/70"
            }`}
          >
            {e.id}. {e.label}
          </button>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-4 sm:p-6">
        {etapa === 1 && (
          <section className="space-y-4">
            <header>
              <h3 className="text-base font-bold">1. Dados Cadastrais da Unidade</h3>
              <p className="text-xs text-muted-foreground">
                Informação cadastral oficial da unidade educacional — atualizada pela API de cadastro.
              </p>
            </header>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className={labelCls}>Unidade Educacional *</label>
                <select
                  className={inputCls}
                  value={unidadeId}
                  onChange={(ev) => aplicarUnidade(ev.target.value)}
                >
                  <option value="">Selecione a unidade educacional...</option>
                  {unidades.map((u) => (
                    <option key={u.unidade} value={u.unidade}>
                      {u.unidade} · {u.regiao}
                    </option>
                  ))}
                </select>
                {cadastroExistente && (
                  <p className="mt-1 text-[11px] text-primary">
                    Cadastro existente carregado (última atualização em{" "}
                    {new Date(cadastroExistente.updated_at!).toLocaleString("pt-BR")}).
                  </p>
                )}
                {unidadeSelecionada && (
                  <p className="mt-1 rounded-md bg-muted px-3 py-2 text-[11px] text-muted-foreground">
                    <span className="font-semibold text-foreground">Base do mapa de calor:</span>{" "}
                    {[unidadeSelecionada.rua, unidadeSelecionada.numero]
                      .filter(Boolean)
                      .join(", ") || unidadeSelecionada.endereco || "endereço não informado"}
                    {unidadeSelecionada.bairro ? ` · ${unidadeSelecionada.bairro}` : ""}
                    {unidadeSelecionada.cep ? ` · CEP ${unidadeSelecionada.cep}` : ""} · Região{" "}
                    {unidadeSelecionada.regiao}
                    {unidadeSelecionada.lat != null && unidadeSelecionada.lon != null
                      ? ` · ${unidadeSelecionada.lat.toFixed(5)}, ${unidadeSelecionada.lon.toFixed(5)}`
                      : ""}
                  </p>
                )}
              </div>

              {[
                ["inep", "Código INEP"],
                ["regiao", "Região / Polo"],
                ["logradouro", "Logradouro"],
                ["numero", "Número"],
                ["bairro", "Bairro"],
                ["cep", "CEP"],
                ["cidade", "Cidade"],
                ["uf", "UF"],
                ["telefone", "Telefone"],
                ["email", "E-mail institucional"],
                ["diretor", "Diretor(a)"],
                ["turnos", "Turnos de funcionamento"],
                ["atualizado_por", "Atualizado por"],
              ].map(([key, label]) => (
                <div key={key}>
                  <label className={labelCls}>{label}</label>
                  <input
                    className={inputCls}
                    value={(cadastro as any)[key] ?? ""}
                    onChange={(ev) =>
                      setCadastro((c) => ({ ...c, [key]: ev.target.value }))
                    }
                  />
                </div>
              ))}
              <div>
                <label className={labelCls}>Nº de salas</label>
                <input
                  type="number"
                  min={0}
                  max={200}
                  className={inputCls}
                  value={cadastro.qtd_salas ?? ""}
                  onChange={(ev) => {
                    const qtd = ev.target.value === "" ? null : Number(ev.target.value);
                    setCadastro((c) => ({
                      ...c,
                      qtd_salas: qtd,
                      salas: ajustarSalas((c.salas as SalaCadastro[]) ?? [], qtd),
                    }));
                  }}
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Ao informar a quantidade, abrem-se os campos de série e CADs por turno de cada
                  sala.
                </p>
              </div>

              <div>
                <label className={labelCls}>Alunos atendidos pelos CADs</label>
                <input
                  type="number"
                  className={inputCls}
                  value={cadastro.qtd_alunos ?? ""}
                  onChange={(ev) =>
                    setCadastro((c) => ({
                      ...c,
                      qtd_alunos: ev.target.value === "" ? null : Number(ev.target.value),
                    }))
                  }
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Pré-preenchido com o dado do mapa de calor (estudantes do atendimento
                  especializado).
                </p>
              </div>
              <div>
                <label className={labelCls}>Total de alunos da instituição</label>
                <input
                  type="number"
                  className={inputCls}
                  placeholder="Matrícula geral da unidade"
                  value={cadastro.qtd_alunos_instituicao ?? ""}
                  onChange={(ev) =>
                    setCadastro((c) => ({
                      ...c,
                      qtd_alunos_instituicao:
                        ev.target.value === "" ? null : Number(ev.target.value),
                    }))
                  }
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Pré-preenchido com as matrículas de 2026 (Painel de Matrículas · por unidade).
                </p>
              </div>
              <div>
                <label className={labelCls}>Nº de CADs na unidade</label>
                <input
                  type="number"
                  className={inputCls}
                  value={cadastro.qtd_cads ?? ""}
                  onChange={(ev) =>
                    setCadastro((c) => ({
                      ...c,
                      qtd_cads: ev.target.value === "" ? null : Number(ev.target.value),
                    }))
                  }
                />
              </div>

              {salas.length > 0 && (
                <div className="sm:col-span-2 space-y-2 rounded-lg border border-border bg-muted/30 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h4 className="text-sm font-bold">Salas da unidade ({salas.length})</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-semibold text-primary">
                        Total de CADs nas salas: {totalCadsSalas(salas)}
                      </span>
                      <span className="rounded-full bg-secondary/20 px-2 py-0.5 text-[11px] font-semibold text-secondary-foreground">
                        Total de alunos assistidos: {totalAlunosSalas(salas)}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {salas.map((sala, i) => (
                      <div
                        key={i}
                        className="grid gap-2 rounded-md border border-border bg-background p-2 sm:grid-cols-[auto_1fr_repeat(4,110px)] sm:items-end"
                      >
                        <span className="text-xs font-bold text-muted-foreground sm:pb-2">
                          Sala {i + 1}
                        </span>
                        <div>
                          <label className={labelCls}>Série / Etapa</label>
                          <select
                            className={inputCls}
                            value={sala.serie}
                            onChange={(ev) => atualizarSala(i, { serie: ev.target.value })}
                          >
                            <option value="">Selecione...</option>
                            {SERIES_SALA.map((s) => (
                              <option key={s.value} value={s.value}>
                                {s.label}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className={labelCls}>CAD 30Hs</label>
                          <input
                            type="number"
                            min={0}
                            className={inputCls}
                            value={sala.cads_matutino ?? ""}
                            onChange={(ev) =>
                              atualizarSala(i, {
                                cads_matutino:
                                  ev.target.value === "" ? null : Number(ev.target.value),
                              })
                            }
                          />
                        </div>
                        <div>
                          <label className={labelCls}>CAD 40Hs</label>
                          <input
                            type="number"
                            min={0}
                            className={inputCls}
                            value={sala.cads_vespertino ?? ""}
                            onChange={(ev) =>
                              atualizarSala(i, {
                                cads_vespertino:
                                  ev.target.value === "" ? null : Number(ev.target.value),
                              })
                            }
                          />
                        </div>
                        <div>
                          <label className={labelCls}>Alunos CAD Matutino</label>
                          <input
                            type="number"
                            min={0}
                            className={inputCls}
                            value={sala.alunos_matutino ?? ""}
                            onChange={(ev) =>
                              atualizarSala(i, {
                                alunos_matutino:
                                  ev.target.value === "" ? null : Number(ev.target.value),
                              })
                            }
                          />
                        </div>
                        <div>
                          <label className={labelCls}>Alunos CAD Vespertino</label>
                          <input
                            type="number"
                            min={0}
                            className={inputCls}
                            value={sala.alunos_vespertino ?? ""}
                            onChange={(ev) =>
                              atualizarSala(i, {
                                alunos_vespertino:
                                  ev.target.value === "" ? null : Number(ev.target.value),
                              })
                            }
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}


              <div className="sm:col-span-2">
                <label className={labelCls}>Observações cadastrais</label>
                <textarea
                  className={`${inputCls} min-h-[80px]`}
                  value={cadastro.observacoes ?? ""}
                  onChange={(ev) => setCadastro((c) => ({ ...c, observacoes: ev.target.value }))}
                />
              </div>
            </div>
          </section>
        )}

        {etapa === 2 && (
          <section className="space-y-4">
            <header>
              <h3 className="text-base font-bold">2. Dados Gerais da Vistoria</h3>
              <p className="text-xs text-muted-foreground">
                Conforme ABNT NBR 14653-2 e diretrizes do CAU/BR.
              </p>
            </header>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className={labelCls}>Data da Vistoria</label>
                <input
                  type="date"
                  className={inputCls}
                  value={gerais.data_vistoria ?? ""}
                  onChange={(ev) => setGerais((g) => ({ ...g, data_vistoria: ev.target.value }))}
                />
              </div>
              <div>
                <label className={labelCls}>Imóvel Próprio / Alugado</label>
                <select
                  className={inputCls}
                  value={gerais.imovel_proprio_alugado ?? ""}
                  onChange={(ev) =>
                    setGerais((g) => ({ ...g, imovel_proprio_alugado: ev.target.value }))
                  }
                >
                  <option value="">Selecione...</option>
                  <option value="proprio">Próprio</option>
                  <option value="alugado">Alugado</option>
                </select>
              </div>
              <div>
                <label className={labelCls}>Responsável pela unidade</label>
                <input
                  className={inputCls}
                  placeholder="Nome do responsável"
                  value={gerais.responsavel ?? ""}
                  onChange={(ev) => setGerais((g) => ({ ...g, responsavel: ev.target.value }))}
                />
              </div>
              <div>
                <label className={labelCls}>Uso / Tipo</label>
                <select
                  className={inputCls}
                  value={gerais.uso_tipo ?? "educacional"}
                  onChange={(ev) => setGerais((g) => ({ ...g, uso_tipo: ev.target.value }))}
                >
                  {["educacional", "residencial", "comercial", "industrial", "misto"].map((v) => (
                    <option key={v} value={v}>
                      {v[0].toUpperCase() + v.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            {unidadeSelecionada && (
              <p className="rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">
                Endereço de referência: {unidadeSelecionada.rua ?? "—"}
                {unidadeSelecionada.numero ? `, ${unidadeSelecionada.numero}` : ""} ·{" "}
                {unidadeSelecionada.bairro ?? "—"}
              </p>
            )}
          </section>
        )}

        {etapa === 3 && (
          <section className="space-y-4">
            <header>
              <h3 className="text-base font-bold">3. Análise Física e Estrutural</h3>
              <p className="text-xs text-muted-foreground">
                Atribua uma nota de 0 a 10 para cada subsistema.
              </p>
            </header>
            <div className="grid grid-cols-2 gap-2 text-[11px] sm:grid-cols-5">
              {FAIXAS_NOTA.map((f) => (
                <div key={f.range} className="flex items-center gap-1.5">
                  <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${f.color}`} />
                  <span className="text-muted-foreground">
                    {f.range}: {f.label}
                  </span>
                </div>
              ))}
            </div>
            <div className="space-y-4">
              {ITENS_ESTRUTURAIS.map((item) => (
                <div key={item.key} className="space-y-2 rounded-lg border border-border p-3">
                  <p className="text-sm font-semibold">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.tooltip}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {Array.from({ length: 11 }, (_, n) => n).map((n) => {
                      const ativo = estrutural[`${item.key}Nota`] === n;
                      return (
                        <button
                          key={n}
                          type="button"
                          onClick={() =>
                            setEstrutural((s) => ({
                              ...s,
                              [`${item.key}Nota`]: ativo ? null : n,
                            }))
                          }
                          className={`h-9 w-9 rounded border text-xs font-semibold transition-all ${
                            ativo ? corDaNota(n) : "border-border bg-background hover:bg-accent"
                          }`}
                        >
                          {n}
                        </button>
                      );
                    })}
                  </div>
                  <textarea
                    className={`${inputCls} min-h-[56px] text-xs`}
                    placeholder={`Observações sobre ${item.label.toLowerCase()}...`}
                    value={estrutural[`${item.key}Obs`] ?? ""}
                    onChange={(ev) =>
                      setEstrutural((s) => ({ ...s, [`${item.key}Obs`]: ev.target.value }))
                    }
                  />
                </div>
              ))}
            </div>
            <p className="text-sm font-semibold">
              Nota média parcial: <span className="text-primary">{notaMedia ?? "—"}</span>
            </p>
          </section>
        )}

        {etapa === 4 && (
          <section className="space-y-4">
            <header>
              <h3 className="text-base font-bold">4. Checklist de Levantamento Fotográfico</h3>
              <p className="text-xs text-muted-foreground">
                Registre as categorias fotografadas e o número de referência das fotos.
              </p>
            </header>
            {ITENS_FOTOGRAFICOS.map((item) => (
              <div key={item.key} className="flex items-start gap-3 rounded-lg border border-border p-3">
                <input
                  type="checkbox"
                  className="mt-1 h-4 w-4"
                  checked={Boolean(fotografico[`${item.key}Registrado`])}
                  onChange={(ev) =>
                    setFotografico((f) => ({ ...f, [`${item.key}Registrado`]: ev.target.checked }))
                  }
                />
                <div className="flex-1 space-y-2">
                  <p className="text-sm font-semibold">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                  <input
                    className={`${inputCls} text-xs`}
                    placeholder="Nº de referência da foto (ex.: F001, F002)"
                    value={fotografico[`${item.key}FotoRef`] ?? ""}
                    onChange={(ev) =>
                      setFotografico((f) => ({ ...f, [`${item.key}FotoRef`]: ev.target.value }))
                    }
                  />
                </div>
              </div>
            ))}
          </section>
        )}

        {etapa === 5 && (
          <section className="space-y-4">
            <header>
              <h3 className="text-base font-bold">5. Análise do Entorno e Localização Urbana</h3>
              <p className="text-xs text-muted-foreground">
                Avalie cada categoria do entorno e registre observações relevantes.
              </p>
            </header>
            {ITENS_ENTORNO.map((item) => (
              <div key={item.key} className="space-y-2 rounded-lg border border-border p-3">
                <p className="text-sm font-semibold">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
                <select
                  className={`${inputCls} text-xs`}
                  value={entorno[`${item.key}Status`] ?? ""}
                  onChange={(ev) =>
                    setEntorno((e) => ({ ...e, [`${item.key}Status`]: ev.target.value }))
                  }
                >
                  <option value="">Selecione...</option>
                  {item.options.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
                <textarea
                  className={`${inputCls} min-h-[52px] text-xs`}
                  placeholder="Observações..."
                  value={entorno[`${item.key}Obs`] ?? ""}
                  onChange={(ev) =>
                    setEntorno((e) => ({ ...e, [`${item.key}Obs`]: ev.target.value }))
                  }
                />
              </div>
            ))}
          </section>
        )}

        {etapa === 6 && (
          <section className="space-y-4">
            <header>
              <h3 className="text-base font-bold">6. Síntese e Parecer Técnico Preliminar</h3>
              <p className="text-xs text-muted-foreground">
                Classificação final, padrão construtivo e responsável técnico CAU/RRT.
              </p>
            </header>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className={labelCls}>Classificação Final de Conservação</label>
                <select
                  className={inputCls}
                  value={parecer.classificacaoFinalConservacao ?? ""}
                  onChange={(ev) =>
                    setParecer((p) => ({ ...p, classificacaoFinalConservacao: ev.target.value }))
                  }
                >
                  <option value="">Selecione...</option>
                  {CLASSIFICACOES_CONSERVACAO.map((c) => (
                    <option key={c.value} value={c.value}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className={labelCls}>Padrão Construtivo Geral</label>
                <select
                  className={inputCls}
                  value={parecer.padraoConstrutivoGeral ?? ""}
                  onChange={(ev) =>
                    setParecer((p) => ({ ...p, padraoConstrutivoGeral: ev.target.value }))
                  }
                >
                  <option value="">Selecione...</option>
                  {PADROES_CONSTRUTIVOS.map((c) => (
                    <option key={c.value} value={c.value}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className={labelCls}>Observações e Recomendações</label>
                <textarea
                  className={`${inputCls} min-h-[100px]`}
                  placeholder="Observações gerais, recomendações de intervenção e cronograma sugerido..."
                  value={parecer.observacoesRecomendacoes ?? ""}
                  onChange={(ev) =>
                    setParecer((p) => ({ ...p, observacoesRecomendacoes: ev.target.value }))
                  }
                />
              </div>
              {[
                ["arquitetoResponsavel", "Arquiteto / Engenheiro responsável"],
                ["cauNumero", "Nº CAU"],
                ["rrtNumero", "Nº RRT"],
                ["acompanhanteResponsavel", "Acompanhante da vistoria"],
              ].map(([key, label]) => (
                <div key={key}>
                  <label className={labelCls}>{label}</label>
                  <input
                    className={inputCls}
                    value={parecer[key] ?? ""}
                    onChange={(ev) => setParecer((p) => ({ ...p, [key]: ev.target.value }))}
                  />
                </div>
              ))}
            </div>
          </section>
        )}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => (etapa === 1 ? onCancel() : setEtapa((e) => e - 1))}
          className="rounded-md border border-border px-4 py-2 text-sm font-semibold hover:bg-accent"
        >
          {etapa === 1 ? "Cancelar" : "Anterior"}
        </button>
        <div className="flex gap-2">
          <button
            type="button"
            disabled={salvando}
            onClick={() => finalizar("rascunho")}
            className="rounded-md border border-border px-4 py-2 text-sm font-semibold hover:bg-accent disabled:opacity-50"
          >
            Salvar rascunho
          </button>
          {etapa < 6 ? (
            <button
              type="button"
              onClick={proxima}
              className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
            >
              Próximo
            </button>
          ) : (
            <button
              type="button"
              disabled={salvando}
              onClick={() => finalizar("concluida")}
              className="rounded-md bg-emerald-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
            >
              Concluir e atualizar cadastro
            </button>
          )}
        </div>
      </div>
      
      {etapa === 1 && unidadeId && (
        <div className="mt-8 pt-8 border-t border-border">
          <CadastroIndividualCAD unidadeId={unidadeId} />
        </div>
      )}
    </div>
  );
}

