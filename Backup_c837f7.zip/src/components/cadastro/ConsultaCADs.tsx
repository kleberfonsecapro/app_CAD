import { Fragment, useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  atualizarDadosLevantamentoPedagogico,
  buscarCADsPorNome,
  excluirCAD,
  listarCADs,
  listarLevantamentosPedagogicos,
  salvarCAD,
  type CAD,
  type LevantamentoPedagogico,
} from "@/lib/cadastro-api";
import {
  buscarVinculosDoCAD,
  construirIndiceVinculos,
  contarAlunosDosVinculos,
  type AlunoVinculado,
  type VinculoAluno,
} from "@/lib/cad-vinculos";

const CAMPOS_ALUNO: { key: string; label: string; opcoes?: string[] }[] = [
  { key: "ano", label: "Ano/Série", opcoes: ["G0", "G1", "G2", "G3", "G4", "G5", "1º Ano", "2º Ano", "3º Ano", "4º Ano", "5º Ano"] },
  { key: "turma", label: "Turma", opcoes: "ABCDEFGHIJK".split("") },
  { key: "periodo", label: "Período", opcoes: ["Matutino", "Vespertino", "Integral", "Transporte"] },
  { key: "cid", label: "CID" },
  { key: "teaNivelSuporte", label: "Nível de suporte TEA", opcoes: ["1", "2", "3", "Não informado"] },
  { key: "teaAutonomia", label: "Autonomia (TEA)" },
  { key: "possuiLaudo", label: "Possui laudo", opcoes: ["Sim", "Não", "Em andamento"] },
  { key: "deficiencia", label: "Deficiência", opcoes: ["Visual", "Sensorial", "Física", "Mental"] },
];
import {
  ChevronDown,
  ChevronRight,
  GraduationCap,
  Hash,
  Loader2,
  Pencil,
  School,
  Search,
  Trash2,
  User,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const CAMPOS_EDICAO: { campo: keyof CAD; rotulo: string; largo?: boolean }[] = [
  { campo: "nome", rotulo: "Nome", largo: true },
  { campo: "matricula", rotulo: "Matrícula" },
  { campo: "jornada", rotulo: "Jornada (h)" },
  { campo: "unidade_id", rotulo: "Unidade", largo: true },
  { campo: "cargo", rotulo: "Cargo" },
  { campo: "status", rotulo: "Status" },
  { campo: "situacao_funcional", rotulo: "Situação funcional" },
  { campo: "sexo", rotulo: "Sexo" },
  { campo: "telefone", rotulo: "Telefone" },
  { campo: "email", rotulo: "E-mail" },
  { campo: "observacoes", rotulo: "Observações", largo: true },
];

/** Separa só os campos da tabela de CADs (remove dados calculados da consulta). */
const extrairCAD = (r: CAD): CAD => {
  const campos: (keyof CAD)[] = [
    "id", "unidade_id", "nome", "sexo", "matricula", "jornada", "cargo", "cod_cargo",
    "situacao", "situacao_funcional", "status", "data_admissao", "vencimento", "cpf",
    "telefone", "email", "observacoes",
  ];
  const out: Record<string, unknown> = {};
  for (const k of campos) if (r[k] !== undefined) out[k] = r[k];
  return out as CAD;
};


/** Normaliza o texto para comparar sem acento, sem caixa e sem espaços duplicados. */
const normalizar = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/\s+/g, " ")
    .trim();

/** Versão "colada" (só letras e números) — casa "Sant'Ana" com "santana". */
const compacto = (s: string) => normalizar(s).replace(/[^A-Z0-9]/g, "");

/**
 * Confere se o registro corresponde ao termo digitado.
 * Aceita nome, matrícula e unidade, ignorando acento, caixa e pontuação,
 * e também casa as palavras do termo em qualquer ordem (ex.: "farias josiane").
 */
const combinaComTermo = (cad: CAD, termo: string) => {
  const termoLimpo = normalizar(termo);
  const termoCompacto = compacto(termo);
  const palavras = termoLimpo.split(" ").filter(Boolean);

  return [cad?.nome, cad?.matricula, cad?.unidade_id].some((valor) => {
    if (typeof valor !== "string" || !valor) return false;
    const alvo = normalizar(valor);
    const alvoCompacto = compacto(valor);
    return (
      (termoLimpo.length >= 2 && alvo.includes(termoLimpo)) ||
      (termoCompacto.length >= 3 && alvoCompacto.includes(termoCompacto)) ||
      (palavras.length > 1 && palavras.every((p) => p.length >= 2 && alvo.includes(p)))
    );
  });
};

/** Chave única de um registro — evita duplicidade ao juntar busca local + banco. */
const chaveRegistro = (cad: CAD) =>
  cad?.id ?? `${normalizar(cad?.nome ?? "")}|${cad?.matricula ?? ""}|${cad?.created_at ?? ""}`;

/** Formata o horário do cadastro em hora:minuto:segundo (hh:mm:ss). */
export const formatarHoraMinutoSegundo = (valor?: string | null) => {
  if (!valor) return "—";
  const d = new Date(valor);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
};

/** Data (dd/mm/aaaa) do cadastro — complementa o horário exato. */
const formatarData = (valor?: string | null) => {
  if (!valor) return "—";
  const d = new Date(valor);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("pt-BR");
};

type ResponsavelTecnico = {
  nome: string;
  escola: string;
  anoSerie: string;
  turma: string;
  periodo: string;
  data: string;
};

type RegistroConsulta = CAD & {
  ocorrencia: number;
  vinculos: VinculoAluno[];
  totalAlunos: number;
  responsaveis: ResponsavelTecnico[];
};
type ContagemNome = { nome: string; total: number };

const texto = (valor: unknown) => (typeof valor === "string" ? valor.trim() : "");

/**
 * Índice "profissional CAD → responsáveis técnicos".
 * O responsável técnico vem do levantamento pedagógico (campo `responsavel`),
 * junto da escola (unidade), ano/série, turma e período em que o CAD foi vinculado.
 */
function montarResponsaveisPorCAD(levantamentos: LevantamentoPedagogico[]) {
  const mapa = new Map<string, ResponsavelTecnico[]>();

  for (const lev of levantamentos) {
    const sala = ((lev?.dados_pedagogicos ?? {}) as any)?.salaAula ?? {};
    const vinculos = Array.isArray(sala?.vinculos) ? sala.vinculos : [];
    const escola = texto(lev?.unidade_nome) || texto(lev?.unidade_id) || "Escola não informada";
    const responsavel = texto(lev?.responsavel) || "Não informado";
    const data = formatarData(lev?.data_levantamento ?? lev?.updated_at);

    for (const vinculo of vinculos) {
      const nome = texto(vinculo?.cadNome ?? vinculo?.nome);
      if (!nome) continue;

      const chave = normalizar(nome);
      const lista = mapa.get(chave) ?? [];
      const registro: ResponsavelTecnico = {
        nome: responsavel,
        escola,
        anoSerie: texto(sala?.ano),
        turma: texto(sala?.turma),
        periodo: texto(sala?.periodo),
        data,
      };
      const repetido = lista.some(
        (r) =>
          normalizar(r.nome) === normalizar(registro.nome) &&
          normalizar(r.escola) === normalizar(registro.escola) &&
          normalizar(r.anoSerie) === normalizar(registro.anoSerie) &&
          normalizar(r.turma) === normalizar(registro.turma) &&
          normalizar(r.periodo) === normalizar(registro.periodo),
      );
      if (!repetido) lista.push(registro);
      mapa.set(chave, lista);
    }
  }

  return mapa;
}

/** Remove responsáveis técnicos repetidos, mantendo a ordem de exibição. */
const responsaveisUnicos = (lista: ResponsavelTecnico[]) => {
  const vistos = new Set<string>();
  return lista.filter((r) => {
    const chave = `${normalizar(r.nome)}|${normalizar(r.escola)}|${normalizar(r.anoSerie)}|${normalizar(r.turma)}|${normalizar(r.periodo)}`;
    if (vistos.has(chave)) return false;
    vistos.add(chave);
    return true;
  });
};

/** Responsáveis técnicos que assinam o levantamento de um vínculo específico. */
const responsaveisDoVinculo = (registro: RegistroConsulta, vinculo: VinculoAluno) => {
  const casados = registro.responsaveis.filter(
    (r) =>
      normalizar(r.escola) === normalizar(vinculo.escola || "") &&
      normalizar(r.anoSerie) === normalizar(vinculo.anoSerie || "") &&
      normalizar(r.turma) === normalizar(vinculo.turma || "") &&
      normalizar(r.periodo) === normalizar(vinculo.periodo || ""),
  );
  return responsaveisUnicos(casados.length ? casados : registro.responsaveis);
};

/** Nomes únicos de responsáveis técnicos (para os chips da linha). */
const nomesResponsaveis = (lista: ResponsavelTecnico[]) => {
  const nomes = new Map<string, string>();
  for (const r of lista) {
    const chave = normalizar(r.nome);
    if (!nomes.has(chave)) nomes.set(chave, r.nome);
  }
  return [...nomes.entries()].map(([chave, nome]) => ({ chave, nome }));
};

export default function ConsultaCADs() {
  const [busca, setBusca] = useState("");
  const [termoDebounced, setTermoDebounced] = useState("");
  const [expandidos, setExpandidos] = useState<Record<string, boolean>>({});

  // Aguarda o usuário parar de digitar antes de consultar (mantém a busca fluida).
  useEffect(() => {
    const timer = setTimeout(() => setTermoDebounced(busca), 300);
    return () => clearTimeout(timer);
  }, [busca]);

  const {
    data: cads = [],
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["consulta-cads"],
    queryFn: async () => {
      const lista = await listarCADs();
      return Array.isArray(lista) ? lista : [];
    },
    staleTime: 60000,
    retry: 1,
  });

  // Levantamentos pedagógicos: é onde ficam os alunos vinculados a cada CAD,
  // com escola, ano/série, turma e período.
  const { data: levantamentos = [], isLoading: carregandoVinculos } = useQuery({
    queryKey: ["consulta-cads-vinculos"],
    queryFn: async () => {
      const lista = await listarLevantamentosPedagogicos();
      return Array.isArray(lista) ? lista : [];
    },
    staleTime: 60000,
    retry: 1,
  });

  const indiceVinculos = useMemo(() => construirIndiceVinculos(levantamentos), [levantamentos]);

  // Responsáveis técnicos por profissional CAD — lidos dos levantamentos pedagógicos.
  const responsaveisPorCAD = useMemo(
    () => montarResponsaveisPorCAD(levantamentos),
    [levantamentos],
  );

  const termo = normalizar(busca);

  // 1) Busca instantânea na base já carregada no navegador.
  const encontradosLocal = useMemo(() => {
    if (termo.length < 2) return [] as CAD[];
    return cads.filter((c) => combinaComTermo(c, termo));
  }, [cads, termo]);

  // 2) Rede de segurança: consulta o banco pelo nome quando a base local não
  //    retorna nada (base ainda carregando, cache antigo ou nome "colado").
  const { data: encontradosServidor = [], isFetching: buscandoNoServidor } = useQuery({
    queryKey: ["consulta-cads-busca-servidor", termoDebounced],
    queryFn: () => buscarCADsPorNome(termoDebounced),
    enabled:
      termoDebounced.trim().length >= 3 &&
      !isLoading &&
      (isError || encontradosLocal.length === 0),
    staleTime: 60000,
    retry: 1,
  });

  // Junta as duas fontes sem repetir registros.
  const encontrados = useMemo(() => {
    if (termo.length < 2) return [] as CAD[];
    const chaves = new Set(encontradosLocal.map(chaveRegistro));
    const extras = encontradosServidor.filter(
      (c) => combinaComTermo(c, termo) && !chaves.has(chaveRegistro(c)),
    );
    return [...encontradosLocal, ...extras];
  }, [encontradosLocal, encontradosServidor, termo]);

  const { registros, contagemPorNome } = useMemo(() => {
    if (termo.length < 2) {
      return { registros: [] as RegistroConsulta[], contagemPorNome: [] as ContagemNome[] };
    }

    const encontradosOrdenados = [...encontrados].sort((a, b) => {
      const porNome = (a.nome ?? "").localeCompare(b.nome ?? "", "pt-BR");
      if (porNome !== 0) return porNome;
      return (a.created_at ?? "").localeCompare(b.created_at ?? "");
    });

    const contagem = new Map<string, ContagemNome>();
    const registros: RegistroConsulta[] = encontradosOrdenados.map((c) => {
      const chave = normalizar(c.nome ?? "");
      const total = (contagem.get(chave)?.total ?? 0) + 1;
      contagem.set(chave, { nome: c.nome, total });

      // Alunos vinculados (escola, ano/série, turma, período)
      const vinculos = buscarVinculosDoCAD(c, indiceVinculos);

      return {
        ...c,
        ocorrencia: total,
        vinculos,
        totalAlunos: contarAlunosDosVinculos(vinculos),
        responsaveis: responsaveisPorCAD.get(normalizar(c.nome ?? "")) ?? [],
      };
    });

    const contagemPorNome = [...contagem.values()].sort(
      (a, b) => b.total - a.total || a.nome.localeCompare(b.nome, "pt-BR"),
    );

    return { registros, contagemPorNome };
  }, [encontrados, termo, indiceVinculos, responsaveisPorCAD]);

  const totalAlunosVinculados = registros.reduce((soma, r) => soma + r.totalAlunos, 0);
  const totalResponsaveis = nomesResponsaveis(registros.flatMap((r) => r.responsaveis)).length;

  const toggleExpandido = (chave: string) =>
    setExpandidos((prev) => ({ ...prev, [chave]: !prev[chave] }));

  const queryClient = useQueryClient();
  const [editando, setEditando] = useState<CAD | null>(null);
  const [excluindo, setExcluindo] = useState<CAD | null>(null);
  const [salvando, setSalvando] = useState(false);

  const atualizarListas = () => {
    queryClient.invalidateQueries({ queryKey: ["consulta-cads"] });
    queryClient.invalidateQueries({ queryKey: ["consulta-cads-busca-servidor"] });
    queryClient.invalidateQueries({ queryKey: ["cads"] });
  };

  const [editAluno, setEditAluno] = useState<{
    v: VinculoAluno;
    a: AlunoVinculado;
    f: Record<string, string>;
  } | null>(null);
  const [salvandoAluno, setSalvandoAluno] = useState(false);

  const abrirEdicaoAluno = (v: VinculoAluno, a: AlunoVinculado) =>
    setEditAluno({
      v,
      a,
      f: {
        ano: v.anoSerie ?? "",
        turma: v.turma ?? "",
        periodo: v.periodo ?? "",
        cid: a.cid ?? "",
        teaNivelSuporte: a.teaNivelSuporte ?? "",
        possuiLaudo: a.possuiLaudo ?? "",
        deficiencia: a.deficiencia ?? "",
        teaAutonomia: a.teaAutonomia ?? "",
      },
    });

  const salvarAluno = async () => {
    if (!editAluno) return;
    const { v, a, f } = editAluno;
    const lev = levantamentos.find((l: any) => l.id === v.levantamentoId);
    if (!lev) return toast.error("Levantamento não encontrado.");
    setSalvandoAluno(true);
    try {
      const dados = JSON.parse(JSON.stringify(lev.dados_pedagogicos ?? {}));
      const chave = dados.salaAula ? "salaAula" : dados.sala_aula ? "sala_aula" : "salaAula";
      const sala = (dados[chave] ??= {});
      sala.ano = f.ano;
      sala.turma = f.turma;
      sala.periodo = f.periodo;
      const aluno = sala.vinculos?.[v.vinculoIdx!]?.alunos?.[a.idx!];
      if (!aluno) throw new Error("Aluno não encontrado no levantamento.");
      for (const k of ["cid", "teaNivelSuporte", "possuiLaudo", "deficiencia", "teaAutonomia"])
        aluno[k] = f[k];
      await atualizarDadosLevantamentoPedagogico(lev.id as string, dados);
      toast.success("Dados do aluno atualizados.");
      setEditAluno(null);
      queryClient.invalidateQueries({ queryKey: ["consulta-cads-vinculos"] });
    } catch (e) {
      toast.error(`Não foi possível salvar: ${(e as Error).message}`);
    } finally {
      setSalvandoAluno(false);
    }
  };

  const [excluirAluno, setExcluirAluno] = useState<{ v: VinculoAluno; a: AlunoVinculado } | null>(null);
  const confirmarExclusaoAluno = async () => {
    if (!excluirAluno) return;
    const { v, a } = excluirAluno;
    const lev = levantamentos.find((l: any) => l.id === v.levantamentoId);
    if (!lev) return toast.error("Levantamento não encontrado.");
    try {
      const dados = JSON.parse(JSON.stringify(lev.dados_pedagogicos ?? {}));
      const chave = dados.salaAula ? "salaAula" : "sala_aula";
      const alunos = dados[chave]?.vinculos?.[v.vinculoIdx!]?.alunos;
      if (!Array.isArray(alunos) || !alunos[a.idx!]) throw new Error("Aluno não encontrado.");
      alunos.splice(a.idx!, 1);
      await atualizarDadosLevantamentoPedagogico(lev.id as string, dados);
      toast.success("Aluno removido do CAD.");
      queryClient.invalidateQueries({ queryKey: ["consulta-cads-vinculos"] });
    } catch (e) {
      toast.error(`Não foi possível excluir: ${(e as Error).message}`);
    } finally {
      setExcluirAluno(null);
    }
  };

  const salvarEdicao = async () => {
    if (!editando) return;
    setSalvando(true);
    try {
      await salvarCAD({ ...editando, updated_at: new Date().toISOString() });
      toast.success("Cadastro alterado com sucesso.");
      setEditando(null);
      atualizarListas();
    } catch (e) {
      toast.error(`Não foi possível salvar: ${(e as Error).message}`);
    } finally {
      setSalvando(false);
    }
  };

  const confirmarExclusao = async () => {
    if (!excluindo?.id) return;
    try {
      await excluirCAD(excluindo.id);
      toast.success("Cadastro excluído.");
      atualizarListas();
    } catch (e) {
      toast.error(`Não foi possível excluir: ${(e as Error).message}`);
    } finally {
      setExcluindo(null);
    }
  };

  return (
    <section className="rounded-xl border border-border bg-card">
      <div className="border-b border-border p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="flex items-center gap-2 text-base font-bold text-foreground sm:text-lg">
              <Search className="h-4 w-4 text-primary" />
              Consulta de CAD por nome
            </h2>
            <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
              Busque pelo nome do profissional para listar todos os cadastros encontrados na base,
              com matrícula, unidade, status, a hora exata do cadastro (hh:mm:ss) e o responsável
              técnico pelo levantamento. Abra um registro para ver os alunos vinculados, com a
              escola, o ano/série, a turma, o período e o responsável técnico.
            </p>
          </div>
          <span className="flex items-center gap-1.5 rounded-full border border-border bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">
            <Users className="h-3.5 w-3.5" />
            {isLoading ? "Carregando base…" : `${cads.length} profissionais na base`}
          </span>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Ex.: Josiane Santana Farias"
              className="w-full rounded-md border border-input bg-background py-2 pl-9 pr-9 text-sm text-foreground outline-none transition-all duration-200 placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/25"
            />
            {busca && (
              <button
                type="button"
                onClick={() => setBusca("")}
                aria-label="Limpar busca"
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground transition-colors hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {termo.length >= 2 && !isLoading && (
            <span className="rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
              {registros.length} {registros.length === 1 ? "registro" : "registros"} ·{" "}
              {contagemPorNome.length} {contagemPorNome.length === 1 ? "nome" : "nomes"} ·{" "}
              {totalAlunosVinculados} {totalAlunosVinculados === 1 ? "aluno" : "alunos"} ·{" "}
              {totalResponsaveis} {totalResponsaveis === 1 ? "resp. técnico" : "resp. técnicos"}
            </span>
          )}
        </div>
      </div>

      <div className="p-4">
        {isLoading && (
          <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Carregando registros do cadastro…
          </div>
        )}

        {!isLoading && isError && (
          <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
            Não foi possível carregar toda a base de CADs agora. Digite o nome do profissional
            para consultar direto no banco de dados.
          </p>
        )}

        {!isLoading && !isError && termo.length < 2 && (
          <div className="flex h-24 items-center justify-center rounded-lg border-2 border-dashed border-border text-sm text-muted-foreground">
            Digite ao menos 2 letras do nome para consultar.
          </div>
        )}

        {!isLoading && termo.length >= 2 && registros.length === 0 && (
          <div className="py-6">
            {buscandoNoServidor ? (
              <p className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Consultando o cadastro pelo nome…
              </p>
            ) : (
              <p className="text-center text-sm text-muted-foreground">
                Nenhum profissional encontrado para <strong>&ldquo;{busca}&rdquo;</strong>. Confira
                a grafia do nome ou tente apenas parte dele (ex.: o primeiro nome ou o sobrenome).
              </p>
            )}
          </div>
        )}

        {!isLoading && registros.length > 0 && (
          <div className="space-y-4">
            <div className="rounded-lg border border-border bg-muted/30 p-3">
              <p className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                <Hash className="h-3.5 w-3.5" />
                Quantas vezes cada nome aparece
              </p>
              <div className="flex flex-wrap gap-2">
                {contagemPorNome.map((c) => (
                  <span
                    key={c.nome}
                    className={`flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-semibold ${
                      c.total > 1
                        ? "border-destructive/30 bg-destructive/10 text-destructive"
                        : "border-border bg-background text-muted-foreground"
                    }`}
                  >
                    {c.nome}
                    <span className="rounded-full bg-card px-1.5 py-0.5 tabular-nums">
                      {c.total}×
                    </span>
                  </span>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto rounded-lg border border-border">
              <table className="w-full min-w-[1020px] text-sm">
                <thead className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2">Ocorrência</th>
                    <th className="px-3 py-2">Nome</th>
                    <th className="px-3 py-2">Matrícula</th>
                    <th className="px-3 py-2">Unidade</th>
                    <th className="px-3 py-2">Alunos vinculados</th>
                    <th className="px-3 py-2">Responsável técnico</th>
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2">Data do cadastro</th>
                    <th className="px-3 py-2">Hora do cadastro (hh:mm:ss)</th>
                    <th className="px-3 py-2">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {registros.map((r) => {
                    const chaveLinha = `${chaveRegistro(r)}-${r.ocorrencia}`;
                    const expandido = !!expandidos[chaveLinha];
                    const total =
                      contagemPorNome.find((c) => normalizar(c.nome) === normalizar(r.nome ?? ""))
                        ?.total ?? 1;
                    const repetido = total > 1;
                    const status = r.status ?? r.situacao ?? "—";
                    const ativo =
                      status === "Em Exercício" || status === "ATIVO" || status === "Ativo";

                    return (
                      <Fragment key={chaveLinha}>
                        <tr
                          className={`border-t border-border transition-colors hover:bg-accent/50 ${
                            repetido ? "bg-destructive/5" : ""
                          }`}
                        >
                        <td className="px-3 py-2">
                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] font-bold tabular-nums ${
                              repetido
                                ? "bg-destructive/10 text-destructive"
                                : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {r.ocorrencia}/{total}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-medium text-foreground">{r.nome}</td>
                        <td className="px-3 py-2 tabular-nums">{r.matricula || "—"}</td>
                        <td className="px-3 py-2 text-xs">{r.unidade_id || "—"}</td>
                        <td className="px-3 py-2">
                          {r.totalAlunos > 0 ? (
                            <button
                              type="button"
                              onClick={() => toggleExpandido(chaveLinha)}
                              title="Ver alunos vinculados"
                              className="flex items-center gap-1.5 rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[11px] font-semibold text-primary transition-all duration-200 hover:scale-[1.02] hover:bg-primary/20"
                            >
                              {expandido ? (
                                <ChevronDown className="h-3 w-3" />
                              ) : (
                                <ChevronRight className="h-3 w-3" />
                              )}
                              {r.totalAlunos} {r.totalAlunos === 1 ? "aluno" : "alunos"}
                            </button>
                          ) : (
                            <span className="text-[11px] italic text-muted-foreground">
                              {carregandoVinculos ? "Carregando…" : "Sem vínculo"}
                            </span>
                          )}
                        </td>
                        <td className="px-3 py-2">
                          {r.responsaveis.length === 0 ? (
                            <span className="text-[11px] italic text-muted-foreground">
                              {carregandoVinculos ? "Carregando…" : "Não informado"}
                            </span>
                          ) : (
                            <div className="flex flex-wrap gap-1">
                              {nomesResponsaveis(r.responsaveis).map((rt) => (
                                <span
                                  key={`${chaveLinha}-rt-${rt.chave}`}
                                  className="flex items-center gap-1 rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[11px] font-semibold text-primary"
                                >
                                  <User className="h-3 w-3" />
                                  {rt.nome}
                                </span>
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-2">
                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                              ativo
                                ? "bg-emerald-100 text-emerald-700"
                                : "bg-amber-100 text-amber-700"
                            }`}
                          >
                            {status}
                          </span>
                        </td>
                        <td className="px-3 py-2 tabular-nums text-xs text-muted-foreground">
                          {formatarData(r.created_at)}
                        </td>
                        <td className="px-3 py-2 font-semibold tabular-nums text-foreground">
                          {formatarHoraMinutoSegundo(r.created_at)}
                        </td>
                        <td className="px-3 py-2">
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              title="Alterar"
                              disabled={!r.id}
                              onClick={() => setEditando(extrairCAD(r))}
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              title="Excluir"
                              disabled={!r.id}
                              className="text-destructive hover:bg-destructive/10"
                              onClick={() => setExcluindo(extrairCAD(r))}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </td>
                        </tr>

                        {expandido && (
                          <tr className="border-t border-border bg-muted/20">
                            <td colSpan={10} className="px-3 py-3">
                              {r.vinculos.length === 0 ? (
                                <p className="text-xs text-muted-foreground">
                                  Nenhum aluno vinculado a <strong>{r.nome}</strong> nos
                                  levantamentos pedagógicos. Vincule o profissional à sala de aula no
                                  Levantamento Pedagógico para que os alunos apareçam aqui.
                                </p>
                              ) : (
                                <div className="space-y-3">
                                  {r.vinculos.map((v, i) => (
                                    <div
                                      key={`${chaveLinha}-v-${i}`}
                                      className="rounded-lg border border-border bg-card p-3"
                                    >
                                      <div className="flex flex-wrap items-center gap-2 text-[11px]">
                                        <span className="flex items-center gap-1 font-semibold text-foreground">
                                          <School className="h-3.5 w-3.5 text-primary" />
                                          {v.escola || "Escola não informada"}
                                        </span>
                                        <span className="rounded-full border border-border bg-muted px-2 py-0.5 text-muted-foreground">
                                          Ano/Série: {v.anoSerie || "—"}
                                        </span>
                                        <span className="rounded-full border border-border bg-muted px-2 py-0.5 text-muted-foreground">
                                          Turma: {v.turma || "—"}
                                        </span>
                                        <span className="rounded-full border border-border bg-muted px-2 py-0.5 text-muted-foreground">
                                          Período: {v.periodo || "—"}
                                        </span>
                                        {responsaveisDoVinculo(r, v).length > 0 ? (
                                          responsaveisDoVinculo(r, v).map((rt, ri) => (
                                            <span
                                              key={`${chaveLinha}-resp-${ri}-${normalizar(rt.nome)}`}
                                              className="flex items-center gap-1 rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 font-semibold text-primary"
                                              title={`Responsável técnico do levantamento · ${rt.escola}${rt.data !== "—" ? ` · ${rt.data}` : ""}`}
                                            >
                                              <User className="h-3 w-3" />
                                              Resp. técnico: {rt.nome}
                                            </span>
                                          ))
                                        ) : (
                                          <span className="text-muted-foreground">
                                            Resp. técnico: não informado
                                          </span>
                                        )}
                                        {v.dataLevantamento && (
                                          <span className="text-muted-foreground">
                                            Levantamento: {v.dataLevantamento}
                                          </span>
                                        )}
                                      </div>

                                      <ul className="mt-2 space-y-1">
                                        {v.alunos.map((a, ai) => (
                                          <li
                                            key={`${chaveLinha}-a-${i}-${ai}`}
                                            className="flex flex-wrap items-center gap-2 rounded-md bg-muted/40 px-2 py-1 text-xs"
                                          >
                                            <GraduationCap className="h-3.5 w-3.5 text-secondary" />
                                            <span className="font-medium text-foreground">
                                              {a.nome || "Aluno sem nome informado"}
                                            </span>
                                            {a.cid && (
                                              <span className="rounded-full bg-secondary/10 px-2 py-0.5 text-[10px] font-semibold text-secondary">
                                                CID {a.cid}
                                              </span>
                                            )}
                                            {a.deficiencia && (
                                              <span className="text-[10px] text-muted-foreground">
                                                Deficiência: {a.deficiencia}
                                              </span>
                                            )}
                                            {a.teaNivelSuporte && (
                                              <span className="text-[10px] text-muted-foreground">
                                                Suporte TEA: {a.teaNivelSuporte}
                                              </span>
                                            )}
                                            {a.possuiLaudo && (
                                              <span className="text-[10px] text-muted-foreground">
                                                Laudo: {a.possuiLaudo}
                                              </span>
                                            )}
                                            {a.teaAutonomia && (
                                              <span className="text-[10px] text-muted-foreground">
                                                Autonomia: {a.teaAutonomia}
                                              </span>
                                            )}
                                            {v.levantamentoId && v.vinculoIdx != null && a.idx != null && (
                                              <>
                                                <Button
                                                  size="sm"
                                                  variant="outline"
                                                  className="ml-auto h-6 px-2 text-[10px]"
                                                  onClick={() => abrirEdicaoAluno(v, a)}
                                                >
                                                  <Pencil className="mr-1 h-3 w-3" /> Editar
                                                </Button>
                                                <Button
                                                  size="sm"
                                                  variant="outline"
                                                  className="h-6 px-2 text-[10px] text-destructive"
                                                  onClick={() => setExcluirAluno({ v, a })}
                                                >
                                                  <Trash2 className="mr-1 h-3 w-3" /> Excluir
                                                </Button>
                                              </>
                                            )}
                                          </li>
                                        ))}
                                        {v.alunos.length === 0 && (
                                          <li className="text-[11px] italic text-muted-foreground">
                                            Nenhum aluno registrado para este vínculo.
                                          </li>
                                        )}
                                      </ul>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <p className="text-[10px] italic text-muted-foreground">
              * Registros repetidos do mesmo nome ficam destacados — use o painel de contagem acima
              para conferir quantas vezes cada profissional aparece na base.
            </p>
          </div>
        )}
      </div>

      <Dialog open={!!editAluno} onOpenChange={(o) => !o && setEditAluno(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Alterar dados do aluno</DialogTitle>
          </DialogHeader>
          {editAluno && (
            <div className="grid grid-cols-2 gap-3">
              {CAMPOS_ALUNO.map((c) => (
                <label key={c.key} className="space-y-1 text-xs font-medium">
                  {c.label}
                  {c.opcoes ? (
                    <select
                      value={editAluno.f[c.key] ?? ""}
                      onChange={(e) =>
                        setEditAluno({ ...editAluno, f: { ...editAluno.f, [c.key]: e.target.value } })
                      }
                      className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                    >
                      <option value="">—</option>
                      {c.opcoes.map((o) => (
                        <option key={o} value={o}>{o}</option>
                      ))}
                    </select>
                  ) : (
                    <Input
                      value={editAluno.f[c.key] ?? ""}
                      onChange={(e) =>
                        setEditAluno({ ...editAluno, f: { ...editAluno.f, [c.key]: e.target.value } })
                      }
                    />
                  )}
                </label>
              ))}
              <p className="col-span-2 text-[11px] text-muted-foreground">
                Ano/Série, Turma e Período valem para a sala inteira deste levantamento.
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditAluno(null)}>Cancelar</Button>
            <Button onClick={salvarAluno} disabled={salvandoAluno}>
              {salvandoAluno ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!editando} onOpenChange={(o) => !o && setEditando(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Alterar cadastro do CAD</DialogTitle>
          </DialogHeader>
          {editando && (
            <div className="grid grid-cols-2 gap-3">
              {CAMPOS_EDICAO.map((f) => (
                <label key={f.campo} className={`text-xs font-semibold text-muted-foreground ${f.largo ? "col-span-2" : ""}`}>
                  {f.rotulo}
                  <Input
                    className="mt-1"
                    type={f.campo === "jornada" ? "number" : "text"}
                    value={(editando[f.campo] as string | number | null | undefined) ?? ""}
                    onChange={(e) =>
                      setEditando({
                        ...editando,
                        [f.campo]: f.campo === "jornada" ? Number(e.target.value) || 0 : e.target.value,
                      })
                    }
                  />
                </label>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditando(null)}>Cancelar</Button>
            <Button onClick={salvarEdicao} disabled={salvando || !editando?.nome?.trim()}>
              {salvando && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!excluirAluno} onOpenChange={(o) => !o && setExcluirAluno(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir aluno do CAD?</AlertDialogTitle>
            <AlertDialogDescription>
              O aluno "{excluirAluno?.a.nome}" será removido deste vínculo no levantamento. Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmarExclusaoAluno}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={!!excluindo} onOpenChange={(o) => !o && setExcluindo(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir cadastro?</AlertDialogTitle>
            <AlertDialogDescription>
              O cadastro de <strong>{excluindo?.nome}</strong>
              {excluindo?.matricula ? ` (matrícula ${excluindo.matricula})` : ""} será removido
              permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmarExclusao}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
