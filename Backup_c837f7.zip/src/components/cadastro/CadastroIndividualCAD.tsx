import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listarCADs, salvarCAD, excluirCAD, type CAD } from "@/lib/cadastro-api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Loader2, Edit, Eye } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function CadastroIndividualCAD({ unidadeId }: { unidadeId: string }) {
  const queryClient = useQueryClient();
  const isTodos = unidadeId === "TODOS";
  const [editandoCad, setEditandoCad] = useState<CAD | null>(null);
  const [visualizandoCad, setVisualizandoCad] = useState<CAD | null>(null);
  
  const [novoCad, setNovoCad] = useState<Partial<CAD>>({ 
    jornada: 30, 
    situacao: "Em Exercício",
    cargo: "CUIDADOR DE ALUNO COM DEFICIÊNCIA"
  });

  const { data: cads = [], isLoading } = useQuery({
    queryKey: ["cads-individuais", unidadeId],
    queryFn: () => listarCADs(isTodos ? undefined : unidadeId),
    enabled: !!unidadeId,
  });

  const mutationSalvar = useMutation({
    mutationFn: salvarCAD,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cads-individuais", unidadeId] });
      toast.success("CAD salvo com sucesso!");
      setNovoCad({ 
        jornada: 30, 
        situacao: "Em Exercício",
        cargo: "CUIDADOR DE ALUNO COM DEFICIÊNCIA"
      });
    },
    onError: (err: any) => toast.error(err.message),
  });

  const mutationExcluir = useMutation({
    mutationFn: excluirCAD,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cads-individuais", unidadeId] });
      toast.success("CAD excluído!");
    },
  });

  if (!unidadeId) return null;

  return (
    <div className="space-y-4 mt-6">
      <header className="flex items-center justify-between">
        <h3 className="text-lg font-bold">
          {isTodos ? "Quadro Geral de Profissionais (Todos)" : "Listagem de Profissionais (CADs)"}
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
            {cads.length} profissionais cadastrados
          </span>
        </div>
      </header>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-2 text-left">Nome</th>
              {isTodos && <th className="px-4 py-2 text-left">Unidade</th>}
              <th className="px-4 py-2 text-left">Jornada</th>
              <th className="px-4 py-2 text-left">Cargo</th>
              <th className="px-4 py-2 text-left">Admissão</th>
              <th className="px-4 py-2 text-left">Matrícula</th>
              <th className="px-4 py-2 text-left">Situação</th>
              <th className="px-4 py-2 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {isLoading ? (
              <tr>
                <td colSpan={isTodos ? 8 : 7} className="px-4 py-8 text-center text-muted-foreground">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
                  Carregando profissionais...
                </td>
              </tr>
            ) : cads.length === 0 ? (
              <tr>
                <td colSpan={isTodos ? 8 : 7} className="px-4 py-8 text-center text-muted-foreground">
                  Nenhum profissional cadastrado nesta unidade.
                </td>
              </tr>
            ) : (
              cads.map((cad) => (
                <tr key={cad.id} className="hover:bg-accent/50">
                  <td className="px-4 py-2 font-medium">{cad.nome}</td>
                  {isTodos && <td className="px-4 py-2 text-xs truncate max-w-[120px]">{cad.unidade_id}</td>}
                  <td className="px-4 py-2">{cad.jornada}h</td>
                  <td className="px-4 py-2 truncate max-w-[150px]" title={cad.cargo || ""}>{cad.cargo || "—"}</td>
                  <td className="px-4 py-2">{cad.data_admissao || "—"}</td>
                  <td className="px-4 py-2">{cad.matricula || "—"}</td>
                  <td className="px-4 py-2">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] ${
                      (cad.status === 'Em Exercício' || cad.status === 'ATIVO') ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {cad.status || cad.situacao || "—"}
                    </span>
                  </td>

                  <td className="px-4 py-2 text-right space-x-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setVisualizandoCad(cad)}>
                      <Eye className="h-3.5 w-3.5 text-primary" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditandoCad(cad)}>
                      <Edit className="h-3.5 w-3.5 text-amber-600" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => {
                      if (confirm("Deseja realmente excluir este profissional?")) {
                        mutationExcluir.mutate(cad.id!);
                      }
                    }}>
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))
            )}
            
            {!isTodos && (
              <tr className="bg-muted/30">
                <td className="px-4 py-2">
                  <Input 
                    placeholder="Nome do profissional" 
                    value={novoCad.nome || ""} 
                    onChange={e => setNovoCad({...novoCad, nome: e.target.value})}
                    className="h-8 text-xs"
                  />
                </td>
                <td className="px-4 py-2">
                  <select 
                    className="h-8 text-xs border border-input bg-background rounded-md px-2 w-full"
                    value={novoCad.jornada}
                    onChange={e => setNovoCad({...novoCad, jornada: Number(e.target.value) as 30|40})}
                  >
                    <option value={30}>30h</option>
                    <option value={40}>40h</option>
                  </select>
                </td>
                <td className="px-4 py-2">
                  <Input 
                    placeholder="Cargo" 
                    value={novoCad.cargo || ""} 
                    onChange={e => setNovoCad({...novoCad, cargo: e.target.value})}
                    className="h-8 text-xs"
                  />
                </td>
                <td className="px-4 py-2">
                  <Input 
                    type="date"
                    value={novoCad.data_admissao || ""} 
                    onChange={e => setNovoCad({...novoCad, data_admissao: e.target.value})}
                    className="h-8 text-xs"
                  />
                </td>
                <td className="px-4 py-2">
                  <Input 
                    placeholder="Matrícula" 
                    value={novoCad.matricula || ""} 
                    onChange={e => setNovoCad({...novoCad, matricula: e.target.value})}
                    className="h-8 text-xs"
                  />
                </td>
                <td className="px-4 py-2">
                  <select 
                    className="h-8 text-xs border border-input bg-background rounded-md px-2 w-full"
                    value={novoCad.situacao || "Em Exercício"}
                    onChange={e => setNovoCad({...novoCad, situacao: e.target.value})}
                  >
                    <option value="Em Exercício">Em Exercício</option>
                    <option value="Contrato Temporário">Contrato Temporário</option>
                    <option value="Licença">Licença</option>
                    <option value="Afastado">Afastado</option>
                  </select>
                </td>
                <td className="px-4 py-2 text-right">
                  <Button 
                    size="sm" 
                    onClick={() => mutationSalvar.mutate({...novoCad, unidade_id: unidadeId} as CAD)}
                    disabled={!novoCad.nome || mutationSalvar.isPending}
                  >
                    {mutationSalvar.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                  </Button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal de Visualização */}
      <Dialog open={!!visualizandoCad} onOpenChange={(open) => !open && setVisualizandoCad(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-primary" />
              Dados do Profissional
            </DialogTitle>
          </DialogHeader>
          {visualizandoCad && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Nome</Label>
                <p className="text-sm font-medium">{visualizandoCad.nome}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Matrícula</Label>
                <p className="text-sm font-medium">{visualizandoCad.matricula || "—"}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Sexo</Label>
                <p className="text-sm font-medium">{visualizandoCad.sexo || "—"}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Cargo</Label>
                <p className="text-sm font-medium">{visualizandoCad.cargo || "—"}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Jornada</Label>
                <p className="text-sm font-medium">{visualizandoCad.jornada}h</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Status</Label>
                <p className="text-sm font-medium">{visualizandoCad.status || "—"}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Situação Funcional</Label>
                <p className="text-sm font-medium">{visualizandoCad.situacao_funcional || "—"}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Admissão</Label>
                <p className="text-sm font-medium">
                  {visualizandoCad.data_admissao ? visualizandoCad.data_admissao : "—"}
                </p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Vencimento</Label>
                <p className="text-sm font-medium">{visualizandoCad.vencimento || "—"}</p>
              </div>

              <div className="space-y-1 col-span-2">
                <Label className="text-[10px] uppercase text-muted-foreground">Unidade</Label>
                <p className="text-sm font-medium">{visualizandoCad.unidade_id}</p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setVisualizandoCad(null)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Edição */}
      <Dialog open={!!editandoCad} onOpenChange={(open) => !open && setEditandoCad(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5 text-amber-600" />
              Alterar Cadastro
            </DialogTitle>
          </DialogHeader>
          {editandoCad && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2 col-span-2">
                <Label>Nome Completo</Label>
                <Input 
                  value={editandoCad.nome} 
                  onChange={e => setEditandoCad({...editandoCad, nome: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Matrícula</Label>
                <Input 
                  value={editandoCad.matricula || ""} 
                  onChange={e => setEditandoCad({...editandoCad, matricula: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Sexo</Label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={editandoCad.sexo || ""}
                  onChange={e => setEditandoCad({...editandoCad, sexo: e.target.value})}
                >
                  <option value="">Selecione...</option>
                  <option value="M">Masculino</option>
                  <option value="F">Feminino</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label>Jornada</Label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={editandoCad.jornada}
                  onChange={e => setEditandoCad({...editandoCad, jornada: Number(e.target.value)})}
                >
                  <option value={30}>30h</option>
                  <option value={40}>40h</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label>Código Cargo</Label>
                <Input 
                  value={editandoCad.cod_cargo || ""} 
                  onChange={e => setEditandoCad({...editandoCad, cod_cargo: e.target.value})}
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label>Cargo</Label>
                <Input 
                  value={editandoCad.cargo || ""} 
                  onChange={e => setEditandoCad({...editandoCad, cargo: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Input 
                  value={editandoCad.status || ""} 
                  onChange={e => setEditandoCad({...editandoCad, status: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Situação Funcional</Label>
                <Input 
                  value={editandoCad.situacao_funcional || ""} 
                  onChange={e => setEditandoCad({...editandoCad, situacao_funcional: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Vencimento</Label>
                <Input 
                  value={editandoCad.vencimento || ""} 
                  onChange={e => setEditandoCad({...editandoCad, vencimento: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Data de Admissão</Label>
                <Input 
                  value={editandoCad.data_admissao || ""} 
                  onChange={e => setEditandoCad({...editandoCad, data_admissao: e.target.value})}
                />
              </div>
            </div>

          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditandoCad(null)}>Cancelar</Button>
            <Button 
              onClick={() => {
                if (editandoCad) {
                  mutationSalvar.mutate(editandoCad);
                  setEditandoCad(null);
                }
              }}
              disabled={mutationSalvar.isPending}
            >
              {mutationSalvar.isPending ? "Salvando..." : "Salvar Alterações"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <p className="text-[10px] text-muted-foreground italic">
        * Este cadastro alimenta a base individualizada da unidade para controle de carga horária e alocação.
      </p>
    </div>
  );
}
