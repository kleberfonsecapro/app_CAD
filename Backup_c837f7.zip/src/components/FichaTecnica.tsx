import type { Unidade } from "@/types/unidade";
import { analisarUnidade, MEDIA_NACIONAL, META_GESTAO } from "@/lib/analiseTecnica";
import { enderecoCompleto } from "@/lib/endereco";

const cor: Record<string, string> = {
  Excedente: "bg-secondary/10 text-secondary",
  Adequado: "bg-primary/10 text-primary",
  "Déficit": "bg-chart-5/15 text-chart-5",
  "Déficit crítico": "bg-destructive/10 text-destructive",
};

export default function FichaTecnica({ unidade }: { unidade: Unidade }) {
  const a = analisarUnidade(unidade);

  return (
    <article className="rounded-xl border border-border bg-card">
      <header className="grid gap-2 border-b border-border p-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start">
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-[0.2em] text-secondary">
            Ficha técnica da unidade · Região {unidade.regiao}
          </p>
          <h3 className="pmc-titulo truncate text-lg">{unidade.unidade}</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">{enderecoCompleto(unidade)}</p>
        </div>
        <span
          className={`justify-self-start rounded-full px-3 py-1 text-xs font-bold ${cor[a.classificacao]}`}
        >
          {a.classificacao} · {a.distorcao > 0 ? "+" : ""}
          {a.distorcao}%
        </span>
      </header>

      <div className="grid grid-cols-2 gap-px bg-border sm:grid-cols-4">
        <Cel titulo="Estudantes" valor={a.estudantes} />
        <Cel titulo="CADs hoje" valor={a.cadsAtuais} />
        <Cel titulo="Necessário técnico" valor={a.cadTecnico} destaque />
        <Cel
          titulo="Saldo"
          valor={`${a.saldo > 0 ? "+" : ""}${a.saldo}`}
          nota={a.saldo < 0 ? "faltam CADs" : "folga no quadro"}
        />
      </div>

      <div className="grid gap-4 p-4 lg:grid-cols-2">
        <section>
          <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Composição por perfil de autonomia
          </h4>
          <ul className="space-y-1.5 text-xs">
            {a.composicao.map((c) => (
              <li key={c.rotulo} className="rounded-md bg-muted px-3 py-2">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="font-semibold text-foreground">{c.rotulo}</span>
                  <span className="tabular-nums text-foreground">
                    {c.alunos} alunos → {Math.ceil(c.cads)} CAD
                  </span>
                </div>
                <p className="text-muted-foreground">{c.regra}</p>
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Cenários de dimensionamento
          </h4>
          <ul className="space-y-1.5 text-xs">
            {a.cenarios.map((c) => (
              <li
                key={c.chave}
                className="flex items-baseline justify-between gap-3 rounded-md border border-border px-3 py-2"
              >
                <span className="min-w-0">
                  <span className="block font-semibold text-foreground">{c.rotulo}</span>
                  <span className="block text-muted-foreground">{c.descricao}</span>
                </span>
                <strong className="shrink-0 text-base tabular-nums text-foreground">{c.cads}</strong>
              </li>
            ))}
          </ul>
          <p className="mt-2 rounded-md bg-primary/5 px-3 py-2 text-xs text-foreground">
            Faixa provável com gestão eficiente:{" "}
            <strong>
              {a.faixaMin}–{a.faixaMax} CADs
            </strong>
            . Referências: média nacional {MEDIA_NACIONAL} alunos/CAD (Inep/MEC) e meta interna{" "}
            {META_GESTAO} alunos/CAD. A lei não define proporção fixa — Lei 13.146/2015 e Decreto
            12.686/2025 exigem definição por estudo de caso.
          </p>
        </section>
      </div>

      {a.alertas.length > 0 && (
        <div className="border-t border-border p-4">
          <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Apontamentos técnicos
          </h4>
          <ul className="space-y-1 text-xs text-foreground">
            {a.alertas.map((x) => (
              <li key={x} className="flex gap-2">
                <span className="text-chart-5">▲</span>
                <span>{x}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <footer className="grid grid-cols-2 gap-3 border-t border-border p-4 text-xs text-muted-foreground sm:grid-cols-4">
        <p>
          TEA <strong className="text-foreground">{unidade.tea}</strong> (N3 {unidade.suporte3} / N2{" "}
          {unidade.suporte2} / N1 {unidade.suporte1})
        </p>
        <p>
          Deficiência <strong className="text-foreground">{unidade.deficiencia}</strong> · Transtornos{" "}
          {unidade.transtorno}
        </p>
        <p>
          Sem laudo <strong className="text-foreground">{unidade.semLaudo}</strong>
        </p>
        <p>
          Matutino {unidade.matutino} · Vespertino {unidade.vespertino} · Integral {unidade.integral}
        </p>
      </footer>
    </article>
  );
}

function Cel({
  titulo,
  valor,
  nota,
  destaque,
}: {
  titulo: string;
  valor: number | string;
  nota?: string;
  destaque?: boolean;
}) {
  return (
    <div className={`bg-card p-3 ${destaque ? "bg-primary/5" : ""}`}>
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{titulo}</p>
      <p className="text-xl font-bold tabular-nums text-foreground">{valor}</p>
      {nota && <p className="text-[10px] text-muted-foreground">{nota}</p>}
    </div>
  );
}
