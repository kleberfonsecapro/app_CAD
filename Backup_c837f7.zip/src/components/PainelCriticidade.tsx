import { COR_CLASSE, type Criticidade, type ResumoCriticidade } from "@/lib/criticidade";

const ORDEM: Criticidade["classe"][] = [
  "Excedente crítico",
  "Déficit crítico",
  "Déficit",
  "Adequado",
];

export default function PainelCriticidade({
  criticidade,
  resumo,
  raio,
  onSelecionar,
}: {
  criticidade: Map<string, Criticidade>;
  resumo: ResumoCriticidade;
  raio: number;
  onSelecionar: (u: string) => void;
}) {
  const lista = [...criticidade.values()];
  const excedentes = lista
    .filter((c) => c.classe === "Excedente crítico")
    .sort((a, b) => b.excedente - a.excedente || b.score - a.score);

  return (
    <section className="mt-8 rounded-xl border border-border bg-card">
      <div className="border-b border-border p-4">
        <h2 className="pmc-titulo text-lg">
          Criticidade do quadro de CAD — excedentes e sustentabilidade
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Unidades com <strong>excedente</strong> de cuidadores são sinalizadas como críticas no mapa
          (roxo tracejado): imobilizam força de trabalho que unidades vizinhas em déficit precisam.
          O plano abaixo redistribui os CADs dentro do raio de {raio} m para reduzir a exaustão
          emocional e a sobrecarga estrutural.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 p-4 lg:grid-cols-4">
        {[
          { l: "Excedentes críticos", v: resumo.excedentes, c: COR_CLASSE["Excedente crítico"] },
          { l: "Déficit crítico", v: resumo.deficitCritico, c: COR_CLASSE["Déficit crítico"] },
          { l: "CADs remanejáveis", v: resumo.cadsRemanejaveis, c: "hsl(200 65% 45%)" },
          {
            l: "CADs realocados no raio",
            v: `${resumo.cadsRemanejados} → ${resumo.unidadesBeneficiadas} un.`,
            c: COR_CLASSE.Adequado,
          },
        ].map((k) => (
          <div key={k.l} className="rounded-lg border border-border p-3">
            <span
              className="inline-block h-2 w-8 rounded-full"
              style={{ background: k.c as string }}
            />
            <p className="mt-1 text-2xl font-semibold tabular-nums text-foreground">{k.v}</p>
            <p className="text-xs text-muted-foreground">{k.l}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-3 border-t border-border px-4 py-3 text-xs">
        {ORDEM.map((c) => (
          <span key={c} className="flex items-center gap-1.5 text-muted-foreground">
            <span
              className="inline-block h-3 w-3 rounded-full"
              style={{ background: COR_CLASSE[c] }}
            />
            {c}
          </span>
        ))}
      </div>

      <div className="max-h-[420px] overflow-y-auto border-t border-border">
        {excedentes.length === 0 && (
          <p className="p-4 text-sm text-muted-foreground">
            Nenhuma unidade com excedente de CAD no recorte atual.
          </p>
        )}
        {excedentes.map((c) => (
          <div key={c.unidade} className="border-b border-border p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <button
                onClick={() => onSelecionar(c.unidade)}
                className="text-left text-sm font-semibold text-foreground underline-offset-2 hover:underline"
              >
                {c.unidade}
              </button>
              <span
                className="rounded-full px-2 py-0.5 text-[11px] font-semibold text-white"
                style={{ background: COR_CLASSE[c.classe] }}
              >
                +{c.excedente} CAD excedente · criticidade {c.score}/100
              </span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {c.analise.estudantes} estudantes · CAD atual {c.analise.cadsAtuais} · necessário
              técnico {c.analise.cadTecnico} · distorção {c.analise.distorcao}%
            </p>

            {c.movimentos.length > 0 ? (
              <ul className="mt-2 space-y-1 text-sm">
                {c.movimentos.map((m) => (
                  <li key={m.destino} className="flex flex-wrap items-center gap-2">
                    <span className="rounded bg-accent px-1.5 py-0.5 text-xs font-semibold">
                      {m.cads} CAD
                    </span>
                    <span>→</span>
                    <button
                      onClick={() => onSelecionar(m.destino)}
                      className="text-left underline-offset-2 hover:underline"
                    >
                      {m.destino}
                    </button>
                    <span className="text-xs text-muted-foreground">
                      {m.metros} m · déficit de {m.deficitDestino} CAD
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-2 text-xs text-muted-foreground">
                Sem unidade deficitária em até {raio} m — avaliar remanejamento regional.
              </p>
            )}

            {c.riscos.length > 0 && (
              <ul className="mt-2 list-disc pl-5 text-xs text-muted-foreground">
                {c.riscos.map((r) => (
                  <li key={r}>{r}</li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
