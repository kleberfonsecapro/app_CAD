import { createClient } from "@supabase/supabase-js";
import { readFileSync } from "fs";

// Using environment variables or direct keys since this is a one-time script
const supabaseUrl = process.env.VITE_SUPABASE_URL!;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);


async function importCads() {
  try {
    const rawData = readFileSync("/tmp/cads_data.json", "utf-8");
    const records = JSON.parse(rawData);
    
    console.log(`Iniciando importação de ${records.length} registros...`);

    // Mapeamento de campos:
    // EXCEL -> DATABASE
    // MATRICULA -> matricula
    // NOME -> nome
    // SEXO -> sexo
    // SITUACAO_FUNCIONAL -> situacao_funcional
    // STATUS -> status
    // ADMISSAO -> data_admissao
    // VENCIMENTO -> vencimento
    // COD. CARGO -> cod_cargo
    // CARGO -> cargo
    // JORNADA DE TRABALHO -> jornada
    // LOTACAO -> unidade_id (precisaremos de um mapeamento ou salvar como está)

    const cadsToInsert = records.map((r: any) => ({
      nome: r["NOME"],
      matricula: r["MATRICULA"],
      sexo: r["SEXO"],
      situacao_funcional: r["SITUACAO_FUNCIONAL"],
      status: r["STATUS"],
      data_admissao: r["ADMISSAO"] !== "nan" ? r["ADMISSAO"] : null,
      vencimento: r["VENCIMENTO"] !== "nan" ? r["VENCIMENTO"] : null,
      cod_cargo: r["COD. CARGO"],
      cargo: r["CARGO"],
      jornada: parseInt(r["JORNADA DE TRABALHO"]) || 30,
      unidade_id: r["LOTACAO"] // Salva a lotação original para posterior vinculação manual ou automática
    }));

    // Inserir em lotes de 100 para evitar limites
    const batchSize = 100;
    for (let i = 0; i < cadsToInsert.length; i += batchSize) {
      const batch = cadsToInsert.slice(i, i + batchSize);
      const { error } = await supabase.from("cads").upsert(batch, { onConflict: "matricula" });
      if (error) {
        console.error(`Erro no lote ${i}:`, error);
      } else {
        console.log(`Lote ${i} inserido com sucesso.`);
      }
    }

    console.log("Importação concluída.");
  } catch (err) {
    console.error("Falha na importação:", err);
  }
}

importCads();
