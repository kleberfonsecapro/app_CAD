# Plano de Implementação - Etapa 2 (Sala de Aula)

Este plano descreve a reestruturação da etapa "Sala de Aula" do Levantamento Pedagógico para permitir a vinculação de múltiplos CADs, cada um com seus respectivos alunos atendidos.

## Alterações Técnicas

### 1. Reestruturação do Estado (`src/components/pedagogico/LevantamentoPedagogicoForm.tsx`)
- Alterar o esquema de `salaAula` no estado `dadosPedagogicos` para suportar uma lista de vínculos entre CADs e alunos.
- Estrutura proposta:
    ```json
    {
      "salaAula": {
        "ano": "...",
        "turma": "...",
        "periodo": "...",
        "vinculos": [
          {
            "cadNome": "...",
            "alunos": [
              {
                "nome": "...",
                "cid": "...",
                "teaNivelSuporte": "...",
                "teaAutonomia": "...",
                "transtornoComportamental": "...",
                "possuiLaudo": "..."
              }
            ]
          }
        ]
      }
    }
    ```

### 2. Interface do Usuário (Etapa 2)
- Manter seletores de Ano, Turma e Período no topo.
- Criar um componente de lista de "CADs Vinculados".
- Para cada CAD na lista:
    - Excluir vínculo.
    - Adicionar/Remover alunos para aquele CAD específico.
    - Formulário individual para cada aluno com os dados técnicos (CID, TEA, Laudo).
- Botão "Vincular Profissional" que abre a busca de CADs.

### 3. Validação e Persistência
- Garantir que a estrutura aninhada seja serializada corretamente para o campo JSON no Supabase.

## Experiência do Usuário
- O fluxo permitirá que um fiscal registre exatamente quem está atendendo quem em uma sala com múltiplos profissionais e múltiplos alunos de inclusão.
- Design responsivo em "cards" para facilitar a visualização em dispositivos móveis.
