-- Tabela para cadastro individual de CADs
CREATE TABLE public.cads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unidade_id TEXT NOT NULL REFERENCES public.unidades_cadastro(unidade_id) ON DELETE CASCADE,
    nome TEXT NOT NULL,
    cpf TEXT UNIQUE,
    matricula TEXT UNIQUE,
    jornada INTEGER NOT NULL CHECK (jornada IN (30, 40)),
    cargo TEXT,
    situacao TEXT DEFAULT 'Ativo',
    data_admissao DATE,
    telefone TEXT,
    email TEXT,
    observacoes TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.cads ENABLE ROW LEVEL SECURITY;

-- Grants
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cads TO authenticated;
GRANT ALL ON public.cads TO service_role;

-- Políticas
CREATE POLICY "Permitir leitura para usuários autenticados" ON public.cads
    FOR SELECT TO authenticated USING (true);

CREATE POLICY "Permitir inserção para usuários autenticados" ON public.cads
    FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Permitir atualização para usuários autenticados" ON public.cads
    FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Permitir exclusão para usuários autenticados" ON public.cads
    FOR DELETE TO authenticated USING (true);

-- Gatilho para updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_cads_updated_at
    BEFORE UPDATE ON public.cads
    FOR EACH ROW
    EXECUTE PROCEDURE update_updated_at_column();
