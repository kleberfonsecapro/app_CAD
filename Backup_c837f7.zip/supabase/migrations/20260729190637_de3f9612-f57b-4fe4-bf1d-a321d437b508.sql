CREATE TABLE public.unidades_cadastro (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  unidade_id TEXT NOT NULL UNIQUE,
  nome TEXT NOT NULL,
  inep TEXT,
  regiao TEXT,
  logradouro TEXT,
  numero TEXT,
  bairro TEXT,
  cep TEXT,
  cidade TEXT DEFAULT 'Cuiabá',
  uf TEXT DEFAULT 'MT',
  telefone TEXT,
  email TEXT,
  diretor TEXT,
  modalidades TEXT,
  turnos TEXT,
  qtd_salas INTEGER,
  qtd_alunos INTEGER,
  situacao_imovel TEXT,
  observacoes TEXT,
  atualizado_por TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.vistorias (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  unidade_id TEXT NOT NULL,
  unidade_nome TEXT NOT NULL,
  data_vistoria DATE,
  imovel_proprio_alugado TEXT,
  responsavel TEXT,
  uso_tipo TEXT DEFAULT 'educacional',
  estrutural JSONB NOT NULL DEFAULT '{}'::jsonb,
  fotografico JSONB NOT NULL DEFAULT '{}'::jsonb,
  entorno JSONB NOT NULL DEFAULT '{}'::jsonb,
  parecer JSONB NOT NULL DEFAULT '{}'::jsonb,
  nota_media NUMERIC(4,2),
  etapa INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'rascunho',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_vistorias_unidade ON public.vistorias (unidade_id);
CREATE INDEX idx_vistorias_updated ON public.vistorias (updated_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.unidades_cadastro TO anon, authenticated;
GRANT ALL ON public.unidades_cadastro TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vistorias TO anon, authenticated;
GRANT ALL ON public.vistorias TO service_role;

ALTER TABLE public.unidades_cadastro ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vistorias ENABLE ROW LEVEL SECURITY;

CREATE POLICY "cadastro publico leitura" ON public.unidades_cadastro FOR SELECT USING (true);
CREATE POLICY "cadastro publico insercao" ON public.unidades_cadastro FOR INSERT WITH CHECK (true);
CREATE POLICY "cadastro publico atualizacao" ON public.unidades_cadastro FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "vistoria publica leitura" ON public.vistorias FOR SELECT USING (true);
CREATE POLICY "vistoria publica insercao" ON public.vistorias FOR INSERT WITH CHECK (true);
CREATE POLICY "vistoria publica atualizacao" ON public.vistorias FOR UPDATE USING (true) WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER trg_unidades_cadastro_updated BEFORE UPDATE ON public.unidades_cadastro
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_vistorias_updated BEFORE UPDATE ON public.vistorias
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();