-- Tabela para cadastro individual de CADs
CREATE TABLE public.cads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unidade_id TEXT NOT NULL,
    nome TEXT NOT NULL,
    cpf TEXT UNIQUE,
    matricula TEXT UNIQUE,
    jornada INTEGER NOT NULL CHECK (jornada IN (30, 40)),
    cargo TEXT,
    situacao TEXT DEFAULT 'Ativo',
    data_admissao DATE,
    telefone TEXT,
    email TEXT,
    observacoes TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.cads ENABLE ROW LEVEL SECURITY;

-- Grants
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cads TO authenticated;
GRANT ALL ON public.cads TO service_role;
GRANT SELECT ON public.cads TO anon;

-- Políticas
CREATE POLICY "Permitir leitura para todos" ON public.cads
    FOR SELECT TO public USING (true);

CREATE POLICY "Permitir inserção para todos" ON public.cads
    FOR INSERT TO public WITH CHECK (true);

CREATE POLICY "Permitir atualização para todos" ON public.cads
    FOR UPDATE TO public USING (true);

CREATE POLICY "Permitir exclusão para todos" ON public.cads
    FOR DELETE TO public USING (true);

-- Gatilho para updated_at (assumindo que já não exista um global)
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_cads_updated_at
    BEFORE UPDATE ON public.cads
    FOR EACH ROW
    EXECUTE PROCEDURE update_updated_at_column();

-- Seed data
INSERT INTO public.cads (unidade_id, nome, jornada, cargo, situacao, matricula, data_admissao)
VALUES 
('EMEB PROFª ELIZABETH MARIA BASTOS FIAUX', 'ANA CLAUDIA DE OLIVEIRA', 30, 'CUIDADOR DE ALUNO COM DEFICIÊNCIA', 'Em Exercício', '102345', '2022-03-15'),
('EMEB PROFª ELIZABETH MARIA BASTOS FIAUX', 'CARLOS ALBERTO SILVA', 40, 'CUIDADOR DE ALUNO COM DEFICIÊNCIA', 'Contrato Temporário', '105678', '2023-01-10'),
('CMEI CUIABÁ', 'MARIA APARECIDA SANTOS', 30, 'CUIDADOR DE ALUNO COM DEFICIÊNCIA', 'Em Exercício', '108901', '2021-06-20'),
('EMEB PROF. NILCE MARIA DE FIGUEIREDO', 'RICARDO PEREIRA LIMA', 40, 'CUIDADOR DE ALUNO COM DEFICIÊNCIA', 'Em Exercício', '101122', '2020-02-05'),
('CMEI PROFª. ANA MARIA DO NASCIMENTO', 'JULIANA SOUZA FERREIRA', 30, 'CUIDADOR DE ALUNO COM DEFICIÊNCIA', 'Licença', '103344', '2022-08-12'),
('EMEB PROFª. ADALBERTO VALENTIM DE MATOS', 'FERNANDO GOMES COSTA', 40, 'CUIDADOR DE ALUNO COM DEFICIÊNCIA', 'Em Exercício', '105566', '2023-05-22');
