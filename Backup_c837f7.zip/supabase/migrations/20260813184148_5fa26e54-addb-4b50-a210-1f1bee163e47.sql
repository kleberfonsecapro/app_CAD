CREATE TABLE IF NOT EXISTS public.levantamentos_pedagogicos (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    unidade_id text NOT NULL,
    unidade_nome text NOT NULL,
    data_levantamento date,
    responsavel text,
    dados_pedagogicos jsonb DEFAULT '{}'::jsonb NOT NULL,
    etapa integer DEFAULT 1,
    status text DEFAULT 'rascunho' CHECK (status IN ('rascunho', 'concluida')),
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.levantamentos_pedagogicos TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.levantamentos_pedagogicos TO anon;
GRANT ALL ON public.levantamentos_pedagogicos TO service_role;

ALTER TABLE public.levantamentos_pedagogicos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public select" ON public.levantamentos_pedagogicos FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.levantamentos_pedagogicos FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.levantamentos_pedagogicos FOR UPDATE USING (true);

CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS on_levantamentos_pedagogicos_updated ON public.levantamentos_pedagogicos;
CREATE TRIGGER on_levantamentos_pedagogicos_updated
    BEFORE UPDATE ON public.levantamentos_pedagogicos
    FOR EACH ROW
    EXECUTE PROCEDURE public.handle_updated_at();
