-- Adicionar novas colunas à tabela cads conforme solicitado
ALTER TABLE public.cads 
ADD COLUMN IF NOT EXISTS sexo TEXT,
ADD COLUMN IF NOT EXISTS situacao_funcional TEXT,
ADD COLUMN IF NOT EXISTS status TEXT,
ADD COLUMN IF NOT EXISTS vencimento TEXT,
ADD COLUMN IF NOT EXISTS cod_cargo TEXT;

-- Garantir que a coluna unidade_id possa ser nula temporariamente
ALTER TABLE public.cads ALTER COLUMN unidade_id DROP NOT NULL;

-- Grants (reforço)
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cads TO authenticated;
GRANT ALL ON public.cads TO service_role;
