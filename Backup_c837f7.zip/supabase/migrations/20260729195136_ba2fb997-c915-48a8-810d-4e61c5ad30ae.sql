ALTER TABLE public.unidades_cadastro
  ADD COLUMN IF NOT EXISTS qtd_alunos_instituicao integer,
  ADD COLUMN IF NOT EXISTS qtd_cads integer;