-- Adicionar novas colunas à tabela cads conforme solicitado
ALTER TABLE public.cads 
ADD COLUMN IF NOT EXISTS sexo TEXT,
ADD COLUMN IF NOT EXISTS situacao_funcional TEXT,
ADD COLUMN IF NOT EXISTS status TEXT,
ADD COLUMN IF NOT EXISTS vencimento TEXT,
ADD COLUMN IF NOT EXISTS cod_cargo TEXT;

-- Ajustar nomes de colunas existentes se necessário (matricula, cargo, jornada já existem)
-- A coluna 'jornada' já é INTEGER CHECK (jornada IN (30, 40))
-- A coluna 'situacao' será mantida como legado ou mapeada para status se necessário.

-- Garantir que a coluna unidade_id possa ser nula temporariamente se não encontrarmos a lotação correspondente
ALTER TABLE public.cads ALTER COLUMN unidade_id DROP NOT NULL;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cads TO authenticated;
GRANT ALL ON public.cads TO service_role;
